// data/pokemon-final-with-forms.json
var pokemon_final_with_forms_default = [
  {
    dexId: 1,
    slug: "bulbasaur",
    en: "Bulbasaur",
    ko: "이상해씨",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 2,
    slug: "ivysaur",
    en: "Ivysaur",
    ko: "이상해풀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 3,
    slug: "venusaur",
    en: "Venusaur",
    ko: "이상해꽃",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 3,
    slug: "mega-venusaur",
    en: "Mega Venusaur",
    ko: "메가이상해꽃",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 3,
    slug: "venusaur-gigantamax",
    en: "Venusaur (G)",
    ko: "이상해꽃 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 4,
    slug: "charmander",
    en: "Charmander",
    ko: "파이리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 5,
    slug: "charmeleon",
    en: "Charmeleon",
    ko: "리자드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 6,
    slug: "charizard",
    en: "Charizard",
    ko: "리자몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 6,
    slug: "charizard-gigantamax",
    en: "Charizard (G)",
    ko: "리자몽 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 6,
    slug: "mega-charizard-x",
    en: "Mega Charizard X",
    ko: "메가리자몽X",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 6,
    slug: "mega-charizard-y",
    en: "Mega Charizard Y",
    ko: "메가리자몽Y",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 7,
    slug: "squirtle",
    en: "Squirtle",
    ko: "꼬부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 8,
    slug: "wartortle",
    en: "Wartortle",
    ko: "어니부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 9,
    slug: "blastoise",
    en: "Blastoise",
    ko: "거북왕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 9,
    slug: "blastoise-gigantamax",
    en: "Blastoise (G)",
    ko: "거북왕 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 9,
    slug: "mega-blastoise",
    en: "Mega Blastoise",
    ko: "메가거북왕",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 10,
    slug: "caterpie",
    en: "Caterpie",
    ko: "캐터피",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 11,
    slug: "metapod",
    en: "Metapod",
    ko: "단데기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 12,
    slug: "butterfree",
    en: "Butterfree",
    ko: "버터플",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 12,
    slug: "butterfree-gigantamax",
    en: "Butterfree (G)",
    ko: "버터플 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 13,
    slug: "weedle",
    en: "Weedle",
    ko: "뿔충이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 14,
    slug: "kakuna",
    en: "Kakuna",
    ko: "딱충이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 15,
    slug: "beedrill",
    en: "Beedrill",
    ko: "독침붕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 15,
    slug: "mega-beedrill",
    en: "Mega Beedrill",
    ko: "메가독침붕",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 16,
    slug: "pidgey",
    en: "Pidgey",
    ko: "구구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 17,
    slug: "pidgeotto",
    en: "Pidgeotto",
    ko: "피죤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 18,
    slug: "pidgeot",
    en: "Pidgeot",
    ko: "피죤투",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 18,
    slug: "mega-pidgeot",
    en: "Mega Pidgeot",
    ko: "메가피죤투",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 19,
    slug: "rattata",
    en: "Rattata",
    ko: "꼬렛",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 19,
    slug: "rattata-alolan",
    en: "Rattata (Alolan)",
    ko: "꼬렛 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 20,
    slug: "raticate",
    en: "Raticate",
    ko: "레트라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 20,
    slug: "raticate-alolan",
    en: "Raticate (Alolan)",
    ko: "레트라 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 21,
    slug: "spearow",
    en: "Spearow",
    ko: "깨비참",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 22,
    slug: "fearow",
    en: "Fearow",
    ko: "깨비드릴조",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 23,
    slug: "ekans",
    en: "Ekans",
    ko: "아보",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 24,
    slug: "arbok",
    en: "Arbok",
    ko: "아보크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 25,
    slug: "pikachu",
    en: "Pikachu",
    ko: "피카츄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 25,
    slug: "pikachu-gigantamax",
    en: "Pikachu (G)",
    ko: "피카츄 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 26,
    slug: "raichu",
    en: "Raichu",
    ko: "라이츄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 26,
    slug: "mega-raichu-x",
    en: "Mega Raichu X",
    ko: "메가라이츄X",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 26,
    slug: "mega-raichu-y",
    en: "Mega Raichu Y",
    ko: "메가라이츄Y",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 26,
    slug: "raichu-alolan",
    en: "Raichu (Alolan)",
    ko: "라이츄 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 27,
    slug: "sandshrew",
    en: "Sandshrew",
    ko: "모래두지",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 27,
    slug: "sandshrew-alolan",
    en: "Sandshrew (Alolan)",
    ko: "모래두지 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 28,
    slug: "sandslash",
    en: "Sandslash",
    ko: "고지",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 28,
    slug: "sandslash-alolan",
    en: "Sandslash (Alolan)",
    ko: "고지 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 29,
    slug: "nidoran-f",
    en: "Nidoran♀",
    ko: "니드런♀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 29,
    slug: "nidoran♀",
    en: "Nidoran♀",
    ko: "니드런♀",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 30,
    slug: "nidorina",
    en: "Nidorina",
    ko: "니드리나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 31,
    slug: "nidoqueen",
    en: "Nidoqueen",
    ko: "니드퀸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 32,
    slug: "nidoran-m",
    en: "Nidoran♂",
    ko: "니드런♂",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 32,
    slug: "nidoran♂",
    en: "Nidoran♂",
    ko: "니드런♂",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 33,
    slug: "nidorino",
    en: "Nidorino",
    ko: "니드리노",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 34,
    slug: "nidoking",
    en: "Nidoking",
    ko: "니드킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 35,
    slug: "clefairy",
    en: "Clefairy",
    ko: "삐삐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 36,
    slug: "clefable",
    en: "Clefable",
    ko: "픽시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 36,
    slug: "mega-clefable",
    en: "Mega Clefable",
    ko: "메가픽시",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 37,
    slug: "vulpix",
    en: "Vulpix",
    ko: "식스테일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 37,
    slug: "vulpix-alolan",
    en: "Vulpix (Alolan)",
    ko: "식스테일 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 38,
    slug: "ninetales",
    en: "Ninetales",
    ko: "나인테일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 38,
    slug: "ninetales-alolan",
    en: "Ninetales (Alolan)",
    ko: "나인테일 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 39,
    slug: "jigglypuff",
    en: "Jigglypuff",
    ko: "푸린",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 40,
    slug: "wigglytuff",
    en: "Wigglytuff",
    ko: "푸크린",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 41,
    slug: "zubat",
    en: "Zubat",
    ko: "주뱃",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 42,
    slug: "golbat",
    en: "Golbat",
    ko: "골뱃",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 43,
    slug: "oddish",
    en: "Oddish",
    ko: "뚜벅쵸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 44,
    slug: "gloom",
    en: "Gloom",
    ko: "냄새꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 45,
    slug: "vileplume",
    en: "Vileplume",
    ko: "라플레시아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 46,
    slug: "paras",
    en: "Paras",
    ko: "파라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 47,
    slug: "parasect",
    en: "Parasect",
    ko: "파라섹트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 48,
    slug: "venonat",
    en: "Venonat",
    ko: "콘팡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 49,
    slug: "venomoth",
    en: "Venomoth",
    ko: "도나리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 50,
    slug: "diglett",
    en: "Diglett",
    ko: "디그다",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 50,
    slug: "diglett-alolan",
    en: "Diglett (Alolan)",
    ko: "디그다 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 51,
    slug: "dugtrio",
    en: "Dugtrio",
    ko: "닥트리오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 51,
    slug: "dugtrio-alolan",
    en: "Dugtrio (Alolan)",
    ko: "닥트리오 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 52,
    slug: "meowth",
    en: "Meowth",
    ko: "나옹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 52,
    slug: "meowth-alolan",
    en: "Meowth (Alolan)",
    ko: "나옹 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 52,
    slug: "meowth-galarian",
    en: "Meowth (Galarian)",
    ko: "나옹 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 52,
    slug: "meowth-gigantamax",
    en: "Meowth (G)",
    ko: "나옹 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 53,
    slug: "persian",
    en: "Persian",
    ko: "페르시온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 53,
    slug: "persian-alolan",
    en: "Persian (Alolan)",
    ko: "페르시온 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 54,
    slug: "psyduck",
    en: "Psyduck",
    ko: "고라파덕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 55,
    slug: "golduck",
    en: "Golduck",
    ko: "골덕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 56,
    slug: "mankey",
    en: "Mankey",
    ko: "망키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 57,
    slug: "primeape",
    en: "Primeape",
    ko: "성원숭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 58,
    slug: "growlithe",
    en: "Growlithe",
    ko: "가디",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 58,
    slug: "growlithe-hisuian",
    en: "Growlithe (Hisuian)",
    ko: "가디 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 59,
    slug: "arcanine",
    en: "Arcanine",
    ko: "윈디",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 59,
    slug: "arcanine-hisuian",
    en: "Arcanine (Hisuian)",
    ko: "윈디 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 60,
    slug: "poliwag",
    en: "Poliwag",
    ko: "발챙이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 61,
    slug: "poliwhirl",
    en: "Poliwhirl",
    ko: "슈륙챙이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 62,
    slug: "poliwrath",
    en: "Poliwrath",
    ko: "강챙이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 63,
    slug: "abra",
    en: "Abra",
    ko: "캐이시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 64,
    slug: "kadabra",
    en: "Kadabra",
    ko: "윤겔라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 65,
    slug: "alakazam",
    en: "Alakazam",
    ko: "후딘",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 65,
    slug: "mega-alakazam",
    en: "Mega Alakazam",
    ko: "메가후딘",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 66,
    slug: "machop",
    en: "Machop",
    ko: "알통몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 67,
    slug: "machoke",
    en: "Machoke",
    ko: "근육몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 68,
    slug: "machamp",
    en: "Machamp",
    ko: "괴력몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 68,
    slug: "machamp-gigantamax",
    en: "Machamp (G)",
    ko: "괴력몬 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 69,
    slug: "bellsprout",
    en: "Bellsprout",
    ko: "모다피",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 70,
    slug: "weepinbell",
    en: "Weepinbell",
    ko: "우츠동",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 71,
    slug: "victreebel",
    en: "Victreebel",
    ko: "우츠보트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 71,
    slug: "mega-victreebel",
    en: "Mega Victreebel",
    ko: "메가우츠보트",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 72,
    slug: "tentacool",
    en: "Tentacool",
    ko: "왕눈해",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 73,
    slug: "tentacruel",
    en: "Tentacruel",
    ko: "독파리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 74,
    slug: "geodude",
    en: "Geodude",
    ko: "꼬마돌",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 74,
    slug: "geodude-alolan",
    en: "Geodude (Alolan)",
    ko: "꼬마돌 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 75,
    slug: "graveler",
    en: "Graveler",
    ko: "데구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 75,
    slug: "graveler-alolan",
    en: "Graveler (Alolan)",
    ko: "데구리 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 76,
    slug: "golem",
    en: "Golem",
    ko: "딱구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 76,
    slug: "golem-alolan",
    en: "Golem (Alolan)",
    ko: "딱구리 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 77,
    slug: "ponyta",
    en: "Ponyta",
    ko: "포니타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 77,
    slug: "ponyta-galarian",
    en: "Ponyta (Galarian)",
    ko: "포니타 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 78,
    slug: "rapidash",
    en: "Rapidash",
    ko: "날쌩마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 78,
    slug: "rapidash-galarian",
    en: "Rapidash (Galarian)",
    ko: "날쌩마 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 79,
    slug: "slowpoke",
    en: "Slowpoke",
    ko: "야돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 79,
    slug: "slowpoke-galarian",
    en: "Slowpoke (Galarian)",
    ko: "야돈 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 80,
    slug: "slowbro",
    en: "Slowbro",
    ko: "야도란",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 80,
    slug: "mega-slowbro",
    en: "Mega Slowbro",
    ko: "메가야도란",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 80,
    slug: "slowbro-galarian",
    en: "Slowbro (Galarian)",
    ko: "야도란 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 81,
    slug: "magnemite",
    en: "Magnemite",
    ko: "코일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 82,
    slug: "magneton",
    en: "Magneton",
    ko: "레어코일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 83,
    slug: "farfetchd",
    en: "Farfetch'd",
    ko: "파오리",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 83,
    slug: "farfetch’d",
    en: "Farfetch’d",
    ko: "파오리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 83,
    slug: "farfetchd-galarian",
    en: "Farfetch'd (Galarian)",
    ko: "파오리 (가라르)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 84,
    slug: "doduo",
    en: "Doduo",
    ko: "두두",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 85,
    slug: "dodrio",
    en: "Dodrio",
    ko: "두트리오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 86,
    slug: "seel",
    en: "Seel",
    ko: "쥬쥬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 87,
    slug: "dewgong",
    en: "Dewgong",
    ko: "쥬레곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 88,
    slug: "grimer",
    en: "Grimer",
    ko: "질퍽이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 88,
    slug: "grimer-alolan",
    en: "Grimer (Alolan)",
    ko: "질퍽이 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 89,
    slug: "muk",
    en: "Muk",
    ko: "질뻐기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 89,
    slug: "muk-alolan",
    en: "Muk (Alolan)",
    ko: "질뻐기 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 90,
    slug: "shellder",
    en: "Shellder",
    ko: "셀러",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 91,
    slug: "cloyster",
    en: "Cloyster",
    ko: "파르셀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 92,
    slug: "gastly",
    en: "Gastly",
    ko: "고오스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 93,
    slug: "haunter",
    en: "Haunter",
    ko: "고우스트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 94,
    slug: "gengar",
    en: "Gengar",
    ko: "팬텀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 94,
    slug: "gengar-gigantamax",
    en: "Gengar (G)",
    ko: "팬텀 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 94,
    slug: "mega-gengar",
    en: "Mega Gengar",
    ko: "메가팬텀",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 95,
    slug: "onix",
    en: "Onix",
    ko: "롱스톤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 96,
    slug: "drowzee",
    en: "Drowzee",
    ko: "슬리프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 97,
    slug: "hypno",
    en: "Hypno",
    ko: "슬리퍼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 98,
    slug: "krabby",
    en: "Krabby",
    ko: "크랩",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 99,
    slug: "kingler",
    en: "Kingler",
    ko: "킹크랩",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 99,
    slug: "kingler-gigantamax",
    en: "Kingler (G)",
    ko: "킹크랩 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 100,
    slug: "voltorb",
    en: "Voltorb",
    ko: "찌리리공",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 100,
    slug: "voltorb-hisuian",
    en: "Voltorb (Hisuian)",
    ko: "찌리리공 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 101,
    slug: "electrode",
    en: "Electrode",
    ko: "붐볼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 101,
    slug: "electrode-hisuian",
    en: "Electrode (Hisuian)",
    ko: "붐볼 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 102,
    slug: "exeggcute",
    en: "Exeggcute",
    ko: "아라리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 103,
    slug: "exeggutor",
    en: "Exeggutor",
    ko: "나시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 103,
    slug: "exeggutor-alolan",
    en: "Exeggutor (Alolan)",
    ko: "나시 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 104,
    slug: "cubone",
    en: "Cubone",
    ko: "탕구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 105,
    slug: "marowak",
    en: "Marowak",
    ko: "텅구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 105,
    slug: "marowak-alolan",
    en: "Marowak (Alolan)",
    ko: "텅구리 (알로라)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 106,
    slug: "hitmonlee",
    en: "Hitmonlee",
    ko: "시라소몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 107,
    slug: "hitmonchan",
    en: "Hitmonchan",
    ko: "홍수몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 108,
    slug: "lickitung",
    en: "Lickitung",
    ko: "내루미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 109,
    slug: "koffing",
    en: "Koffing",
    ko: "또가스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 110,
    slug: "weezing",
    en: "Weezing",
    ko: "또도가스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 110,
    slug: "weezing-galarian",
    en: "Weezing (Galarian)",
    ko: "또도가스 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 111,
    slug: "rhyhorn",
    en: "Rhyhorn",
    ko: "뿔카노",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 112,
    slug: "rhydon",
    en: "Rhydon",
    ko: "코뿌리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 113,
    slug: "chansey",
    en: "Chansey",
    ko: "럭키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 114,
    slug: "tangela",
    en: "Tangela",
    ko: "덩쿠리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 115,
    slug: "kangaskhan",
    en: "Kangaskhan",
    ko: "캥카",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 115,
    slug: "mega-kangaskhan",
    en: "Mega Kangaskhan",
    ko: "메가캥카",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 116,
    slug: "horsea",
    en: "Horsea",
    ko: "쏘드라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 117,
    slug: "seadra",
    en: "Seadra",
    ko: "시드라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 118,
    slug: "goldeen",
    en: "Goldeen",
    ko: "콘치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 119,
    slug: "seaking",
    en: "Seaking",
    ko: "왕콘치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 120,
    slug: "staryu",
    en: "Staryu",
    ko: "별가사리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 121,
    slug: "starmie",
    en: "Starmie",
    ko: "아쿠스타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 121,
    slug: "mega-starmie",
    en: "Mega Starmie",
    ko: "메가아쿠스타",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 122,
    slug: "mr.-mime",
    en: "Mr. Mime",
    ko: "마임맨",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 122,
    slug: "mr-mime",
    en: "Mr. Mime",
    ko: "마임맨",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 122,
    slug: "mr-mime-galarian",
    en: "Mr. Mime (Galarian)",
    ko: "마임맨 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 123,
    slug: "scyther",
    en: "Scyther",
    ko: "스라크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 124,
    slug: "jynx",
    en: "Jynx",
    ko: "루주라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 125,
    slug: "electabuzz",
    en: "Electabuzz",
    ko: "에레브",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 126,
    slug: "magmar",
    en: "Magmar",
    ko: "마그마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 127,
    slug: "pinsir",
    en: "Pinsir",
    ko: "쁘사이저",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 127,
    slug: "mega-pinsir",
    en: "Mega Pinsir",
    ko: "메가쁘사이저",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 128,
    slug: "tauros",
    en: "Tauros",
    ko: "켄타로스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 128,
    slug: "tauros-aqua-breed",
    en: "Tauros (Aqua)",
    ko: "켄타로스(아쿠아종)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 128,
    slug: "tauros-blaze-breed",
    en: "Tauros (Blaze)",
    ko: "켄타로스(블레이즈종)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 128,
    slug: "tauros-combat-breed",
    en: "Tauros (Combat)",
    ko: "켄타로스(컴뱃종)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 129,
    slug: "magikarp",
    en: "Magikarp",
    ko: "잉어킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 130,
    slug: "gyarados",
    en: "Gyarados",
    ko: "갸라도스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 130,
    slug: "mega-gyarados",
    en: "Mega Gyarados",
    ko: "메가갸라도스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 131,
    slug: "lapras",
    en: "Lapras",
    ko: "라프라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 131,
    slug: "lapras-gigantamax",
    en: "Lapras (G)",
    ko: "라프라스 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 132,
    slug: "ditto",
    en: "Ditto",
    ko: "메타몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 133,
    slug: "eevee",
    en: "Eevee",
    ko: "이브이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 133,
    slug: "eevee-gigantamax",
    en: "Eevee (G)",
    ko: "이브이 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 134,
    slug: "vaporeon",
    en: "Vaporeon",
    ko: "샤미드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 135,
    slug: "jolteon",
    en: "Jolteon",
    ko: "쥬피썬더",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 136,
    slug: "flareon",
    en: "Flareon",
    ko: "부스터",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 137,
    slug: "porygon",
    en: "Porygon",
    ko: "폴리곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 138,
    slug: "omanyte",
    en: "Omanyte",
    ko: "암나이트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 139,
    slug: "omastar",
    en: "Omastar",
    ko: "암스타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 140,
    slug: "kabuto",
    en: "Kabuto",
    ko: "투구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 141,
    slug: "kabutops",
    en: "Kabutops",
    ko: "투구푸스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 142,
    slug: "aerodactyl",
    en: "Aerodactyl",
    ko: "프테라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 142,
    slug: "mega-aerodactyl",
    en: "Mega Aerodactyl",
    ko: "메가프테라",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 143,
    slug: "snorlax",
    en: "Snorlax",
    ko: "잠만보",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 143,
    slug: "snorlax-gigantamax",
    en: "Snorlax (G)",
    ko: "잠만보 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 144,
    slug: "articuno",
    en: "Articuno",
    ko: "프리져",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 144,
    slug: "articuno-galarian",
    en: "Articuno (Galarian)",
    ko: "프리져 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 145,
    slug: "zapdos",
    en: "Zapdos",
    ko: "썬더",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 145,
    slug: "zapdos-galarian",
    en: "Zapdos (Galarian)",
    ko: "썬더 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 146,
    slug: "moltres",
    en: "Moltres",
    ko: "파이어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 146,
    slug: "moltres-galarian",
    en: "Moltres (Galarian)",
    ko: "파이어 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 147,
    slug: "dratini",
    en: "Dratini",
    ko: "미뇽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 148,
    slug: "dragonair",
    en: "Dragonair",
    ko: "신뇽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 149,
    slug: "dragonite",
    en: "Dragonite",
    ko: "망나뇽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 149,
    slug: "mega-dragonite",
    en: "Mega Dragonite",
    ko: "메가망나뇽",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 150,
    slug: "mewtwo",
    en: "Mewtwo",
    ko: "뮤츠",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 150,
    slug: "mega-mewtwo-x",
    en: "Mega Mewtwo X",
    ko: "메가뮤츠X",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 150,
    slug: "mega-mewtwo-y",
    en: "Mega Mewtwo Y",
    ko: "메가뮤츠Y",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 151,
    slug: "mew",
    en: "Mew",
    ko: "뮤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 152,
    slug: "chikorita",
    en: "Chikorita",
    ko: "치코리타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 153,
    slug: "bayleef",
    en: "Bayleef",
    ko: "베이리프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 154,
    slug: "meganium",
    en: "Meganium",
    ko: "메가니움",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 154,
    slug: "mega-meganium",
    en: "Mega Meganium",
    ko: "메가메가니움",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 155,
    slug: "cyndaquil",
    en: "Cyndaquil",
    ko: "브케인",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 156,
    slug: "quilava",
    en: "Quilava",
    ko: "마그케인",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 157,
    slug: "typhlosion",
    en: "Typhlosion",
    ko: "블레이범",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 157,
    slug: "typhlosion-hisuian",
    en: "Typhlosion (Hisuian)",
    ko: "블레이범 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 158,
    slug: "totodile",
    en: "Totodile",
    ko: "리아코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 159,
    slug: "croconaw",
    en: "Croconaw",
    ko: "엘리게이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 160,
    slug: "feraligatr",
    en: "Feraligatr",
    ko: "장크로다일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 160,
    slug: "mega-feraligatr",
    en: "Mega Feraligatr",
    ko: "메가장크로다일",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 161,
    slug: "sentret",
    en: "Sentret",
    ko: "꼬리선",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 162,
    slug: "furret",
    en: "Furret",
    ko: "다꼬리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 163,
    slug: "hoothoot",
    en: "Hoothoot",
    ko: "부우부",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 164,
    slug: "noctowl",
    en: "Noctowl",
    ko: "야부엉",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 165,
    slug: "ledyba",
    en: "Ledyba",
    ko: "레디바",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 166,
    slug: "ledian",
    en: "Ledian",
    ko: "레디안",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 167,
    slug: "spinarak",
    en: "Spinarak",
    ko: "페이검",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 168,
    slug: "ariados",
    en: "Ariados",
    ko: "아리아도스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 169,
    slug: "crobat",
    en: "Crobat",
    ko: "크로뱃",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 170,
    slug: "chinchou",
    en: "Chinchou",
    ko: "초라기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 171,
    slug: "lanturn",
    en: "Lanturn",
    ko: "랜턴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 172,
    slug: "pichu",
    en: "Pichu",
    ko: "피츄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 173,
    slug: "cleffa",
    en: "Cleffa",
    ko: "삐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 174,
    slug: "igglybuff",
    en: "Igglybuff",
    ko: "푸푸린",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 175,
    slug: "togepi",
    en: "Togepi",
    ko: "토게피",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 176,
    slug: "togetic",
    en: "Togetic",
    ko: "토게틱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 177,
    slug: "natu",
    en: "Natu",
    ko: "네이티",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 178,
    slug: "xatu",
    en: "Xatu",
    ko: "네이티오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 179,
    slug: "mareep",
    en: "Mareep",
    ko: "메리프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 180,
    slug: "flaaffy",
    en: "Flaaffy",
    ko: "보송송",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 181,
    slug: "ampharos",
    en: "Ampharos",
    ko: "전룡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 181,
    slug: "mega-ampharos",
    en: "Mega Ampharos",
    ko: "메가전룡",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 182,
    slug: "bellossom",
    en: "Bellossom",
    ko: "아르코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 183,
    slug: "marill",
    en: "Marill",
    ko: "마릴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 184,
    slug: "azumarill",
    en: "Azumarill",
    ko: "마릴리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 185,
    slug: "sudowoodo",
    en: "Sudowoodo",
    ko: "꼬지모",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 186,
    slug: "politoed",
    en: "Politoed",
    ko: "왕구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 187,
    slug: "hoppip",
    en: "Hoppip",
    ko: "통통코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 188,
    slug: "skiploom",
    en: "Skiploom",
    ko: "두코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 189,
    slug: "jumpluff",
    en: "Jumpluff",
    ko: "솜솜코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 190,
    slug: "aipom",
    en: "Aipom",
    ko: "에이팜",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 191,
    slug: "sunkern",
    en: "Sunkern",
    ko: "해너츠",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 192,
    slug: "sunflora",
    en: "Sunflora",
    ko: "해루미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 193,
    slug: "yanma",
    en: "Yanma",
    ko: "왕자리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 194,
    slug: "wooper",
    en: "Wooper",
    ko: "우파",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 194,
    slug: "wooper-paldean",
    en: "Wooper (Paldean)",
    ko: "우파 (팔데아)",
    category: "paldea",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 195,
    slug: "quagsire",
    en: "Quagsire",
    ko: "누오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 196,
    slug: "espeon",
    en: "Espeon",
    ko: "에브이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 197,
    slug: "umbreon",
    en: "Umbreon",
    ko: "블래키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 198,
    slug: "murkrow",
    en: "Murkrow",
    ko: "니로우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 199,
    slug: "slowking",
    en: "Slowking",
    ko: "야도킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 199,
    slug: "slowking-galarian",
    en: "Slowking (Galarian)",
    ko: "야도킹 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 200,
    slug: "misdreavus",
    en: "Misdreavus",
    ko: "무우마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 201,
    slug: "unown",
    en: "Unown",
    ko: "안농",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 202,
    slug: "wobbuffet",
    en: "Wobbuffet",
    ko: "마자용",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 203,
    slug: "girafarig",
    en: "Girafarig",
    ko: "키링키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 204,
    slug: "pineco",
    en: "Pineco",
    ko: "피콘",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 205,
    slug: "forretress",
    en: "Forretress",
    ko: "쏘콘",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 206,
    slug: "dunsparce",
    en: "Dunsparce",
    ko: "노고치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 207,
    slug: "gligar",
    en: "Gligar",
    ko: "글라이거",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 208,
    slug: "steelix",
    en: "Steelix",
    ko: "강철톤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 208,
    slug: "mega-steelix",
    en: "Mega Steelix",
    ko: "메가강철톤",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 209,
    slug: "snubbull",
    en: "Snubbull",
    ko: "블루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 210,
    slug: "granbull",
    en: "Granbull",
    ko: "그랑블루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 211,
    slug: "qwilfish",
    en: "Qwilfish",
    ko: "침바루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 211,
    slug: "qwilfish-hisuian",
    en: "Qwilfish (Hisuian)",
    ko: "침바루 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 212,
    slug: "scizor",
    en: "Scizor",
    ko: "핫삼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 212,
    slug: "mega-scizor",
    en: "Mega Scizor",
    ko: "메가핫삼",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 213,
    slug: "shuckle",
    en: "Shuckle",
    ko: "단단지",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 214,
    slug: "heracross",
    en: "Heracross",
    ko: "헤라크로스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 214,
    slug: "mega-heracross",
    en: "Mega Heracross",
    ko: "메가헤라크로스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 215,
    slug: "sneasel",
    en: "Sneasel",
    ko: "포푸니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 215,
    slug: "sneasel-hisuian",
    en: "Sneasel (Hisuian)",
    ko: "포푸니 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 216,
    slug: "teddiursa",
    en: "Teddiursa",
    ko: "깜지곰",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 217,
    slug: "ursaring",
    en: "Ursaring",
    ko: "링곰",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 218,
    slug: "slugma",
    en: "Slugma",
    ko: "마그마그",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 219,
    slug: "magcargo",
    en: "Magcargo",
    ko: "마그카르고",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 220,
    slug: "swinub",
    en: "Swinub",
    ko: "꾸꾸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 221,
    slug: "piloswine",
    en: "Piloswine",
    ko: "메꾸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 222,
    slug: "corsola",
    en: "Corsola",
    ko: "코산호",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 222,
    slug: "corsola-galarian",
    en: "Corsola (Galarian)",
    ko: "코산호 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 223,
    slug: "remoraid",
    en: "Remoraid",
    ko: "총어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 224,
    slug: "octillery",
    en: "Octillery",
    ko: "대포무노",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 225,
    slug: "delibird",
    en: "Delibird",
    ko: "딜리버드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 226,
    slug: "mantine",
    en: "Mantine",
    ko: "만타인",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 227,
    slug: "skarmory",
    en: "Skarmory",
    ko: "무장조",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 227,
    slug: "mega-skarmory",
    en: "Mega Skarmory",
    ko: "메가무장조",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 228,
    slug: "houndour",
    en: "Houndour",
    ko: "델빌",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 229,
    slug: "houndoom",
    en: "Houndoom",
    ko: "헬가",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 229,
    slug: "mega-houndoom",
    en: "Mega Houndoom",
    ko: "메가헬가",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 230,
    slug: "kingdra",
    en: "Kingdra",
    ko: "킹드라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 231,
    slug: "phanpy",
    en: "Phanpy",
    ko: "코코리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 232,
    slug: "donphan",
    en: "Donphan",
    ko: "코리갑",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 233,
    slug: "porygon2",
    en: "Porygon2",
    ko: "폴리곤2",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 234,
    slug: "stantler",
    en: "Stantler",
    ko: "노라키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 235,
    slug: "smeargle",
    en: "Smeargle",
    ko: "루브도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 236,
    slug: "tyrogue",
    en: "Tyrogue",
    ko: "배루키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 237,
    slug: "hitmontop",
    en: "Hitmontop",
    ko: "카포에라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 238,
    slug: "smoochum",
    en: "Smoochum",
    ko: "뽀뽀라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 239,
    slug: "elekid",
    en: "Elekid",
    ko: "에레키드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 240,
    slug: "magby",
    en: "Magby",
    ko: "마그비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 241,
    slug: "miltank",
    en: "Miltank",
    ko: "밀탱크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 242,
    slug: "blissey",
    en: "Blissey",
    ko: "해피너스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 243,
    slug: "raikou",
    en: "Raikou",
    ko: "라이코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 244,
    slug: "entei",
    en: "Entei",
    ko: "앤테이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 245,
    slug: "suicune",
    en: "Suicune",
    ko: "스이쿤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 246,
    slug: "larvitar",
    en: "Larvitar",
    ko: "애버라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 247,
    slug: "pupitar",
    en: "Pupitar",
    ko: "데기라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 248,
    slug: "tyranitar",
    en: "Tyranitar",
    ko: "마기라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 248,
    slug: "mega-tyranitar",
    en: "Mega Tyranitar",
    ko: "메가마기라스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 249,
    slug: "lugia",
    en: "Lugia",
    ko: "루기아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 250,
    slug: "ho-oh",
    en: "Ho-Oh",
    ko: "칠색조",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 251,
    slug: "celebi",
    en: "Celebi",
    ko: "세레비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 252,
    slug: "treecko",
    en: "Treecko",
    ko: "나무지기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 253,
    slug: "grovyle",
    en: "Grovyle",
    ko: "나무돌이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 254,
    slug: "sceptile",
    en: "Sceptile",
    ko: "나무킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 254,
    slug: "mega-sceptile",
    en: "Mega Sceptile",
    ko: "메가나무킹",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 255,
    slug: "torchic",
    en: "Torchic",
    ko: "아차모",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 256,
    slug: "combusken",
    en: "Combusken",
    ko: "영치코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 257,
    slug: "blaziken",
    en: "Blaziken",
    ko: "번치코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 257,
    slug: "mega-blaziken",
    en: "Mega Blaziken",
    ko: "메가번치코",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 258,
    slug: "mudkip",
    en: "Mudkip",
    ko: "물짱이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 259,
    slug: "marshtomp",
    en: "Marshtomp",
    ko: "늪짱이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 260,
    slug: "swampert",
    en: "Swampert",
    ko: "대짱이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 260,
    slug: "mega-swampert",
    en: "Mega Swampert",
    ko: "메가대짱이",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 261,
    slug: "poochyena",
    en: "Poochyena",
    ko: "포챠나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 262,
    slug: "mightyena",
    en: "Mightyena",
    ko: "그라에나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 263,
    slug: "zigzagoon",
    en: "Zigzagoon",
    ko: "지그제구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 263,
    slug: "zigzagoon-galarian",
    en: "Zigzagoon (Galarian)",
    ko: "지그제구리 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 264,
    slug: "linoone",
    en: "Linoone",
    ko: "직구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 264,
    slug: "linoone-galarian",
    en: "Linoone (Galarian)",
    ko: "직구리 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 265,
    slug: "wurmple",
    en: "Wurmple",
    ko: "개무소",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 266,
    slug: "silcoon",
    en: "Silcoon",
    ko: "실쿤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 267,
    slug: "beautifly",
    en: "Beautifly",
    ko: "뷰티플라이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 268,
    slug: "cascoon",
    en: "Cascoon",
    ko: "카스쿤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 269,
    slug: "dustox",
    en: "Dustox",
    ko: "독케일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 270,
    slug: "lotad",
    en: "Lotad",
    ko: "연꽃몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 271,
    slug: "lombre",
    en: "Lombre",
    ko: "로토스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 272,
    slug: "ludicolo",
    en: "Ludicolo",
    ko: "로파파",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 273,
    slug: "seedot",
    en: "Seedot",
    ko: "도토링",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 274,
    slug: "nuzleaf",
    en: "Nuzleaf",
    ko: "잎새코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 275,
    slug: "shiftry",
    en: "Shiftry",
    ko: "다탱구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 276,
    slug: "taillow",
    en: "Taillow",
    ko: "테일로",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 277,
    slug: "swellow",
    en: "Swellow",
    ko: "스왈로",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 278,
    slug: "wingull",
    en: "Wingull",
    ko: "갈모매",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 279,
    slug: "pelipper",
    en: "Pelipper",
    ko: "패리퍼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 280,
    slug: "ralts",
    en: "Ralts",
    ko: "랄토스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 281,
    slug: "kirlia",
    en: "Kirlia",
    ko: "킬리아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 282,
    slug: "gardevoir",
    en: "Gardevoir",
    ko: "가디안",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 282,
    slug: "mega-gardevoir",
    en: "Mega Gardevoir",
    ko: "메가가디안",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 283,
    slug: "surskit",
    en: "Surskit",
    ko: "비구술",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 284,
    slug: "masquerain",
    en: "Masquerain",
    ko: "비나방",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 285,
    slug: "shroomish",
    en: "Shroomish",
    ko: "버섯꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 286,
    slug: "breloom",
    en: "Breloom",
    ko: "버섯모",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 287,
    slug: "slakoth",
    en: "Slakoth",
    ko: "게을로",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 288,
    slug: "vigoroth",
    en: "Vigoroth",
    ko: "발바로",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 289,
    slug: "slaking",
    en: "Slaking",
    ko: "게을킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 290,
    slug: "nincada",
    en: "Nincada",
    ko: "토중몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 291,
    slug: "ninjask",
    en: "Ninjask",
    ko: "아이스크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 292,
    slug: "shedinja",
    en: "Shedinja",
    ko: "껍질몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 293,
    slug: "whismur",
    en: "Whismur",
    ko: "소곤룡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 294,
    slug: "loudred",
    en: "Loudred",
    ko: "노공룡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 295,
    slug: "exploud",
    en: "Exploud",
    ko: "폭음룡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 296,
    slug: "makuhita",
    en: "Makuhita",
    ko: "마크탕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 297,
    slug: "hariyama",
    en: "Hariyama",
    ko: "하리뭉",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 298,
    slug: "azurill",
    en: "Azurill",
    ko: "루리리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 299,
    slug: "nosepass",
    en: "Nosepass",
    ko: "코코파스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 300,
    slug: "skitty",
    en: "Skitty",
    ko: "에나비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 301,
    slug: "delcatty",
    en: "Delcatty",
    ko: "델케티",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 302,
    slug: "sableye",
    en: "Sableye",
    ko: "깜까미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 302,
    slug: "mega-sableye",
    en: "Mega Sableye",
    ko: "메가깜까미",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 303,
    slug: "mawile",
    en: "Mawile",
    ko: "입치트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 303,
    slug: "mega-mawile",
    en: "Mega Mawile",
    ko: "메가입치트",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 304,
    slug: "aron",
    en: "Aron",
    ko: "가보리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 305,
    slug: "lairon",
    en: "Lairon",
    ko: "갱도라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 306,
    slug: "aggron",
    en: "Aggron",
    ko: "보스로라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 306,
    slug: "mega-aggron",
    en: "Mega Aggron",
    ko: "메가보스로라",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 307,
    slug: "meditite",
    en: "Meditite",
    ko: "요가랑",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 308,
    slug: "medicham",
    en: "Medicham",
    ko: "요가램",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 308,
    slug: "mega-medicham",
    en: "Mega Medicham",
    ko: "메가요가램",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 309,
    slug: "electrike",
    en: "Electrike",
    ko: "썬더라이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 310,
    slug: "manectric",
    en: "Manectric",
    ko: "썬더볼트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 310,
    slug: "mega-manectric",
    en: "Mega Manectric",
    ko: "메가썬더볼트",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 311,
    slug: "plusle",
    en: "Plusle",
    ko: "플러시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 312,
    slug: "minun",
    en: "Minun",
    ko: "마이농",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 313,
    slug: "volbeat",
    en: "Volbeat",
    ko: "볼비트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 314,
    slug: "illumise",
    en: "Illumise",
    ko: "네오비트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 315,
    slug: "roselia",
    en: "Roselia",
    ko: "로젤리아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 316,
    slug: "gulpin",
    en: "Gulpin",
    ko: "꼴깍몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 317,
    slug: "swalot",
    en: "Swalot",
    ko: "꿀꺽몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 318,
    slug: "carvanha",
    en: "Carvanha",
    ko: "샤프니아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 319,
    slug: "sharpedo",
    en: "Sharpedo",
    ko: "샤크니아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 319,
    slug: "mega-sharpedo",
    en: "Mega Sharpedo",
    ko: "메가샤크니아",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 320,
    slug: "wailmer",
    en: "Wailmer",
    ko: "고래왕자",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 321,
    slug: "wailord",
    en: "Wailord",
    ko: "고래왕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 322,
    slug: "numel",
    en: "Numel",
    ko: "둔타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 323,
    slug: "camerupt",
    en: "Camerupt",
    ko: "폭타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 323,
    slug: "mega-camerupt",
    en: "Mega Camerupt",
    ko: "메가폭타",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 324,
    slug: "torkoal",
    en: "Torkoal",
    ko: "코터스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 325,
    slug: "spoink",
    en: "Spoink",
    ko: "피그점프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 326,
    slug: "grumpig",
    en: "Grumpig",
    ko: "피그킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 327,
    slug: "spinda",
    en: "Spinda",
    ko: "얼루기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 328,
    slug: "trapinch",
    en: "Trapinch",
    ko: "톱치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 329,
    slug: "vibrava",
    en: "Vibrava",
    ko: "비브라바",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 330,
    slug: "flygon",
    en: "Flygon",
    ko: "플라이곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 331,
    slug: "cacnea",
    en: "Cacnea",
    ko: "선인왕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 332,
    slug: "cacturne",
    en: "Cacturne",
    ko: "밤선인",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 333,
    slug: "swablu",
    en: "Swablu",
    ko: "파비코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 334,
    slug: "altaria",
    en: "Altaria",
    ko: "파비코리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 334,
    slug: "mega-altaria",
    en: "Mega Altaria",
    ko: "메가파비코리",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 335,
    slug: "zangoose",
    en: "Zangoose",
    ko: "쟝고",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 336,
    slug: "seviper",
    en: "Seviper",
    ko: "세비퍼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 337,
    slug: "lunatone",
    en: "Lunatone",
    ko: "루나톤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 338,
    slug: "solrock",
    en: "Solrock",
    ko: "솔록",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 339,
    slug: "barboach",
    en: "Barboach",
    ko: "미꾸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 340,
    slug: "whiscash",
    en: "Whiscash",
    ko: "메깅",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 341,
    slug: "corphish",
    en: "Corphish",
    ko: "가재군",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 342,
    slug: "crawdaunt",
    en: "Crawdaunt",
    ko: "가재장군",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 343,
    slug: "baltoy",
    en: "Baltoy",
    ko: "오뚝군",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 344,
    slug: "claydol",
    en: "Claydol",
    ko: "점토도리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 345,
    slug: "lileep",
    en: "Lileep",
    ko: "릴링",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 346,
    slug: "cradily",
    en: "Cradily",
    ko: "릴리요",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 347,
    slug: "anorith",
    en: "Anorith",
    ko: "아노딥스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 348,
    slug: "armaldo",
    en: "Armaldo",
    ko: "아말도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 349,
    slug: "feebas",
    en: "Feebas",
    ko: "빈티나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 350,
    slug: "milotic",
    en: "Milotic",
    ko: "밀로틱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 351,
    slug: "castform",
    en: "Castform",
    ko: "캐스퐁",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 352,
    slug: "kecleon",
    en: "Kecleon",
    ko: "켈리몬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 353,
    slug: "shuppet",
    en: "Shuppet",
    ko: "어둠대신",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 354,
    slug: "banette",
    en: "Banette",
    ko: "다크펫",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 354,
    slug: "mega-banette",
    en: "Mega Banette",
    ko: "메가다크펫",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 355,
    slug: "duskull",
    en: "Duskull",
    ko: "해골몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 356,
    slug: "dusclops",
    en: "Dusclops",
    ko: "미라몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 357,
    slug: "tropius",
    en: "Tropius",
    ko: "트로피우스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 358,
    slug: "chimecho",
    en: "Chimecho",
    ko: "치렁",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 358,
    slug: "mega-chimecho",
    en: "Meega Chimecho",
    ko: "메가치렁",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 359,
    slug: "absol",
    en: "Absol",
    ko: "앱솔",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 359,
    slug: "mega-absol",
    en: "Mega Absol",
    ko: "메가앱솔",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 359,
    slug: "mega-absol-z",
    en: "Mega Absol Z",
    ko: "메가앱솔Z",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 360,
    slug: "wynaut",
    en: "Wynaut",
    ko: "마자",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 361,
    slug: "snorunt",
    en: "Snorunt",
    ko: "눈꼬마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 362,
    slug: "glalie",
    en: "Glalie",
    ko: "얼음귀신",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 362,
    slug: "mega-glalie",
    en: "Mega Glalie",
    ko: "메가얼음귀신",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 363,
    slug: "spheal",
    en: "Spheal",
    ko: "대굴레오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 364,
    slug: "sealeo",
    en: "Sealeo",
    ko: "씨레오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 365,
    slug: "walrein",
    en: "Walrein",
    ko: "씨카이저",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 366,
    slug: "clamperl",
    en: "Clamperl",
    ko: "진주몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 367,
    slug: "huntail",
    en: "Huntail",
    ko: "헌테일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 368,
    slug: "gorebyss",
    en: "Gorebyss",
    ko: "분홍장이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 369,
    slug: "relicanth",
    en: "Relicanth",
    ko: "시라칸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 370,
    slug: "luvdisc",
    en: "Luvdisc",
    ko: "사랑동이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 371,
    slug: "bagon",
    en: "Bagon",
    ko: "아공이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 372,
    slug: "shelgon",
    en: "Shelgon",
    ko: "쉘곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 373,
    slug: "salamence",
    en: "Salamence",
    ko: "보만다",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 373,
    slug: "mega-salamence",
    en: "Mega Salamence",
    ko: "메가보만다",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 374,
    slug: "beldum",
    en: "Beldum",
    ko: "메탕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 375,
    slug: "metang",
    en: "Metang",
    ko: "메탕구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 376,
    slug: "metagross",
    en: "Metagross",
    ko: "메타그로스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 376,
    slug: "mega-metagross",
    en: "Mega Metagross",
    ko: "메가메타그로스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 377,
    slug: "regirock",
    en: "Regirock",
    ko: "레지락",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 378,
    slug: "regice",
    en: "Regice",
    ko: "레지아이스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 379,
    slug: "registeel",
    en: "Registeel",
    ko: "레지스틸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 380,
    slug: "latias",
    en: "Latias",
    ko: "라티아스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 380,
    slug: "mega-latias",
    en: "Mega Latias",
    ko: "메가라티아스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 381,
    slug: "latios",
    en: "Latios",
    ko: "라티오스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 381,
    slug: "mega-latios",
    en: "Mega Latios",
    ko: "메가라티오스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 382,
    slug: "kyogre",
    en: "Kyogre",
    ko: "가이오가",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 382,
    slug: "primal-kyogre",
    en: "Primal Kyogre",
    ko: "원시가이오가",
    category: "primal",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 383,
    slug: "groudon",
    en: "Groudon",
    ko: "그란돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 383,
    slug: "primal-groudon",
    en: "Primal Groudon",
    ko: "원시그란돈",
    category: "primal",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 384,
    slug: "rayquaza",
    en: "Rayquaza",
    ko: "레쿠쟈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 384,
    slug: "mega-rayquaza",
    en: "Mega Rayquaza",
    ko: "메가레쿠쟈",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 385,
    slug: "jirachi",
    en: "Jirachi",
    ko: "지라치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 386,
    slug: "deoxys",
    en: "Deoxys",
    ko: "테오키스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 386,
    slug: "deoxys-attack-forme",
    en: "Deoxys (Attack Forme)",
    ko: "테오키스(어택폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 386,
    slug: "deoxys-defense-forme",
    en: "Deoxys (Defense Forme)",
    ko: "테오키스(디펜스폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 386,
    slug: "deoxys-speed-forme",
    en: "Deoxys (Speed Forme)",
    ko: "테오키스(스피드폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 387,
    slug: "turtwig",
    en: "Turtwig",
    ko: "모부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 388,
    slug: "grotle",
    en: "Grotle",
    ko: "수풀부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 389,
    slug: "torterra",
    en: "Torterra",
    ko: "토대부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 390,
    slug: "chimchar",
    en: "Chimchar",
    ko: "불꽃숭이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 391,
    slug: "monferno",
    en: "Monferno",
    ko: "파이숭이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 392,
    slug: "infernape",
    en: "Infernape",
    ko: "초염몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 393,
    slug: "piplup",
    en: "Piplup",
    ko: "팽도리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 394,
    slug: "prinplup",
    en: "Prinplup",
    ko: "팽태자",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 395,
    slug: "empoleon",
    en: "Empoleon",
    ko: "엠페르트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 396,
    slug: "starly",
    en: "Starly",
    ko: "찌르꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 397,
    slug: "staravia",
    en: "Staravia",
    ko: "찌르버드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 398,
    slug: "staraptor",
    en: "Staraptor",
    ko: "찌르호크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 398,
    slug: "mega-staraptor",
    en: "Mega Staraptor",
    ko: "메가찌르호크",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 399,
    slug: "bidoof",
    en: "Bidoof",
    ko: "비버니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 400,
    slug: "bibarel",
    en: "Bibarel",
    ko: "비버통",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 401,
    slug: "kricketot",
    en: "Kricketot",
    ko: "귀뚤뚜기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 402,
    slug: "kricketune",
    en: "Kricketune",
    ko: "귀뚤톡크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 403,
    slug: "shinx",
    en: "Shinx",
    ko: "꼬링크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 404,
    slug: "luxio",
    en: "Luxio",
    ko: "럭시오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 405,
    slug: "luxray",
    en: "Luxray",
    ko: "렌트라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 406,
    slug: "budew",
    en: "Budew",
    ko: "꼬몽울",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 407,
    slug: "roserade",
    en: "Roserade",
    ko: "로즈레이드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 408,
    slug: "cranidos",
    en: "Cranidos",
    ko: "두개도스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 409,
    slug: "rampardos",
    en: "Rampardos",
    ko: "램펄드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 410,
    slug: "shieldon",
    en: "Shieldon",
    ko: "방패톱스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 411,
    slug: "bastiodon",
    en: "Bastiodon",
    ko: "바리톱스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 412,
    slug: "burmy-plant-cloak",
    en: "Burmy",
    ko: "도롱충이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 413,
    slug: "wormadam-plant-cloak",
    en: "Wormadam",
    ko: "도롱마담",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 413,
    slug: "wormadam-sandy-cloak",
    en: "Wormadam (Sandy Cloak)",
    ko: "도롱마담(모래땅도롱)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 413,
    slug: "wormadam-trash-cloak",
    en: "Wormadam (Trash Cloak)",
    ko: "도롱마담(슈레도롱)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 414,
    slug: "mothim",
    en: "Mothim",
    ko: "나메일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 415,
    slug: "combee",
    en: "Combee",
    ko: "세꿀버리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 416,
    slug: "vespiquen",
    en: "Vespiquen",
    ko: "비퀸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 417,
    slug: "pachirisu",
    en: "Pachirisu",
    ko: "파치리스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 418,
    slug: "buizel",
    en: "Buizel",
    ko: "브이젤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 419,
    slug: "floatzel",
    en: "Floatzel",
    ko: "플로젤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 420,
    slug: "cherubi",
    en: "Cherubi",
    ko: "체리버",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 421,
    slug: "cherrim",
    en: "Cherrim",
    ko: "체리꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 422,
    slug: "shellos",
    en: "Shellos",
    ko: "깝질무",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 423,
    slug: "gastrodon",
    en: "Gastrodon",
    ko: "트리토돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 424,
    slug: "ambipom",
    en: "Ambipom",
    ko: "겟핸보숭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 425,
    slug: "drifloon",
    en: "Drifloon",
    ko: "흔들풍손",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 426,
    slug: "drifblim",
    en: "Drifblim",
    ko: "둥실라이드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 427,
    slug: "buneary",
    en: "Buneary",
    ko: "이어롤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 428,
    slug: "lopunny",
    en: "Lopunny",
    ko: "이어롭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 428,
    slug: "mega-lopunny",
    en: "Mega Lopunny",
    ko: "메가이어롭",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 429,
    slug: "mismagius",
    en: "Mismagius",
    ko: "무우마직",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 430,
    slug: "honchkrow",
    en: "Honchkrow",
    ko: "돈크로우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 431,
    slug: "glameow",
    en: "Glameow",
    ko: "나옹마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 432,
    slug: "purugly",
    en: "Purugly",
    ko: "몬냥이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 433,
    slug: "chingling",
    en: "Chingling",
    ko: "랑딸랑",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 434,
    slug: "stunky",
    en: "Stunky",
    ko: "스컹뿡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 435,
    slug: "skuntank",
    en: "Skuntank",
    ko: "스컹탱크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 436,
    slug: "bronzor",
    en: "Bronzor",
    ko: "동미러",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 437,
    slug: "bronzong",
    en: "Bronzong",
    ko: "동탁군",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 438,
    slug: "bonsly",
    en: "Bonsly",
    ko: "꼬지지",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 439,
    slug: "mime-jr",
    en: "Mime Jr.",
    ko: "흉내내",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 440,
    slug: "happiny",
    en: "Happiny",
    ko: "핑복",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 441,
    slug: "chatot",
    en: "Chatot",
    ko: "페라페",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 442,
    slug: "spiritomb",
    en: "Spiritomb",
    ko: "화강돌",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 443,
    slug: "gible",
    en: "Gible",
    ko: "딥상어동",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 444,
    slug: "gabite",
    en: "Gabite",
    ko: "한바이트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 445,
    slug: "garchomp",
    en: "Garchomp",
    ko: "한카리아스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 445,
    slug: "mega-garchomp",
    en: "Mega Garchomp",
    ko: "메가한카리아스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 445,
    slug: "mega-garchomp-z",
    en: "Mega Garchomp Z",
    ko: "메가한카리아스Z",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 446,
    slug: "munchlax",
    en: "Munchlax",
    ko: "먹고자",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 447,
    slug: "riolu",
    en: "Riolu",
    ko: "리오르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 448,
    slug: "lucario",
    en: "Lucario",
    ko: "루카리오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 448,
    slug: "mega-lucario",
    en: "Mega Lucario",
    ko: "메가루카리오",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 448,
    slug: "mega-lucario-z",
    en: "Mega Lucario Z",
    ko: "메가루카리오Z",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 449,
    slug: "hippopotas",
    en: "Hippopotas",
    ko: "히포포타스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 450,
    slug: "hippowdon",
    en: "Hippowdon",
    ko: "하마돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 451,
    slug: "skorupi",
    en: "Skorupi",
    ko: "스콜피",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 452,
    slug: "drapion",
    en: "Drapion",
    ko: "드래피온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 453,
    slug: "croagunk",
    en: "Croagunk",
    ko: "삐딱구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 454,
    slug: "toxicroak",
    en: "Toxicroak",
    ko: "독개굴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 455,
    slug: "carnivine",
    en: "Carnivine",
    ko: "무스틈니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 456,
    slug: "finneon",
    en: "Finneon",
    ko: "형광어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 457,
    slug: "lumineon",
    en: "Lumineon",
    ko: "네오라이트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 458,
    slug: "mantyke",
    en: "Mantyke",
    ko: "타만타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 459,
    slug: "snover",
    en: "Snover",
    ko: "눈쓰개",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 460,
    slug: "abomasnow",
    en: "Abomasnow",
    ko: "눈설왕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 460,
    slug: "mega-abomasnow",
    en: "Mega Abomasnow",
    ko: "메가눈설왕",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 461,
    slug: "weavile",
    en: "Weavile",
    ko: "포푸니라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 462,
    slug: "magnezone",
    en: "Magnezone",
    ko: "자포코일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 463,
    slug: "lickilicky",
    en: "Lickilicky",
    ko: "내룸벨트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 464,
    slug: "rhyperior",
    en: "Rhyperior",
    ko: "거대코뿌리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 465,
    slug: "tangrowth",
    en: "Tangrowth",
    ko: "덩쿠림보",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 466,
    slug: "electivire",
    en: "Electivire",
    ko: "에레키블",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 467,
    slug: "magmortar",
    en: "Magmortar",
    ko: "마그마번",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 468,
    slug: "togekiss",
    en: "Togekiss",
    ko: "토게키스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 469,
    slug: "yanmega",
    en: "Yanmega",
    ko: "메가자리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 470,
    slug: "leafeon",
    en: "Leafeon",
    ko: "리피아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 471,
    slug: "glaceon",
    en: "Glaceon",
    ko: "글레이시아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 472,
    slug: "gliscor",
    en: "Gliscor",
    ko: "글라이온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 473,
    slug: "mamoswine",
    en: "Mamoswine",
    ko: "맘모꾸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 474,
    slug: "porygon-z",
    en: "Porygon-Z",
    ko: "폴리곤Z",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 475,
    slug: "gallade",
    en: "Gallade",
    ko: "엘레이드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 475,
    slug: "mega-gallade",
    en: "Mega Gallade",
    ko: "메가엘레이드",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 476,
    slug: "probopass",
    en: "Probopass",
    ko: "대코파스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 477,
    slug: "dusknoir",
    en: "Dusknoir",
    ko: "야느와르몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 478,
    slug: "froslass",
    en: "Froslass",
    ko: "눈여아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 478,
    slug: "mega-froslass",
    en: "Mega Froslass",
    ko: "메가눈여아",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "rotom",
    en: "Rotom",
    ko: "로토무",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 479,
    slug: "fan-rotom",
    en: "Fan Rotom",
    ko: "스핀로토무",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "frost-rotom",
    en: "Frost Rotom",
    ko: "프로스트로토무",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "heat-rotom",
    en: "Heat Rotom",
    ko: "히트로토무",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "mow-rotom",
    en: "Mow Rotom",
    ko: "커트로토무",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "wash-rotom",
    en: "Wash Rotom",
    ko: "워시로토무",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 480,
    slug: "uxie",
    en: "Uxie",
    ko: "유크시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 481,
    slug: "mesprit",
    en: "Mesprit",
    ko: "엠라이트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 482,
    slug: "azelf",
    en: "Azelf",
    ko: "아그놈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 483,
    slug: "dialga",
    en: "Dialga",
    ko: "디아루가",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 484,
    slug: "palkia",
    en: "Palkia",
    ko: "펄기아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 485,
    slug: "heatran",
    en: "Heatran",
    ko: "히드런",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 485,
    slug: "mega-heatran",
    en: "Mega Heatran",
    ko: "메가히드런",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 486,
    slug: "regigigas",
    en: "Regigigas",
    ko: "레지기가스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 487,
    slug: "giratina-another-forme",
    en: "Giratina",
    ko: "기라티나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 487,
    slug: "giratina-origin-forme",
    en: "Giratina (Origin Forme)",
    ko: "기라티나(오리진폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 488,
    slug: "cresselia",
    en: "Cresselia",
    ko: "크레세리아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 489,
    slug: "phione",
    en: "Phione",
    ko: "피오네",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 490,
    slug: "manaphy",
    en: "Manaphy",
    ko: "마나피",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 491,
    slug: "darkrai",
    en: "Darkrai",
    ko: "다크라이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 491,
    slug: "mega-darkrai",
    en: "Mega Darkrai",
    ko: "메가다크라이",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 492,
    slug: "shaymin-land-forme",
    en: "Shaymin",
    ko: "쉐이미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 492,
    slug: "shaymin-sky-forme",
    en: "Shaymin (Sky Forme)",
    ko: "쉐이미(스카이폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 493,
    slug: "arceus",
    en: "Arceus",
    ko: "아르세우스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 494,
    slug: "victini",
    en: "Victini",
    ko: "비크티니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 495,
    slug: "snivy",
    en: "Snivy",
    ko: "주리비얀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 496,
    slug: "servine",
    en: "Servine",
    ko: "샤비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 497,
    slug: "serperior",
    en: "Serperior",
    ko: "샤로다",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 498,
    slug: "tepig",
    en: "Tepig",
    ko: "뚜꾸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 499,
    slug: "pignite",
    en: "Pignite",
    ko: "차오꿀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 500,
    slug: "emboar",
    en: "Emboar",
    ko: "염무왕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 500,
    slug: "mega-emboar",
    en: "Mega Emboar",
    ko: "메가염무왕",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 501,
    slug: "oshawott",
    en: "Oshawott",
    ko: "수댕이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 502,
    slug: "dewott",
    en: "Dewott",
    ko: "쌍검자비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 503,
    slug: "samurott",
    en: "Samurott",
    ko: "대검귀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 503,
    slug: "samurott-hisuian",
    en: "Samurott (Hisuian)",
    ko: "대검귀 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 504,
    slug: "patrat",
    en: "Patrat",
    ko: "보르쥐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 505,
    slug: "watchog",
    en: "Watchog",
    ko: "보르그",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 506,
    slug: "lillipup",
    en: "Lillipup",
    ko: "요테리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 507,
    slug: "herdier",
    en: "Herdier",
    ko: "하데리어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 508,
    slug: "stoutland",
    en: "Stoutland",
    ko: "바랜드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 509,
    slug: "purrloin",
    en: "Purrloin",
    ko: "쌔비냥",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 510,
    slug: "liepard",
    en: "Liepard",
    ko: "레파르다스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 511,
    slug: "pansage",
    en: "Pansage",
    ko: "야나프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 512,
    slug: "simisage",
    en: "Simisage",
    ko: "야나키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 513,
    slug: "pansear",
    en: "Pansear",
    ko: "바오프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 514,
    slug: "simisear",
    en: "Simisear",
    ko: "바오키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 515,
    slug: "panpour",
    en: "Panpour",
    ko: "앗차프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 516,
    slug: "simipour",
    en: "Simipour",
    ko: "앗차키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 517,
    slug: "munna",
    en: "Munna",
    ko: "몽나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 518,
    slug: "musharna",
    en: "Musharna",
    ko: "몽얌나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 519,
    slug: "pidove",
    en: "Pidove",
    ko: "콩둘기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 520,
    slug: "tranquill",
    en: "Tranquill",
    ko: "유토브",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 521,
    slug: "unfezant",
    en: "Unfezant",
    ko: "켄호로우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 522,
    slug: "blitzle",
    en: "Blitzle",
    ko: "줄뮤마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 523,
    slug: "zebstrika",
    en: "Zebstrika",
    ko: "제브라이카",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 524,
    slug: "roggenrola",
    en: "Roggenrola",
    ko: "단굴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 525,
    slug: "boldore",
    en: "Boldore",
    ko: "암트르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 526,
    slug: "gigalith",
    en: "Gigalith",
    ko: "기가이어스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 527,
    slug: "woobat",
    en: "Woobat",
    ko: "또르박쥐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 528,
    slug: "swoobat",
    en: "Swoobat",
    ko: "맘박쥐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 529,
    slug: "drilbur",
    en: "Drilbur",
    ko: "두더류",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 530,
    slug: "excadrill",
    en: "Excadrill",
    ko: "몰드류",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 530,
    slug: "mega-excadrill",
    en: "Mega Excadrill",
    ko: "메가몰드류",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 531,
    slug: "audino",
    en: "Audino",
    ko: "다부니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 531,
    slug: "mega-audino",
    en: "Mega Audino",
    ko: "메가다부니",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 532,
    slug: "timburr",
    en: "Timburr",
    ko: "으랏차",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 533,
    slug: "gurdurr",
    en: "Gurdurr",
    ko: "토쇠골",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 534,
    slug: "conkeldurr",
    en: "Conkeldurr",
    ko: "노보청",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 535,
    slug: "tympole",
    en: "Tympole",
    ko: "동챙이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 536,
    slug: "palpitoad",
    en: "Palpitoad",
    ko: "두까비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 537,
    slug: "seismitoad",
    en: "Seismitoad",
    ko: "두빅굴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 538,
    slug: "throh",
    en: "Throh",
    ko: "던지미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 539,
    slug: "sawk",
    en: "Sawk",
    ko: "타격귀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 540,
    slug: "sewaddle",
    en: "Sewaddle",
    ko: "두르보",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 541,
    slug: "swadloon",
    en: "Swadloon",
    ko: "두르쿤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 542,
    slug: "leavanny",
    en: "Leavanny",
    ko: "모아머",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 543,
    slug: "venipede",
    en: "Venipede",
    ko: "마디네",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 544,
    slug: "whirlipede",
    en: "Whirlipede",
    ko: "휠구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 545,
    slug: "scolipede",
    en: "Scolipede",
    ko: "펜드라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 545,
    slug: "mega-scolipede",
    en: "Mega Scolipede",
    ko: "메가펜드라",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 546,
    slug: "cottonee",
    en: "Cottonee",
    ko: "소미안",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 547,
    slug: "whimsicott",
    en: "Whimsicott",
    ko: "엘풍",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 548,
    slug: "petilil",
    en: "Petilil",
    ko: "치릴리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 549,
    slug: "lilligant",
    en: "Lilligant",
    ko: "드레디어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 549,
    slug: "lilligant-hisuian",
    en: "Lilligant (Hisuian)",
    ko: "드레디어 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 550,
    slug: "basculin-red-striped",
    en: "Basculin",
    ko: "배쓰나이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 551,
    slug: "sandile",
    en: "Sandile",
    ko: "깜눈크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 552,
    slug: "krokorok",
    en: "Krokorok",
    ko: "악비르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 553,
    slug: "krookodile",
    en: "Krookodile",
    ko: "악비아르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 554,
    slug: "darumaka",
    en: "Darumaka",
    ko: "달막화",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 554,
    slug: "darumaka-galarian",
    en: "Darumaka (Galarian)",
    ko: "달막화 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 555,
    slug: "darmanitan",
    en: "Darmanitan",
    ko: "불비달마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 555,
    slug: "darmanitan-galarian",
    en: "Darmanitan (Galarian)",
    ko: "불비달마 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 556,
    slug: "maractus",
    en: "Maractus",
    ko: "마라카치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 557,
    slug: "dwebble",
    en: "Dwebble",
    ko: "돌살이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 558,
    slug: "crustle",
    en: "Crustle",
    ko: "암팰리스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 559,
    slug: "scraggy",
    en: "Scraggy",
    ko: "곤율랭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 560,
    slug: "scrafty",
    en: "Scrafty",
    ko: "곤율거니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 560,
    slug: "mega-scrafty",
    en: "Mega Scrafty",
    ko: "메가곤율거니",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 561,
    slug: "sigilyph",
    en: "Sigilyph",
    ko: "심보러",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 562,
    slug: "yamask",
    en: "Yamask",
    ko: "데스마스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 562,
    slug: "yamask-galarian",
    en: "Yamask (Galarian)",
    ko: "데스마스 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 563,
    slug: "cofagrigus",
    en: "Cofagrigus",
    ko: "데스니칸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 564,
    slug: "tirtouga",
    en: "Tirtouga",
    ko: "프로토가",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 565,
    slug: "carracosta",
    en: "Carracosta",
    ko: "늑골라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 566,
    slug: "archen",
    en: "Archen",
    ko: "아켄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 567,
    slug: "archeops",
    en: "Archeops",
    ko: "아케오스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 568,
    slug: "trubbish",
    en: "Trubbish",
    ko: "깨봉이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 569,
    slug: "garbodor",
    en: "Garbodor",
    ko: "더스트나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 569,
    slug: "garbodor-gigantamax",
    en: "Garbodor (G)",
    ko: "더스트나 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 570,
    slug: "zorua",
    en: "Zorua",
    ko: "조로아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 570,
    slug: "zorua-hisuian",
    en: "Zorua (Hisuian)",
    ko: "조로아 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 571,
    slug: "zoroark",
    en: "Zoroark",
    ko: "조로아크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 571,
    slug: "zoroark-hisuian",
    en: "Zoroark (Hisuian)",
    ko: "조로아크 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 572,
    slug: "minccino",
    en: "Minccino",
    ko: "치라미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 573,
    slug: "cinccino",
    en: "Cinccino",
    ko: "치라치노",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 574,
    slug: "gothita",
    en: "Gothita",
    ko: "고디탱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 575,
    slug: "gothorita",
    en: "Gothorita",
    ko: "고디보미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 576,
    slug: "gothitelle",
    en: "Gothitelle",
    ko: "고디모아젤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 577,
    slug: "solosis",
    en: "Solosis",
    ko: "유니란",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 578,
    slug: "duosion",
    en: "Duosion",
    ko: "듀란",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 579,
    slug: "reuniclus",
    en: "Reuniclus",
    ko: "란쿨루스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 580,
    slug: "ducklett",
    en: "Ducklett",
    ko: "꼬지보리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 581,
    slug: "swanna",
    en: "Swanna",
    ko: "스완나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 582,
    slug: "vanillite",
    en: "Vanillite",
    ko: "바닐프티",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 583,
    slug: "vanillish",
    en: "Vanillish",
    ko: "바닐리치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 584,
    slug: "vanilluxe",
    en: "Vanilluxe",
    ko: "배바닐라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 585,
    slug: "deerling",
    en: "Deerling",
    ko: "사철록",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 586,
    slug: "sawsbuck",
    en: "Sawsbuck",
    ko: "바라철록",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 587,
    slug: "emolga",
    en: "Emolga",
    ko: "에몽가",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 588,
    slug: "karrablast",
    en: "Karrablast",
    ko: "딱정곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 589,
    slug: "escavalier",
    en: "Escavalier",
    ko: "슈바르고",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 590,
    slug: "foongus",
    en: "Foongus",
    ko: "깜놀버슬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 591,
    slug: "amoonguss",
    en: "Amoonguss",
    ko: "뽀록나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 592,
    slug: "frillish",
    en: "Frillish",
    ko: "탱그릴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 593,
    slug: "jellicent",
    en: "Jellicent",
    ko: "탱탱겔",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 594,
    slug: "alomomola",
    en: "Alomomola",
    ko: "맘복치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 595,
    slug: "joltik",
    en: "Joltik",
    ko: "파쪼옥",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 596,
    slug: "galvantula",
    en: "Galvantula",
    ko: "전툴라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 597,
    slug: "ferroseed",
    en: "Ferroseed",
    ko: "철시드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 598,
    slug: "ferrothorn",
    en: "Ferrothorn",
    ko: "너트령",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 599,
    slug: "klink",
    en: "Klink",
    ko: "기어르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 600,
    slug: "klang",
    en: "Klang",
    ko: "기기어르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 601,
    slug: "klinklang",
    en: "Klinklang",
    ko: "기기기어르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 602,
    slug: "tynamo",
    en: "Tynamo",
    ko: "저리어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 603,
    slug: "eelektrik",
    en: "Eelektrik",
    ko: "저리릴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 604,
    slug: "eelektross",
    en: "Eelektross",
    ko: "저리더프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 604,
    slug: "mega-eelektross",
    en: "Mega Eelektross",
    ko: "메가저리더프",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 605,
    slug: "elgyem",
    en: "Elgyem",
    ko: "리그레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 606,
    slug: "beheeyem",
    en: "Beheeyem",
    ko: "벰크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 607,
    slug: "litwick",
    en: "Litwick",
    ko: "불켜미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 608,
    slug: "lampent",
    en: "Lampent",
    ko: "램프라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 609,
    slug: "chandelure",
    en: "Chandelure",
    ko: "샹델라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 609,
    slug: "mega-chandelure",
    en: "Mega Chandelure",
    ko: "메가샹델라",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 610,
    slug: "axew",
    en: "Axew",
    ko: "터검니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 611,
    slug: "fraxure",
    en: "Fraxure",
    ko: "액슨도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 612,
    slug: "haxorus",
    en: "Haxorus",
    ko: "액스라이즈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 613,
    slug: "cubchoo",
    en: "Cubchoo",
    ko: "코고미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 614,
    slug: "beartic",
    en: "Beartic",
    ko: "툰베어",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 615,
    slug: "cryogonal",
    en: "Cryogonal",
    ko: "프리지오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 616,
    slug: "shelmet",
    en: "Shelmet",
    ko: "쪼마리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 617,
    slug: "accelgor",
    en: "Accelgor",
    ko: "어지리더",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 618,
    slug: "stunfisk",
    en: "Stunfisk",
    ko: "메더",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 618,
    slug: "stunfisk-galarian",
    en: "Stunfisk (Galarian)",
    ko: "메더 (가라르)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 619,
    slug: "mienfoo",
    en: "Mienfoo",
    ko: "비조푸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 620,
    slug: "mienshao",
    en: "Mienshao",
    ko: "비조도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 621,
    slug: "druddigon",
    en: "Druddigon",
    ko: "크리만",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 622,
    slug: "golett",
    en: "Golett",
    ko: "골비람",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 623,
    slug: "golurk",
    en: "Golurk",
    ko: "골루그",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 623,
    slug: "mega-golurk",
    en: "Mega Golurk",
    ko: "메가골루그",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 624,
    slug: "pawniard",
    en: "Pawniard",
    ko: "자망칼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 625,
    slug: "bisharp",
    en: "Bisharp",
    ko: "절각참",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 626,
    slug: "bouffalant",
    en: "Bouffalant",
    ko: "버프론",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 627,
    slug: "rufflet",
    en: "Rufflet",
    ko: "수리둥보",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 628,
    slug: "braviary",
    en: "Braviary",
    ko: "워글",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 628,
    slug: "braviaryhisuian",
    en: "Braviary (Hisuian)",
    ko: "워글 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 629,
    slug: "vullaby",
    en: "Vullaby",
    ko: "벌차이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 630,
    slug: "mandibuzz",
    en: "Mandibuzz",
    ko: "버랜지나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 631,
    slug: "heatmor",
    en: "Heatmor",
    ko: "앤티골",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 632,
    slug: "durant",
    en: "Durant",
    ko: "아이앤트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 633,
    slug: "deino",
    en: "Deino",
    ko: "모노두",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 634,
    slug: "zweilous",
    en: "Zweilous",
    ko: "디헤드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 635,
    slug: "hydreigon",
    en: "Hydreigon",
    ko: "삼삼드래",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 636,
    slug: "larvesta",
    en: "Larvesta",
    ko: "활화르바",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 637,
    slug: "volcarona",
    en: "Volcarona",
    ko: "불카모스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 638,
    slug: "cobalion",
    en: "Cobalion",
    ko: "코바르온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 639,
    slug: "terrakion",
    en: "Terrakion",
    ko: "테라키온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 640,
    slug: "virizion",
    en: "Virizion",
    ko: "비리디온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 641,
    slug: "tornadus-incarnate",
    en: "Tornadus",
    ko: "토네로스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 641,
    slug: "tornadus-therian",
    en: "Tornadus (Therian)",
    ko: "토네로스(영물폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 642,
    slug: "thundurus-incarnate",
    en: "Thundurus",
    ko: "볼트로스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 642,
    slug: "thundurus-therian",
    en: "Thundurus (Therian)",
    ko: "볼트로스(영물폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 643,
    slug: "reshiram",
    en: "Reshiram",
    ko: "레시라무",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 644,
    slug: "zekrom",
    en: "Zekrom",
    ko: "제크로무",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 645,
    slug: "landorus-incarnate",
    en: "Landorus",
    ko: "랜드로스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 645,
    slug: "landorus-therian",
    en: "Landorus (Therian)",
    ko: "랜드로스(영물폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 646,
    slug: "black-kyurem",
    en: "Black Kyurem",
    ko: "블랙큐레무",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 646,
    slug: "kyurem",
    en: "Kyurem",
    ko: "큐레무",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 646,
    slug: "white-kyurem",
    en: "White Kyurem",
    ko: "화이트큐레무",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 647,
    slug: "keldeo",
    en: "Keldeo",
    ko: "케르디오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 648,
    slug: "meloetta-aria",
    en: "Meloetta",
    ko: "메로엣타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 648,
    slug: "meloetta-pirouette",
    en: "Meloetta (Pirouette)",
    ko: "메로엣타(스텝폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 649,
    slug: "genesect",
    en: "Genesect",
    ko: "게노세크트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 650,
    slug: "chespin",
    en: "Chespin",
    ko: "도치마론",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 651,
    slug: "quilladin",
    en: "Quilladin",
    ko: "도치보구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 652,
    slug: "chesnaught",
    en: "Chesnaught",
    ko: "브리가론",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 652,
    slug: "mega-chesnaught",
    en: "Mega Chesnaught",
    ko: "메가브리가론",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 653,
    slug: "fennekin",
    en: "Fennekin",
    ko: "푸호꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 654,
    slug: "braixen",
    en: "Braixen",
    ko: "테르나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 655,
    slug: "delphox",
    en: "Delphox",
    ko: "마폭시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 655,
    slug: "mega-delphox",
    en: "Mega Delphox",
    ko: "메가마폭시",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 656,
    slug: "froakie",
    en: "Froakie",
    ko: "개구마르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 657,
    slug: "frogadier",
    en: "Frogadier",
    ko: "개굴반장",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 658,
    slug: "ash-greninja",
    en: "Ash-Greninja",
    ko: "지우개굴닌자",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 658,
    slug: "greninja",
    en: "Greninja",
    ko: "개굴닌자",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 658,
    slug: "mega-greninja",
    en: "Mega Greninja",
    ko: "메가개굴닌자",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 659,
    slug: "bunnelby",
    en: "Bunnelby",
    ko: "파르빗",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 660,
    slug: "diggersby",
    en: "Diggersby",
    ko: "파르토",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 661,
    slug: "fletchling",
    en: "Fletchling",
    ko: "화살꼬빈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 662,
    slug: "fletchinder",
    en: "Fletchinder",
    ko: "불화살빈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 663,
    slug: "talonflame",
    en: "Talonflame",
    ko: "파이어로",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 664,
    slug: "scatterbug",
    en: "Scatterbug",
    ko: "분이벌레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 665,
    slug: "spewpa",
    en: "Spewpa",
    ko: "분떠도리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 666,
    slug: "vivillon",
    en: "Vivillon",
    ko: "비비용",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 667,
    slug: "litleo",
    en: "Litleo",
    ko: "레오꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 668,
    slug: "pyroar",
    en: "Pyroar",
    ko: "화염레오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 668,
    slug: "mega-pyroar",
    en: "Mega Pyroar",
    ko: "메가화염레오",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 669,
    slug: "flabebe",
    en: "Flabébé",
    ko: "플라베베",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 670,
    slug: "floette",
    en: "Floette",
    ko: "플라엣테",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 670,
    slug: "floette-eternal-flower",
    en: "Floette Eternal Flower",
    ko: "영원의 꽃 플라엣테",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 670,
    slug: "mega-floette",
    en: "Mega Floette",
    ko: "메가플라엣테",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 671,
    slug: "florges",
    en: "Florges",
    ko: "플라제스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 672,
    slug: "skiddo",
    en: "Skiddo",
    ko: "메이클",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 673,
    slug: "gogoat",
    en: "Gogoat",
    ko: "고고트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 674,
    slug: "pancham",
    en: "Pancham",
    ko: "판짱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 675,
    slug: "pangoro",
    en: "Pangoro",
    ko: "부란다",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 676,
    slug: "furfrou",
    en: "Furfrou",
    ko: "트리미앙",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 677,
    slug: "espurr",
    en: "Espurr",
    ko: "냐스퍼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 678,
    slug: "mega-meowstic",
    en: "Mega Meowstic",
    ko: "메가냐오닉스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 678,
    slug: "meowstic-f",
    en: "Meowstic (female)",
    ko: "냐오닉스 (암컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 678,
    slug: "meowstic-m",
    en: "Meowstic (male)",
    ko: "냐오닉스 (수컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 679,
    slug: "honedge",
    en: "Honedge",
    ko: "단칼빙",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 680,
    slug: "doublade",
    en: "Doublade",
    ko: "쌍검킬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 681,
    slug: "aegislash",
    en: "Aegislash",
    ko: "킬가르도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 682,
    slug: "spritzee",
    en: "Spritzee",
    ko: "슈쁘",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 683,
    slug: "aromatisse",
    en: "Aromatisse",
    ko: "프레프티르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 684,
    slug: "swirlix",
    en: "Swirlix",
    ko: "나룸퍼프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 685,
    slug: "slurpuff",
    en: "Slurpuff",
    ko: "나루림",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 686,
    slug: "inkay",
    en: "Inkay",
    ko: "오케이징",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 687,
    slug: "malamar",
    en: "Malamar",
    ko: "칼라마네로",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 687,
    slug: "mega-malamar",
    en: "Mega Malamar",
    ko: "메가칼라마네로",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 688,
    slug: "binacle",
    en: "Binacle",
    ko: "거북손손",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 689,
    slug: "barbaracle",
    en: "Barbaracle",
    ko: "거북손데스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 689,
    slug: "mega-barbaracle",
    en: "Mega Barbaracle",
    ko: "메가거북손데스",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 690,
    slug: "skrelp",
    en: "Skrelp",
    ko: "수레기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 691,
    slug: "dragalge",
    en: "Dragalge",
    ko: "드래캄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 691,
    slug: "mega-dragalge",
    en: "Mega Dragalge",
    ko: "메가드래캄",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 692,
    slug: "clauncher",
    en: "Clauncher",
    ko: "완철포",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 693,
    slug: "clawitzer",
    en: "Clawitzer",
    ko: "블로스터",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 694,
    slug: "helioptile",
    en: "Helioptile",
    ko: "목도리키텔",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 695,
    slug: "heliolisk",
    en: "Heliolisk",
    ko: "일레도리자드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 696,
    slug: "tyrunt",
    en: "Tyrunt",
    ko: "티고라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 697,
    slug: "tyrantrum",
    en: "Tyrantrum",
    ko: "견고라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 698,
    slug: "amaura",
    en: "Amaura",
    ko: "아마루스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 699,
    slug: "aurorus",
    en: "Aurorus",
    ko: "아마루르가",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 700,
    slug: "sylveon",
    en: "Sylveon",
    ko: "님피아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 701,
    slug: "hawlucha",
    en: "Hawlucha",
    ko: "루차불",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 701,
    slug: "mega-hawlucha",
    en: "Mega Hawlucha",
    ko: "메가루차불",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 702,
    slug: "dedenne",
    en: "Dedenne",
    ko: "데덴네",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 703,
    slug: "carbink",
    en: "Carbink",
    ko: "멜리시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 704,
    slug: "goomy",
    en: "Goomy",
    ko: "미끄메라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 705,
    slug: "sliggoo",
    en: "Sliggoo",
    ko: "미끄네일",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 705,
    slug: "sliggoo-hisuian",
    en: "Sliggoo (Hisuian)",
    ko: "미끄네일 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 706,
    slug: "goodra",
    en: "Goodra",
    ko: "미끄래곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 706,
    slug: "goodra-hisuian",
    en: "Goodra (Hisuian)",
    ko: "미끄래곤 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 707,
    slug: "klefki",
    en: "Klefki",
    ko: "클레피",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 708,
    slug: "phantump",
    en: "Phantump",
    ko: "나목령",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 709,
    slug: "trevenant",
    en: "Trevenant",
    ko: "대로트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 710,
    slug: "pumpkaboo",
    en: "Pumpkaboo",
    ko: "호바귀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 711,
    slug: "gourgeist",
    en: "Gourgeist",
    ko: "펌킨인",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 712,
    slug: "bergmite",
    en: "Bergmite",
    ko: "꽁어름",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 713,
    slug: "avalugg",
    en: "Avalugg",
    ko: "크레베이스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 713,
    slug: "avalugg-hisuian",
    en: "Avalugg (Hisuian)",
    ko: "크레베이스 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 714,
    slug: "noibat",
    en: "Noibat",
    ko: "음뱃",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 715,
    slug: "noivern",
    en: "Noivern",
    ko: "음번",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 716,
    slug: "xerneas",
    en: "Xerneas",
    ko: "제르네아스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 717,
    slug: "yveltal",
    en: "Yveltal",
    ko: "이벨타르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 718,
    slug: "mega-zygarde",
    en: "Mega Zygarde",
    ko: "메가지가르데",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 718,
    slug: "zygarde-10-forme",
    en: "Zygarde (10% Forme)",
    ko: "지가르데 (10%폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 718,
    slug: "zygarde-50-forme",
    en: "Zygarde (50% Forme)",
    ko: "지가르데 (50%폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 718,
    slug: "zygarde-complete-forme",
    en: "Zygarde (Complete Forme)",
    ko: "지가르데 (퍼펙트폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 719,
    slug: "diancie",
    en: "Diancie",
    ko: "디안시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 719,
    slug: "mega-diancie",
    en: "Mega Diancie",
    ko: "메가디안시",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 720,
    slug: "hoopa-confined",
    en: "Hoopa (Confined)",
    ko: "후파 (굴레에빠진)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 720,
    slug: "hoopa-unbound",
    en: "Hoopa (Unbound)",
    ko: "후파 (굴레를벗어난)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 721,
    slug: "volcanion",
    en: "Volcanion",
    ko: "볼케니온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 722,
    slug: "rowlet",
    en: "Rowlet",
    ko: "나몰빼미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 723,
    slug: "dartrix",
    en: "Dartrix",
    ko: "빼미스로우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 724,
    slug: "decidueye",
    en: "Decidueye",
    ko: "모크나이퍼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 724,
    slug: "decidueye-hisuian",
    en: "Decidueye (Hisuian)",
    ko: "모크나이퍼 (히스이)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 725,
    slug: "litten",
    en: "Litten",
    ko: "냐오불",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 726,
    slug: "torracat",
    en: "Torracat",
    ko: "냐오히트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 727,
    slug: "incineroar",
    en: "Incineroar",
    ko: "어흥염",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 728,
    slug: "popplio",
    en: "Popplio",
    ko: "누리공",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 729,
    slug: "brionne",
    en: "Brionne",
    ko: "키요공",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 730,
    slug: "primarina",
    en: "Primarina",
    ko: "누리레느",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 731,
    slug: "pikipek",
    en: "Pikipek",
    ko: "콕코구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 732,
    slug: "trumbeak",
    en: "Trumbeak",
    ko: "크라파",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 733,
    slug: "toucannon",
    en: "Toucannon",
    ko: "왕큰부리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 734,
    slug: "yungoos",
    en: "Yungoos",
    ko: "영구스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 735,
    slug: "gumshoos",
    en: "Gumshoos",
    ko: "형사구스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 736,
    slug: "grubbin",
    en: "Grubbin",
    ko: "턱지충이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 737,
    slug: "charjabug",
    en: "Charjabug",
    ko: "전지충이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 738,
    slug: "vikavolt",
    en: "Vikavolt",
    ko: "투구뿌논",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 739,
    slug: "crabrawler",
    en: "Crabrawler",
    ko: "오기지게",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 740,
    slug: "crabominable",
    en: "Crabominable",
    ko: "모단단게",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 740,
    slug: "mega-crabominable",
    en: "Mega Crabominable",
    ko: "메가모단단게",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-baile",
    en: "Oricorio (Baile)",
    ko: "춤추새(이글이글스타일)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-pau",
    en: "Oricorio (Pa'u)",
    ko: "춤추새(훌라훌라스타일)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-pom-pom",
    en: "Oricorio (Pom-Pom)",
    ko: "춤추새(파칙파칙스타일)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-sensu",
    en: "Oricorio (Sensu)",
    ko: "춤추새(하늘하늘스타일)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 742,
    slug: "cutiefly",
    en: "Cutiefly",
    ko: "에블리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 743,
    slug: "ribombee",
    en: "Ribombee",
    ko: "에리본",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 744,
    slug: "rockruff",
    en: "Rockruff",
    ko: "암멍이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 745,
    slug: "lycanroc-dusk",
    en: "Lycanroc (Dusk)",
    ko: "루가루암 (황혼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 745,
    slug: "lycanroc-midday",
    en: "Lycanroc (Midday)",
    ko: "루가루암 (한낮)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 745,
    slug: "lycanroc-midnight",
    en: "Lycanroc (Midnight)",
    ko: "루가루암 (한밤)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 746,
    slug: "wishiwashi-school",
    en: "Wishiwashi (School)",
    ko: "약어리 (군의모습)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 747,
    slug: "mareanie",
    en: "Mareanie",
    ko: "시마사리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 748,
    slug: "toxapex",
    en: "Toxapex",
    ko: "더시마사리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 749,
    slug: "mudbray",
    en: "Mudbray",
    ko: "머드나기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 750,
    slug: "mudsdale",
    en: "Mudsdale",
    ko: "만마드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 751,
    slug: "dewpider",
    en: "Dewpider",
    ko: "물거미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 752,
    slug: "araquanid",
    en: "Araquanid",
    ko: "깨비물거미",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 753,
    slug: "fomantis",
    en: "Fomantis",
    ko: "짜랑랑",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 754,
    slug: "lurantis",
    en: "Lurantis",
    ko: "라란티스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 755,
    slug: "morelull",
    en: "Morelull",
    ko: "자마슈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 756,
    slug: "shiinotic",
    en: "Shiinotic",
    ko: "마셰이드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 757,
    slug: "salandit",
    en: "Salandit",
    ko: "야도뇽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 758,
    slug: "salazzle",
    en: "Salazzle",
    ko: "염뉴트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 759,
    slug: "stufful",
    en: "Stufful",
    ko: "포곰곰",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 760,
    slug: "bewear",
    en: "Bewear",
    ko: "이븐곰",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 761,
    slug: "bounsweet",
    en: "Bounsweet",
    ko: "달콤아",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 762,
    slug: "steenee",
    en: "Steenee",
    ko: "달무리나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 763,
    slug: "tsareena",
    en: "Tsareena",
    ko: "달코퀸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 764,
    slug: "comfey",
    en: "Comfey",
    ko: "큐아링",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 765,
    slug: "oranguru",
    en: "Oranguru",
    ko: "하랑우탄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 766,
    slug: "passimian",
    en: "Passimian",
    ko: "내던숭이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 767,
    slug: "wimpod",
    en: "Wimpod",
    ko: "꼬시레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 768,
    slug: "golisopod",
    en: "Golisopod",
    ko: "갑주무사",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 768,
    slug: "mega-golisopod",
    en: "Mega Golisopod",
    ko: "메가갑주무사",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 769,
    slug: "sandygast",
    en: "Sandygast",
    ko: "모래꿍",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 770,
    slug: "palossand",
    en: "Palossand",
    ko: "모래성이당",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 771,
    slug: "pyukumuku",
    en: "Pyukumuku",
    ko: "해무기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 772,
    slug: "type-null",
    en: "Type: Null",
    ko: "타입:널",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 773,
    slug: "silvally",
    en: "Silvally",
    ko: "실버디",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 774,
    slug: "minior-core",
    en: "Minior (Core)",
    ko: "메테노(코어)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 775,
    slug: "komala",
    en: "Komala",
    ko: "자말라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 776,
    slug: "turtonator",
    en: "Turtonator",
    ko: "폭거북스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 777,
    slug: "togedemaru",
    en: "Togedemaru",
    ko: "토게데마루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 778,
    slug: "mimikyu",
    en: "Mimikyu",
    ko: "따라큐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 779,
    slug: "bruxish",
    en: "Bruxish",
    ko: "치갈기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 780,
    slug: "drampa",
    en: "Drampa",
    ko: "할비롱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 780,
    slug: "mega-drampa",
    en: "Mega Drampa",
    ko: "메가할비롱",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 781,
    slug: "dhelmise",
    en: "Dhelmise",
    ko: "타타륜",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 782,
    slug: "jangmo-o",
    en: "Jangmo-o",
    ko: "짜랑꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 783,
    slug: "hakamo-o",
    en: "Hakamo-o",
    ko: "짜랑고우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 784,
    slug: "kommo-o",
    en: "Kommo-o",
    ko: "짜랑고우거",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 785,
    slug: "tapu-koko",
    en: "Tapu Koko",
    ko: "카푸꼬꼬꼭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 786,
    slug: "tapu-lele",
    en: "Tapu Lele",
    ko: "카푸나비나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 787,
    slug: "tapu-bulu",
    en: "Tapu Bulu",
    ko: "카푸브루루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 788,
    slug: "tapu-fini",
    en: "Tapu Fini",
    ko: "카푸느지느",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 789,
    slug: "cosmog",
    en: "Cosmog",
    ko: "코스모그",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 790,
    slug: "cosmoem",
    en: "Cosmoem",
    ko: "코스모움",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 791,
    slug: "solgaleo",
    en: "Solgaleo",
    ko: "솔가레오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 792,
    slug: "lunala",
    en: "Lunala",
    ko: "루나아라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 793,
    slug: "nihilego",
    en: "Nihilego",
    ko: "텅비드",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 794,
    slug: "buzzwole",
    en: "Buzzwole",
    ko: "매시붕",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 795,
    slug: "pheromosa",
    en: "Pheromosa",
    ko: "페로코체",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 796,
    slug: "xurkitree",
    en: "Xurkitree",
    ko: "전수목",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 797,
    slug: "celesteela",
    en: "Celesteela",
    ko: "철화구야",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 798,
    slug: "kartana",
    en: "Kartana",
    ko: "종이신도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 799,
    slug: "guzzlord",
    en: "Guzzlord",
    ko: "악식킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 800,
    slug: "necrozma",
    en: "Necrozma",
    ko: "네크로즈마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 800,
    slug: "necrozma-dawn-wings",
    en: "Necrozma (Dawn Wings)",
    ko: "네크로즈마(새벽의날개)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 800,
    slug: "necrozma-dusk-mane",
    en: "Necrozma (Dusk Mane)",
    ko: "네크로즈마(황혼의갈기)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 800,
    slug: "ultra-necrozma",
    en: "Ultra Necrozma",
    ko: "울트라네크로즈마",
    category: "ultra",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 801,
    slug: "magearna",
    en: "Magearna",
    ko: "마기아나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 801,
    slug: "mega-magearna",
    en: "Mega Magearna",
    ko: "메가마기아나",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 802,
    slug: "marshadow",
    en: "Marshadow",
    ko: "마샤도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 803,
    slug: "poipole",
    en: "Poipole",
    ko: "베베놈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 804,
    slug: "naganadel",
    en: "Naganadel",
    ko: "아고용",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 805,
    slug: "stakataka",
    en: "Stakataka",
    ko: "차곡차곡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 806,
    slug: "blacephalon",
    en: "Blacephalon",
    ko: "두파팡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 807,
    slug: "zeraora",
    en: "Zeraora",
    ko: "제라오라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 807,
    slug: "mega-zeraora",
    en: "Mega Zeraora",
    ko: "메가제라오라",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 808,
    slug: "meltan",
    en: "Meltan",
    ko: "멜탄",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 809,
    slug: "melmetal",
    en: "Melmetal",
    ko: "멜메탈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 809,
    slug: "melmetal-gigantamax",
    en: "Melmetal (G)",
    ko: "멜메탈 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 810,
    slug: "grookey",
    en: "Grookey",
    ko: "흥나숭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 811,
    slug: "thwackey",
    en: "Thwackey",
    ko: "채키몽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 812,
    slug: "rillaboom",
    en: "Rillaboom",
    ko: "고릴타",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 812,
    slug: "rillaboom-gigantamax",
    en: "Rillaboom (G)",
    ko: "고릴타 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 813,
    slug: "scorbunny",
    en: "Scorbunny",
    ko: "염버니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 814,
    slug: "raboot",
    en: "Raboot",
    ko: "래비풋",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 815,
    slug: "cinderace",
    en: "Cinderace",
    ko: "에이스번",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 815,
    slug: "cinderace-gigantamax",
    en: "Cinderace (G)",
    ko: "에이스번 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 816,
    slug: "sobble",
    en: "Sobble",
    ko: "울머기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 817,
    slug: "drizzile",
    en: "Drizzile",
    ko: "누겔레온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 818,
    slug: "inteleon",
    en: "Inteleon",
    ko: "인텔리레온",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 818,
    slug: "inteleon-gigantamax",
    en: "Inteleon (G)",
    ko: "인텔리레온 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 819,
    slug: "skwovet",
    en: "Skwovet",
    ko: "탐리스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 820,
    slug: "greedent",
    en: "Greedent",
    ko: "요씽리스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 821,
    slug: "rookidee",
    en: "Rookidee",
    ko: "파라꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 822,
    slug: "corvisquire",
    en: "Corvisquire",
    ko: "파크로우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 823,
    slug: "corviknight",
    en: "Corviknight",
    ko: "아머까오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 823,
    slug: "corviknight-gigantamax",
    en: "Corviknight (G)",
    ko: "아머까오 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 824,
    slug: "blipbug",
    en: "Blipbug",
    ko: "두루지벌레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 825,
    slug: "dottler",
    en: "Dottler",
    ko: "레돔벌레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 826,
    slug: "orbeetle",
    en: "Orbeetle",
    ko: "이올브",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 826,
    slug: "orbeetle-gigantamax",
    en: "Orbeetle (G)",
    ko: "이올브 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 827,
    slug: "nickit",
    en: "Nickit",
    ko: "훔처우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 828,
    slug: "thievul",
    en: "Thievul",
    ko: "폭슬라이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 829,
    slug: "gossifleur",
    en: "Gossifleur",
    ko: "꼬모카",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 830,
    slug: "eldegoss",
    en: "Eldegoss",
    ko: "백솜모카",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 831,
    slug: "wooloo",
    en: "Wooloo",
    ko: "우르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 832,
    slug: "dubwool",
    en: "Dubwool",
    ko: "배우르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 833,
    slug: "chewtle",
    en: "Chewtle",
    ko: "깨물부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 834,
    slug: "drednaw",
    en: "Drednaw",
    ko: "갈가부기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 834,
    slug: "drednaw-gigantamax",
    en: "Drednaw (G)",
    ko: "갈가부기 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 835,
    slug: "yamper",
    en: "Yamper",
    ko: "멍파치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 836,
    slug: "boltund",
    en: "Boltund",
    ko: "펄스멍",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 837,
    slug: "rolycoly",
    en: "Rolycoly",
    ko: "탄동",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 838,
    slug: "carkol",
    en: "Carkol",
    ko: "탄차곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 839,
    slug: "coalossal",
    en: "Coalossal",
    ko: "석탄산",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 839,
    slug: "coalossal-gigantamax",
    en: "Coalossal (G)",
    ko: "석탄산 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 840,
    slug: "applin",
    en: "Applin",
    ko: "과사삭벌레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 841,
    slug: "flapple",
    en: "Flapple",
    ko: "애프룡",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 841,
    slug: "flapple-gigantamax",
    en: "Flapple (G)",
    ko: "애프룡 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 842,
    slug: "appletun",
    en: "Appletun",
    ko: "단지래플",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 842,
    slug: "appletun-gigantamax",
    en: "Appletun (G)",
    ko: "단지래플 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 843,
    slug: "silicobra",
    en: "Silicobra",
    ko: "모래뱀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 844,
    slug: "sandaconda",
    en: "Sandaconda",
    ko: "사다이사",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 844,
    slug: "sandaconda-gigantamax",
    en: "Sandaconda (G)",
    ko: "사다이사 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 845,
    slug: "cramorant",
    en: "Cramorant",
    ko: "윽우지",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 846,
    slug: "arrokuda",
    en: "Arrokuda",
    ko: "찌로꼬치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 847,
    slug: "barraskewda",
    en: "Barraskewda",
    ko: "꼬치조",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 848,
    slug: "toxel",
    en: "Toxel",
    ko: "일레즌",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 849,
    slug: "toxtricity-gigantamax",
    en: "Toxtricity (G)",
    ko: "스트린더 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 849,
    slug: "toxtricity-high",
    en: "Toxtricity High",
    ko: "스트린더 하이",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 849,
    slug: "toxtricity-low",
    en: "Toxtricity Low",
    ko: "스트린더 로우",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 850,
    slug: "sizzlipede",
    en: "Sizzlipede",
    ko: "태우지네",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 851,
    slug: "centiskorch",
    en: "Centiskorch",
    ko: "다태우지네",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 851,
    slug: "centiskorch-gigantamax",
    en: "Centiskorch (G)",
    ko: "다태우지네 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 852,
    slug: "clobbopus",
    en: "Clobbopus",
    ko: "때때무노",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 853,
    slug: "grapploct",
    en: "Grapploct",
    ko: "케오퍼스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 854,
    slug: "sinistea",
    en: "Sinistea",
    ko: "데인차",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 855,
    slug: "polteageist",
    en: "Polteageist",
    ko: "포트데스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 856,
    slug: "hatenna",
    en: "Hatenna",
    ko: "몸지브림",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 857,
    slug: "hattrem",
    en: "Hattrem",
    ko: "손지브림",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 858,
    slug: "hatterene",
    en: "Hatterene",
    ko: "브리무음",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 858,
    slug: "hatterene-gigantamax",
    en: "Hatterene (G)",
    ko: "브리무음 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 859,
    slug: "impidimp",
    en: "Impidimp",
    ko: "메롱꿍",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 860,
    slug: "morgrem",
    en: "Morgrem",
    ko: "쏘겨모",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 861,
    slug: "grimmsnarl",
    en: "Grimmsnarl",
    ko: "오롱털",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 861,
    slug: "grimmsnarl-gigantamax",
    en: "Grimmsnarl (G)",
    ko: "오롱털 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 862,
    slug: "obstagoon",
    en: "Obstagoon",
    ko: "가로막구리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 863,
    slug: "perrserker",
    en: "Perrserker",
    ko: "나이킹",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 864,
    slug: "cursola",
    en: "Cursola",
    ko: "산호르곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 865,
    slug: "sirfetchd",
    en: "Sirfetch'd",
    ko: "창파나이트",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 866,
    slug: "mr-rime",
    en: "Mr. Rime",
    ko: "마임꽁꽁",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 867,
    slug: "runerigus",
    en: "Runerigus",
    ko: "데스판",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 868,
    slug: "milcery",
    en: "Milcery",
    ko: "마빌크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 869,
    slug: "alcremie",
    en: "Alcremie",
    ko: "마휘핑",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 869,
    slug: "alcremie-gigantamax",
    en: "Alcremie (G)",
    ko: "마휘핑 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 870,
    slug: "falinks",
    en: "Falinks",
    ko: "대여르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 870,
    slug: "mega-falinks",
    en: "Mega Falinks",
    ko: "메가대여르",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 871,
    slug: "pincurchin",
    en: "Pincurchin",
    ko: "찌르성게",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 872,
    slug: "snom",
    en: "Snom",
    ko: "누니머기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 873,
    slug: "frosmoth",
    en: "Frosmoth",
    ko: "모스노우",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 874,
    slug: "stonjourner",
    en: "Stonjourner",
    ko: "돌헨진",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 875,
    slug: "eiscue",
    en: "Eiscue",
    ko: "빙큐보",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 876,
    slug: "indeedee-f",
    en: "Indeedee (Female)",
    ko: "에써르(암컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 876,
    slug: "indeedee-m",
    en: "Indeedee (Male)",
    ko: "에써르(수컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 877,
    slug: "morpeko",
    en: "Morpeko",
    ko: "모르페코",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 878,
    slug: "cufant",
    en: "Cufant",
    ko: "끼리동",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 879,
    slug: "copperajah",
    en: "Copperajah",
    ko: "대왕끼리동",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 879,
    slug: "copperajah-gigantamax",
    en: "Copperajah (G)",
    ko: "대왕끼리동 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 880,
    slug: "dracozolt",
    en: "Dracozolt",
    ko: "파치래곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 881,
    slug: "arctozolt",
    en: "Arctozolt",
    ko: "파치르돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 882,
    slug: "dracovish",
    en: "Dracovish",
    ko: "어래곤",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 883,
    slug: "arctovish",
    en: "Arctovish",
    ko: "어치르돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 884,
    slug: "duraludon",
    en: "Duraludon",
    ko: "두랄루돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 884,
    slug: "duraludon-gigantamax",
    en: "Duraludon (G)",
    ko: "두랄루돈 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 885,
    slug: "dreepy",
    en: "Dreepy",
    ko: "드라꼰",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 886,
    slug: "drakloak",
    en: "Drakloak",
    ko: "드래런치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 887,
    slug: "dragapult",
    en: "Dragapult",
    ko: "드래펄트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 888,
    slug: "zacian-crowned-sword",
    en: "Zacian (Crowned Sword)",
    ko: "자시안 (검왕)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 888,
    slug: "zacian-hero-of-many-battles",
    en: "Zacian (Hero of Many Battles)",
    ko: "자시안(역전의용사)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 889,
    slug: "zamazenta-crowned-shield",
    en: "Zamazenta (Crowned Shield)",
    ko: "자마젠타(방패왕)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 889,
    slug: "zamazenta-hero-of-many-battles",
    en: "Zamazenta (Hero of Many Battles)",
    ko: "자마젠타 (역전의용사)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 890,
    slug: "eternatus",
    en: "Eternatus",
    ko: "무한다이노",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 891,
    slug: "kubfu",
    en: "Kubfu",
    ko: "치고마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 892,
    slug: "urshifu-rapid-strike",
    en: "Urshifu (Rapid Strike)",
    ko: "우라오스 (연격의태세)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 892,
    slug: "urshifu-rapid-strike-gigantamax",
    en: "Urshifu (Rapid Strike G)",
    ko: "우라오스 (연격의태세 G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 892,
    slug: "urshifu-single-strike",
    en: "Urshifu (Single Strike)",
    ko: "우라오스 (일격의태세)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 892,
    slug: "urshifu-single-strike-gigantamax",
    en: "Urshifu (Single Strike G)",
    ko: "우라오스 (일격의태세 G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 893,
    slug: "zarude",
    en: "Zarude",
    ko: "자루도",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 894,
    slug: "regieleki",
    en: "Regieleki",
    ko: "레지에레키",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 895,
    slug: "regidrago",
    en: "Regidrago",
    ko: "레지드래고",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 896,
    slug: "glastrier",
    en: "Glastrier",
    ko: "블리자포스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 897,
    slug: "spectrier",
    en: "Spectrier",
    ko: "레이스포스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 898,
    slug: "calyrex",
    en: "Calyrex",
    ko: "버드렉스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 898,
    slug: "calyrex-ice-rider",
    en: "Calyrex (Ice Rider)",
    ko: "버드렉스(백마탄모습)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 898,
    slug: "calyrex-shadow-rider",
    en: "Calyrex (Shadow Rider)",
    ko: "버드렉스(흑마탄모습)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 899,
    slug: "wyrdeer",
    en: "Wyrdeer",
    ko: "신비록",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 900,
    slug: "kleavor",
    en: "Kleavor",
    ko: "사마자르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 901,
    slug: "ursaluna",
    en: "Ursaluna",
    ko: "다투곰",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 902,
    slug: "basculegion-f",
    en: "Basculegion (Female)",
    ko: "대쓰여너(암컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 902,
    slug: "basculegion-m",
    en: "Basculegion (Male)",
    ko: "대쓰여너(수컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 903,
    slug: "sneasler",
    en: "Sneasler",
    ko: "포푸니크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 904,
    slug: "overqwil",
    en: "Overqwil",
    ko: "장침바루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 905,
    slug: "enamorus-incarnate",
    en: "Enamorus (Incarnate)",
    ko: "러브로스(화신폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 905,
    slug: "enamorus-therian",
    en: "Enamorus (Therian)",
    ko: "러브로스(영물폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 906,
    slug: "sprigatito",
    en: "Sprigatito",
    ko: "나오하",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 907,
    slug: "floragato",
    en: "Floragato",
    ko: "나로테",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 908,
    slug: "meowscarada",
    en: "Meowscarada",
    ko: "마스카나",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 909,
    slug: "fuecoco",
    en: "Fuecoco",
    ko: "뜨아거",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 910,
    slug: "crocalor",
    en: "Crocalor",
    ko: "악뜨거",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 911,
    slug: "skeledirge",
    en: "Skeledirge",
    ko: "라우드본",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 912,
    slug: "quaxly",
    en: "Quaxly",
    ko: "꾸왁스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 913,
    slug: "quaxwell",
    en: "Quaxwell",
    ko: "아꾸왁",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 914,
    slug: "quaquaval",
    en: "Quaquaval",
    ko: "웨이니발",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 915,
    slug: "lechonk",
    en: "Lechonk",
    ko: "맛보돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 916,
    slug: "oinkologne-f",
    en: "Oinkologne (Female)",
    ko: "퍼퓨돈 (암컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 916,
    slug: "oinkologne-m",
    en: "Oinkologne (Male)",
    ko: "퍼퓨돈 (수컷)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 917,
    slug: "tarountula",
    en: "Tarountula",
    ko: "타랜툴라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 918,
    slug: "spidops",
    en: "Spidops",
    ko: "트래피더",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 919,
    slug: "nymble",
    en: "Nymble",
    ko: "콩알뚜기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 920,
    slug: "lokix",
    en: "Lokix",
    ko: "엑스레그",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 921,
    slug: "pawmi",
    en: "Pawmi",
    ko: "빠모",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 922,
    slug: "pawmo",
    en: "Pawmo",
    ko: "빠모트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 923,
    slug: "pawmot",
    en: "Pawmot",
    ko: "빠르모트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 924,
    slug: "tandemaus",
    en: "Tandemaus",
    ko: "두리쥐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 925,
    slug: "maushold",
    en: "Maushold",
    ko: "파밀리쥐",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 926,
    slug: "fidough",
    en: "Fidough",
    ko: "쫀도기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 927,
    slug: "dachsbun",
    en: "Dachsbun",
    ko: "바우첼",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 928,
    slug: "smoliv",
    en: "Smoliv",
    ko: "미니브",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 929,
    slug: "dolliv",
    en: "Dolliv",
    ko: "올리뇨",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 930,
    slug: "arboliva",
    en: "Arboliva",
    ko: "올리르바",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 931,
    slug: "squawkabilly",
    en: "Squawkabilly",
    ko: "시비꼬",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 932,
    slug: "nacli",
    en: "Nacli",
    ko: "베베솔트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 933,
    slug: "naclstack",
    en: "Naclstack",
    ko: "스태솔트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 934,
    slug: "garganacl",
    en: "Garganacl",
    ko: "콜로솔트",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 935,
    slug: "charcadet",
    en: "Charcadet",
    ko: "카르본",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 936,
    slug: "armarouge",
    en: "Armarouge",
    ko: "카디나르마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 937,
    slug: "ceruledge",
    en: "Ceruledge",
    ko: "파라블레이즈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 938,
    slug: "tadbulb",
    en: "Tadbulb",
    ko: "빈나두",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 939,
    slug: "bellibolt",
    en: "Bellibolt",
    ko: "찌리배리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 940,
    slug: "wattrel",
    en: "Wattrel",
    ko: "찌리비",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 941,
    slug: "kilowattrel",
    en: "Kilowattrel",
    ko: "찌리비크",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 942,
    slug: "maschiff",
    en: "Maschiff",
    ko: "오라티프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 943,
    slug: "mabosstiff",
    en: "Mabosstiff",
    ko: "마피티프",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 944,
    slug: "shroodle",
    en: "Shroodle",
    ko: "땃쭈르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 945,
    slug: "grafaiai",
    en: "Grafaiai",
    ko: "태깅구르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 946,
    slug: "bramblin",
    en: "Bramblin",
    ko: "그푸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 947,
    slug: "brambleghast",
    en: "Brambleghast",
    ko: "공푸리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 948,
    slug: "toedscool",
    en: "Toedscool",
    ko: "들눈해",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 949,
    slug: "toedscruel",
    en: "Toedscruel",
    ko: "육파리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 950,
    slug: "klawf",
    en: "Klawf",
    ko: "절벼게",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 951,
    slug: "capsakid",
    en: "Capsakid",
    ko: "캡싸이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 952,
    slug: "scovillain",
    en: "Scovillain",
    ko: "스코빌런",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 952,
    slug: "mega-scovillain",
    en: "Mega Scovillain",
    ko: "메가스코빌런",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 953,
    slug: "rellor",
    en: "Rellor",
    ko: "구르데",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 954,
    slug: "rabsca",
    en: "Rabsca",
    ko: "베라카스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 955,
    slug: "flittle",
    en: "Flittle",
    ko: "하느라기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 956,
    slug: "espathra",
    en: "Espathra",
    ko: "클레스퍼트라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 957,
    slug: "tinkatink",
    en: "Tinkatink",
    ko: "어리짱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 958,
    slug: "tinkatuff",
    en: "Tinkatuff",
    ko: "벼리짱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 959,
    slug: "tinkaton",
    en: "Tinkaton",
    ko: "두드리짱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 960,
    slug: "wiglett",
    en: "Wiglett",
    ko: "바다그다",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 961,
    slug: "wugtrio",
    en: "Wugtrio",
    ko: "바닥트리오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 962,
    slug: "bombirdier",
    en: "Bombirdier",
    ko: "떨구새",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 963,
    slug: "finizen",
    en: "Finizen",
    ko: "맨돌핀",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 964,
    slug: "palafin",
    en: "Palafin",
    ko: "돌핀맨(나이브폼)",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 965,
    slug: "varoom",
    en: "Varoom",
    ko: "부르롱",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 966,
    slug: "revavroom",
    en: "Revavroom",
    ko: "부르르룸",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 967,
    slug: "cyclizar",
    en: "Cyclizar",
    ko: "모토마",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 968,
    slug: "orthworm",
    en: "Orthworm",
    ko: "꿈트렁",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 969,
    slug: "glimmet",
    en: "Glimmet",
    ko: "초롱순",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 970,
    slug: "glimmora",
    en: "Glimmora",
    ko: "킬라플로르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 970,
    slug: "mega-glimmora",
    en: "Mega Glimmora",
    ko: "메가킬라플로르",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 971,
    slug: "greavard",
    en: "Greavard",
    ko: "망망이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 972,
    slug: "houndstone",
    en: "Houndstone",
    ko: "묘두기",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 973,
    slug: "flamigo",
    en: "Flamigo",
    ko: "꼬이밍고",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 974,
    slug: "cetoddle",
    en: "Cetoddle",
    ko: "터벅고래",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 975,
    slug: "cetitan",
    en: "Cetitan",
    ko: "우락고래",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 976,
    slug: "veluza",
    en: "Veluza",
    ko: "가비루사",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 977,
    slug: "dondozo",
    en: "Dondozo",
    ko: "어써러셔",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 978,
    slug: "tatsugiri",
    en: "Tatsugiri",
    ko: "싸리용",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 978,
    slug: "mega-tatsugiri",
    en: "Mega Tatsugiri",
    ko: "메가싸리용",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 979,
    slug: "annihilape",
    en: "Annihilape",
    ko: "저승갓숭",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 980,
    slug: "clodsire",
    en: "Clodsire",
    ko: "토오",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 981,
    slug: "farigiraf",
    en: "Farigiraf",
    ko: "키키링",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 982,
    slug: "dudunsparce",
    en: "Dudunsparce",
    ko: "노고고치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 983,
    slug: "kingambit",
    en: "Kingambit",
    ko: "대도각참",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 984,
    slug: "great-tusk",
    en: "Great Tusk",
    ko: "위대한엄니",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 985,
    slug: "scream-tail",
    en: "Scream Tail",
    ko: "우렁찬꼬리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 986,
    slug: "brute-bonnet",
    en: "Brute Bonnet",
    ko: "사나운버섯",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 987,
    slug: "flutter-mane",
    en: "Flutter Mane",
    ko: "날개치는머리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 988,
    slug: "slither-wing",
    en: "Slither Wing",
    ko: "땅을기는날개",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 989,
    slug: "sandy-shocks",
    en: "Sandy Shocks",
    ko: "모래털가죽",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 990,
    slug: "iron-treads",
    en: "Iron Treads",
    ko: "무쇠바퀴",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 991,
    slug: "iron-bundle",
    en: "Iron Bundle",
    ko: "무쇠보따리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 992,
    slug: "iron-hands",
    en: "Iron Hands",
    ko: "무쇠손",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 993,
    slug: "iron-jugulis",
    en: "Iron Jugulis",
    ko: "무쇠머리",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 994,
    slug: "iron-moth",
    en: "Iron Moth",
    ko: "무쇠독나방",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 995,
    slug: "iron-thorns",
    en: "Iron Thorns",
    ko: "무쇠가시",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 996,
    slug: "frigibax",
    en: "Frigibax",
    ko: "드니차",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 997,
    slug: "arctibax",
    en: "Arctibax",
    ko: "드니꽁",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 998,
    slug: "baxcalibur",
    en: "Baxcalibur",
    ko: "드닐레이브",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 998,
    slug: "mega-baxcalibur",
    en: "Mega Baxcalibur",
    ko: "메가드닐레이브",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 999,
    slug: "gimmighoul",
    en: "Gimmighoul",
    ko: "모으령",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1e3,
    slug: "gholdengo",
    en: "Gholdengo",
    ko: "타부자고",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1001,
    slug: "wo-chien",
    en: "Wo-Chien",
    ko: "총지엔",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1002,
    slug: "chien-pao",
    en: "Chien-Pao",
    ko: "파오젠",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1003,
    slug: "ting-lu",
    en: "Ting-Lu",
    ko: "딩루",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1004,
    slug: "chi-yu",
    en: "Chi-Yu",
    ko: "위유이",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1005,
    slug: "roaring-moon",
    en: "Roaring Moon",
    ko: "고동치는달",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1006,
    slug: "iron-valiant",
    en: "Iron Valiant",
    ko: "무쇠무인",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1007,
    slug: "koraidon",
    en: "Koraidon",
    ko: "코라이돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1008,
    slug: "miraidon",
    en: "Miraidon",
    ko: "미라이돈",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1009,
    slug: "walking-wake",
    en: "Walking Wake",
    ko: "굽이치는물결",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1010,
    slug: "iron-leaves",
    en: "Iron Leaves",
    ko: "무쇠잎새",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1011,
    slug: "dipplin",
    en: "Dipplin",
    ko: "과미르",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1012,
    slug: "poltchageist",
    en: "Poltchageist",
    ko: "차데스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1013,
    slug: "sinistcha",
    en: "Sinistcha",
    ko: "그우린차",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1014,
    slug: "okidogi",
    en: "Okidogi",
    ko: "조타구",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1015,
    slug: "munkidori",
    en: "Munkidori",
    ko: "이야후",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1016,
    slug: "fezandipiti",
    en: "Fezandipiti",
    ko: "기로치",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1017,
    slug: "ogerpon-cornerstone-mask",
    en: "Ogerpon (Cornerstone Mask)",
    ko: "오거폰 (주춧돌가면)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1017,
    slug: "ogerpon-hearthflame-mask",
    en: "Ogerpon (Hearthflame Mask)",
    ko: "오거폰 (화덕의가면)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1017,
    slug: "ogerpon-teal-mask",
    en: "Ogerpon (Teal Mask)",
    ko: "오거폰 (벽록의가면)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1017,
    slug: "ogerpon-wellspring-mask",
    en: "Ogerpon (Wellspring Mask)",
    ko: "오거폰 (우물가면)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1018,
    slug: "archaludon",
    en: "Archaludon",
    ko: "브리두라스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1019,
    slug: "hydrapple",
    en: "Hydrapple",
    ko: "과미드라",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1020,
    slug: "gouging-fire",
    en: "Gouging Fire",
    ko: "꿰뚫는화염",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1021,
    slug: "raging-bolt",
    en: "Raging Bolt",
    ko: "날뛰는우레",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1022,
    slug: "iron-boulder",
    en: "Iron Boulder",
    ko: "무쇠암석",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1023,
    slug: "iron-crown",
    en: "Iron Crown",
    ko: "무쇠감투",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1024,
    slug: "terapagos",
    en: "Terapagos",
    ko: "테라파고스",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1024,
    slug: "terapagos-terastal",
    en: "Terapagos (Terastal Form)",
    ko: "테라파고스 (테라스탈폼)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1025,
    slug: "pecharunt",
    en: "Pecharunt",
    ko: "복숭악동",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 901,
    slug: "ursaluna-blood-moon",
    en: "Ursaluna (Bloodmoon)",
    ko: "다투곰(붉은 달)",
    category: "form",
    is_form: true,
    source: "images/normal/ursaluna-blood-moon.webp"
  }
];

// data/pokemon-background-types.json
var pokemon_background_types_default = {
  bySlug: {
    bulbasaur: [
      "grass",
      "poison"
    ],
    ivysaur: [
      "grass",
      "poison"
    ],
    venusaur: [
      "grass",
      "poison"
    ],
    "mega-venusaur": [
      "grass",
      "poison"
    ],
    "venusaur-gigantamax": [
      "grass",
      "poison"
    ],
    charmander: [
      "fire"
    ],
    charmeleon: [
      "fire"
    ],
    charizard: [
      "fire",
      "flying"
    ],
    "charizard-gigantamax": [
      "fire",
      "flying"
    ],
    "mega-charizard-x": [
      "fire",
      "dragon"
    ],
    "mega-charizard-y": [
      "fire",
      "flying"
    ],
    squirtle: [
      "water"
    ],
    wartortle: [
      "water"
    ],
    blastoise: [
      "water"
    ],
    "blastoise-gigantamax": [
      "water"
    ],
    "mega-blastoise": [
      "water"
    ],
    caterpie: [
      "bug"
    ],
    metapod: [
      "bug"
    ],
    butterfree: [
      "bug",
      "flying"
    ],
    "butterfree-gigantamax": [
      "bug",
      "flying"
    ],
    weedle: [
      "bug",
      "poison"
    ],
    kakuna: [
      "bug",
      "poison"
    ],
    beedrill: [
      "bug",
      "poison"
    ],
    "mega-beedrill": [
      "bug",
      "poison"
    ],
    pidgey: [
      "normal",
      "flying"
    ],
    pidgeotto: [
      "normal",
      "flying"
    ],
    pidgeot: [
      "normal",
      "flying"
    ],
    "mega-pidgeot": [
      "normal",
      "flying"
    ],
    rattata: [
      "normal"
    ],
    "rattata-alolan": [
      "dark",
      "normal"
    ],
    raticate: [
      "normal"
    ],
    "raticate-alolan": [
      "dark",
      "normal"
    ],
    spearow: [
      "normal",
      "flying"
    ],
    fearow: [
      "normal",
      "flying"
    ],
    ekans: [
      "poison"
    ],
    arbok: [
      "poison"
    ],
    pikachu: [
      "electric"
    ],
    "pikachu-gigantamax": [
      "electric"
    ],
    raichu: [
      "electric"
    ],
    "mega-raichu-x": [
      "electric"
    ],
    "mega-raichu-y": [
      "electric"
    ],
    "raichu-alolan": [
      "electric",
      "psychic"
    ],
    sandshrew: [
      "ground"
    ],
    "sandshrew-alolan": [
      "ice",
      "steel"
    ],
    sandslash: [
      "ground"
    ],
    "sandslash-alolan": [
      "ice",
      "steel"
    ],
    "nidoran-f": [
      "poison"
    ],
    "nidoran♀": [
      "poison"
    ],
    nidorina: [
      "poison"
    ],
    nidoqueen: [
      "poison",
      "ground"
    ],
    "nidoran-m": [
      "poison"
    ],
    "nidoran♂": [
      "poison"
    ],
    nidorino: [
      "poison"
    ],
    nidoking: [
      "poison",
      "ground"
    ],
    clefairy: [
      "fairy"
    ],
    clefable: [
      "fairy"
    ],
    "mega-clefable": [
      "fairy",
      "flying"
    ],
    vulpix: [
      "fire"
    ],
    "vulpix-alolan": [
      "ice"
    ],
    ninetales: [
      "fire"
    ],
    "ninetales-alolan": [
      "ice",
      "fairy"
    ],
    jigglypuff: [
      "normal",
      "fairy"
    ],
    wigglytuff: [
      "normal",
      "fairy"
    ],
    zubat: [
      "poison",
      "flying"
    ],
    golbat: [
      "poison",
      "flying"
    ],
    oddish: [
      "grass",
      "poison"
    ],
    gloom: [
      "grass",
      "poison"
    ],
    vileplume: [
      "grass",
      "poison"
    ],
    paras: [
      "bug",
      "grass"
    ],
    parasect: [
      "bug",
      "grass"
    ],
    venonat: [
      "bug",
      "poison"
    ],
    venomoth: [
      "bug",
      "poison"
    ],
    diglett: [
      "ground"
    ],
    "diglett-alolan": [
      "ground",
      "steel"
    ],
    dugtrio: [
      "ground"
    ],
    "dugtrio-alolan": [
      "ground",
      "steel"
    ],
    meowth: [
      "normal"
    ],
    "meowth-alolan": [
      "dark"
    ],
    "meowth-galarian": [
      "steel"
    ],
    "meowth-gigantamax": [
      "normal"
    ],
    persian: [
      "normal"
    ],
    "persian-alolan": [
      "dark"
    ],
    psyduck: [
      "water"
    ],
    golduck: [
      "water"
    ],
    mankey: [
      "fighting"
    ],
    primeape: [
      "fighting"
    ],
    growlithe: [
      "fire"
    ],
    "growlithe-hisuian": [
      "fire",
      "rock"
    ],
    arcanine: [
      "fire"
    ],
    "arcanine-hisuian": [
      "fire",
      "rock"
    ],
    poliwag: [
      "water"
    ],
    poliwhirl: [
      "water"
    ],
    poliwrath: [
      "water",
      "fighting"
    ],
    abra: [
      "psychic"
    ],
    kadabra: [
      "psychic"
    ],
    alakazam: [
      "psychic"
    ],
    "mega-alakazam": [
      "psychic"
    ],
    machop: [
      "fighting"
    ],
    machoke: [
      "fighting"
    ],
    machamp: [
      "fighting"
    ],
    "machamp-gigantamax": [
      "fighting"
    ],
    bellsprout: [
      "grass",
      "poison"
    ],
    weepinbell: [
      "grass",
      "poison"
    ],
    victreebel: [
      "grass",
      "poison"
    ],
    "mega-victreebel": [
      "grass",
      "poison"
    ],
    tentacool: [
      "water",
      "poison"
    ],
    tentacruel: [
      "water",
      "poison"
    ],
    geodude: [
      "rock",
      "ground"
    ],
    "geodude-alolan": [
      "rock",
      "electric"
    ],
    graveler: [
      "rock",
      "ground"
    ],
    "graveler-alolan": [
      "rock",
      "electric"
    ],
    golem: [
      "rock",
      "ground"
    ],
    "golem-alolan": [
      "rock",
      "electric"
    ],
    ponyta: [
      "fire"
    ],
    "ponyta-galarian": [
      "psychic"
    ],
    rapidash: [
      "fire"
    ],
    "rapidash-galarian": [
      "psychic",
      "fairy"
    ],
    slowpoke: [
      "water",
      "psychic"
    ],
    "slowpoke-galarian": [
      "psychic"
    ],
    slowbro: [
      "water",
      "psychic"
    ],
    "mega-slowbro": [
      "water",
      "psychic"
    ],
    "slowbro-galarian": [
      "poison",
      "psychic"
    ],
    magnemite: [
      "electric",
      "steel"
    ],
    magneton: [
      "electric",
      "steel"
    ],
    farfetchd: [
      "normal",
      "flying"
    ],
    "farfetch’d": [
      "normal",
      "flying"
    ],
    "farfetchd-galarian": [
      "fighting"
    ],
    doduo: [
      "normal",
      "flying"
    ],
    dodrio: [
      "normal",
      "flying"
    ],
    seel: [
      "water"
    ],
    dewgong: [
      "water",
      "ice"
    ],
    grimer: [
      "poison"
    ],
    "grimer-alolan": [
      "poison",
      "dark"
    ],
    muk: [
      "poison"
    ],
    "muk-alolan": [
      "poison",
      "dark"
    ],
    shellder: [
      "water"
    ],
    cloyster: [
      "water",
      "ice"
    ],
    gastly: [
      "ghost",
      "poison"
    ],
    haunter: [
      "ghost",
      "poison"
    ],
    gengar: [
      "ghost",
      "poison"
    ],
    "gengar-gigantamax": [
      "ghost",
      "poison"
    ],
    "mega-gengar": [
      "ghost",
      "poison"
    ],
    onix: [
      "rock",
      "ground"
    ],
    drowzee: [
      "psychic"
    ],
    hypno: [
      "psychic"
    ],
    krabby: [
      "water"
    ],
    kingler: [
      "water"
    ],
    "kingler-gigantamax": [
      "water"
    ],
    voltorb: [
      "electric"
    ],
    "voltorb-hisuian": [
      "electric",
      "grass"
    ],
    electrode: [
      "electric"
    ],
    "electrode-hisuian": [
      "electric",
      "grass"
    ],
    exeggcute: [
      "grass",
      "psychic"
    ],
    exeggutor: [
      "grass",
      "psychic"
    ],
    "exeggutor-alolan": [
      "grass",
      "dragon"
    ],
    cubone: [
      "ground"
    ],
    marowak: [
      "ground"
    ],
    "marowak-alolan": [
      "fire",
      "ghost"
    ],
    hitmonlee: [
      "fighting"
    ],
    hitmonchan: [
      "fighting"
    ],
    lickitung: [
      "normal"
    ],
    koffing: [
      "poison"
    ],
    weezing: [
      "poison"
    ],
    "weezing-galarian": [
      "poison",
      "fairy"
    ],
    rhyhorn: [
      "ground",
      "rock"
    ],
    rhydon: [
      "ground",
      "rock"
    ],
    chansey: [
      "normal"
    ],
    tangela: [
      "grass"
    ],
    kangaskhan: [
      "normal"
    ],
    "mega-kangaskhan": [
      "normal"
    ],
    horsea: [
      "water"
    ],
    seadra: [
      "water"
    ],
    goldeen: [
      "water"
    ],
    seaking: [
      "water"
    ],
    staryu: [
      "water"
    ],
    starmie: [
      "water",
      "psychic"
    ],
    "mega-starmie": [
      "water",
      "psychic"
    ],
    "mr.-mime": [
      "psychic",
      "fairy"
    ],
    "mr-mime": [
      "psychic",
      "fairy"
    ],
    "mr-mime-galarian": [
      "ice",
      "psychic"
    ],
    scyther: [
      "bug",
      "flying"
    ],
    jynx: [
      "ice",
      "psychic"
    ],
    electabuzz: [
      "electric"
    ],
    magmar: [
      "fire"
    ],
    pinsir: [
      "bug"
    ],
    "mega-pinsir": [
      "bug",
      "flying"
    ],
    tauros: [
      "normal"
    ],
    "tauros-aqua-breed": [
      "fighting",
      "water"
    ],
    "tauros-blaze-breed": [
      "fighting",
      "fire"
    ],
    "tauros-combat-breed": [
      "fighting"
    ],
    magikarp: [
      "water"
    ],
    gyarados: [
      "water",
      "flying"
    ],
    "mega-gyarados": [
      "water",
      "dark"
    ],
    lapras: [
      "water",
      "ice"
    ],
    "lapras-gigantamax": [
      "water",
      "ice"
    ],
    ditto: [
      "normal"
    ],
    eevee: [
      "normal"
    ],
    "eevee-gigantamax": [
      "normal"
    ],
    vaporeon: [
      "water"
    ],
    jolteon: [
      "electric"
    ],
    flareon: [
      "fire"
    ],
    porygon: [
      "normal"
    ],
    omanyte: [
      "rock",
      "water"
    ],
    omastar: [
      "rock",
      "water"
    ],
    kabuto: [
      "rock",
      "water"
    ],
    kabutops: [
      "rock",
      "water"
    ],
    aerodactyl: [
      "rock",
      "flying"
    ],
    "mega-aerodactyl": [
      "rock",
      "flying"
    ],
    snorlax: [
      "normal"
    ],
    "snorlax-gigantamax": [
      "normal"
    ],
    articuno: [
      "ice",
      "flying"
    ],
    "articuno-galarian": [
      "psychic",
      "flying"
    ],
    zapdos: [
      "electric",
      "flying"
    ],
    "zapdos-galarian": [
      "fighting",
      "flying"
    ],
    moltres: [
      "fire",
      "flying"
    ],
    "moltres-galarian": [
      "dark",
      "flying"
    ],
    dratini: [
      "dragon"
    ],
    dragonair: [
      "dragon"
    ],
    dragonite: [
      "dragon",
      "flying"
    ],
    "mega-dragonite": [
      "dragon",
      "flying"
    ],
    mewtwo: [
      "psychic"
    ],
    "mega-mewtwo-x": [
      "psychic",
      "fighting"
    ],
    "mega-mewtwo-y": [
      "psychic"
    ],
    mew: [
      "psychic"
    ],
    chikorita: [
      "grass"
    ],
    bayleef: [
      "grass"
    ],
    meganium: [
      "grass"
    ],
    "mega-meganium": [
      "grass",
      "fairy"
    ],
    cyndaquil: [
      "fire"
    ],
    quilava: [
      "fire"
    ],
    typhlosion: [
      "fire"
    ],
    "typhlosion-hisuian": [
      "fire",
      "ghost"
    ],
    totodile: [
      "water"
    ],
    croconaw: [
      "water"
    ],
    feraligatr: [
      "water"
    ],
    "mega-feraligatr": [
      "water",
      "dragon"
    ],
    sentret: [
      "normal"
    ],
    furret: [
      "normal"
    ],
    hoothoot: [
      "normal",
      "flying"
    ],
    noctowl: [
      "normal",
      "flying"
    ],
    ledyba: [
      "bug",
      "flying"
    ],
    ledian: [
      "bug",
      "flying"
    ],
    spinarak: [
      "bug",
      "poison"
    ],
    ariados: [
      "bug",
      "poison"
    ],
    crobat: [
      "poison",
      "flying"
    ],
    chinchou: [
      "water",
      "electric"
    ],
    lanturn: [
      "water",
      "electric"
    ],
    pichu: [
      "electric"
    ],
    cleffa: [
      "fairy"
    ],
    igglybuff: [
      "normal",
      "fairy"
    ],
    togepi: [
      "fairy"
    ],
    togetic: [
      "fairy",
      "flying"
    ],
    natu: [
      "psychic",
      "flying"
    ],
    xatu: [
      "psychic",
      "flying"
    ],
    mareep: [
      "electric"
    ],
    flaaffy: [
      "electric"
    ],
    ampharos: [
      "electric"
    ],
    "mega-ampharos": [
      "electric",
      "dragon"
    ],
    bellossom: [
      "grass"
    ],
    marill: [
      "water",
      "fairy"
    ],
    azumarill: [
      "water",
      "fairy"
    ],
    sudowoodo: [
      "rock"
    ],
    politoed: [
      "water"
    ],
    hoppip: [
      "grass",
      "flying"
    ],
    skiploom: [
      "grass",
      "flying"
    ],
    jumpluff: [
      "grass",
      "flying"
    ],
    aipom: [
      "normal"
    ],
    sunkern: [
      "grass"
    ],
    sunflora: [
      "grass"
    ],
    yanma: [
      "bug",
      "flying"
    ],
    wooper: [
      "water",
      "ground"
    ],
    "wooper-paldean": [
      "poison",
      "ground"
    ],
    quagsire: [
      "water",
      "ground"
    ],
    espeon: [
      "psychic"
    ],
    umbreon: [
      "dark"
    ],
    murkrow: [
      "dark",
      "flying"
    ],
    slowking: [
      "water",
      "psychic"
    ],
    "slowking-galarian": [
      "poison",
      "psychic"
    ],
    misdreavus: [
      "ghost"
    ],
    unown: [
      "psychic"
    ],
    wobbuffet: [
      "psychic"
    ],
    girafarig: [
      "normal",
      "psychic"
    ],
    pineco: [
      "bug"
    ],
    forretress: [
      "bug",
      "steel"
    ],
    dunsparce: [
      "normal"
    ],
    gligar: [
      "ground",
      "flying"
    ],
    steelix: [
      "steel",
      "ground"
    ],
    "mega-steelix": [
      "steel",
      "ground"
    ],
    snubbull: [
      "fairy"
    ],
    granbull: [
      "fairy"
    ],
    qwilfish: [
      "water",
      "poison"
    ],
    "qwilfish-hisuian": [
      "dark",
      "poison"
    ],
    scizor: [
      "bug",
      "steel"
    ],
    "mega-scizor": [
      "bug",
      "steel"
    ],
    shuckle: [
      "bug",
      "rock"
    ],
    heracross: [
      "bug",
      "fighting"
    ],
    "mega-heracross": [
      "bug",
      "fighting"
    ],
    sneasel: [
      "dark",
      "ice"
    ],
    "sneasel-hisuian": [
      "fighting",
      "poison"
    ],
    teddiursa: [
      "normal"
    ],
    ursaring: [
      "normal"
    ],
    slugma: [
      "fire"
    ],
    magcargo: [
      "fire",
      "rock"
    ],
    swinub: [
      "ice",
      "ground"
    ],
    piloswine: [
      "ice",
      "ground"
    ],
    corsola: [
      "water",
      "rock"
    ],
    "corsola-galarian": [
      "ghost"
    ],
    remoraid: [
      "water"
    ],
    octillery: [
      "water"
    ],
    delibird: [
      "ice",
      "flying"
    ],
    mantine: [
      "water",
      "flying"
    ],
    skarmory: [
      "steel",
      "flying"
    ],
    "mega-skarmory": [
      "steel",
      "flying"
    ],
    houndour: [
      "dark",
      "fire"
    ],
    houndoom: [
      "dark",
      "fire"
    ],
    "mega-houndoom": [
      "dark",
      "fire"
    ],
    kingdra: [
      "water",
      "dragon"
    ],
    phanpy: [
      "ground"
    ],
    donphan: [
      "ground"
    ],
    porygon2: [
      "normal"
    ],
    stantler: [
      "normal"
    ],
    smeargle: [
      "normal"
    ],
    tyrogue: [
      "fighting"
    ],
    hitmontop: [
      "fighting"
    ],
    smoochum: [
      "ice",
      "psychic"
    ],
    elekid: [
      "electric"
    ],
    magby: [
      "fire"
    ],
    miltank: [
      "normal"
    ],
    blissey: [
      "normal"
    ],
    raikou: [
      "electric"
    ],
    entei: [
      "fire"
    ],
    suicune: [
      "water"
    ],
    larvitar: [
      "rock",
      "ground"
    ],
    pupitar: [
      "rock",
      "ground"
    ],
    tyranitar: [
      "rock",
      "dark"
    ],
    "mega-tyranitar": [
      "rock",
      "dark"
    ],
    lugia: [
      "psychic",
      "flying"
    ],
    "ho-oh": [
      "fire",
      "flying"
    ],
    celebi: [
      "psychic",
      "grass"
    ],
    treecko: [
      "grass"
    ],
    grovyle: [
      "grass"
    ],
    sceptile: [
      "grass"
    ],
    "mega-sceptile": [
      "grass",
      "dragon"
    ],
    torchic: [
      "fire"
    ],
    combusken: [
      "fire",
      "fighting"
    ],
    blaziken: [
      "fire",
      "fighting"
    ],
    "mega-blaziken": [
      "fire",
      "fighting"
    ],
    mudkip: [
      "water"
    ],
    marshtomp: [
      "water",
      "ground"
    ],
    swampert: [
      "water",
      "ground"
    ],
    "mega-swampert": [
      "water",
      "ground"
    ],
    poochyena: [
      "dark"
    ],
    mightyena: [
      "dark"
    ],
    zigzagoon: [
      "normal"
    ],
    "zigzagoon-galarian": [
      "dark",
      "normal"
    ],
    linoone: [
      "normal"
    ],
    "linoone-galarian": [
      "dark",
      "normal"
    ],
    wurmple: [
      "bug"
    ],
    silcoon: [
      "bug"
    ],
    beautifly: [
      "bug",
      "flying"
    ],
    cascoon: [
      "bug"
    ],
    dustox: [
      "bug",
      "poison"
    ],
    lotad: [
      "water",
      "grass"
    ],
    lombre: [
      "water",
      "grass"
    ],
    ludicolo: [
      "water",
      "grass"
    ],
    seedot: [
      "grass"
    ],
    nuzleaf: [
      "grass",
      "dark"
    ],
    shiftry: [
      "grass",
      "dark"
    ],
    taillow: [
      "normal",
      "flying"
    ],
    swellow: [
      "normal",
      "flying"
    ],
    wingull: [
      "water",
      "flying"
    ],
    pelipper: [
      "water",
      "flying"
    ],
    ralts: [
      "psychic",
      "fairy"
    ],
    kirlia: [
      "psychic",
      "fairy"
    ],
    gardevoir: [
      "psychic",
      "fairy"
    ],
    "mega-gardevoir": [
      "psychic",
      "fairy"
    ],
    surskit: [
      "bug",
      "water"
    ],
    masquerain: [
      "bug",
      "flying"
    ],
    shroomish: [
      "grass"
    ],
    breloom: [
      "grass",
      "fighting"
    ],
    slakoth: [
      "normal"
    ],
    vigoroth: [
      "normal"
    ],
    slaking: [
      "normal"
    ],
    nincada: [
      "bug",
      "ground"
    ],
    ninjask: [
      "bug",
      "flying"
    ],
    shedinja: [
      "bug",
      "ghost"
    ],
    whismur: [
      "normal"
    ],
    loudred: [
      "normal"
    ],
    exploud: [
      "normal"
    ],
    makuhita: [
      "fighting"
    ],
    hariyama: [
      "fighting"
    ],
    azurill: [
      "normal",
      "fairy"
    ],
    nosepass: [
      "rock"
    ],
    skitty: [
      "normal"
    ],
    delcatty: [
      "normal"
    ],
    sableye: [
      "dark",
      "ghost"
    ],
    "mega-sableye": [
      "dark",
      "ghost"
    ],
    mawile: [
      "steel",
      "fairy"
    ],
    "mega-mawile": [
      "steel",
      "fairy"
    ],
    aron: [
      "steel",
      "rock"
    ],
    lairon: [
      "steel",
      "rock"
    ],
    aggron: [
      "steel",
      "rock"
    ],
    "mega-aggron": [
      "steel"
    ],
    meditite: [
      "fighting",
      "psychic"
    ],
    medicham: [
      "fighting",
      "psychic"
    ],
    "mega-medicham": [
      "fighting",
      "psychic"
    ],
    electrike: [
      "electric"
    ],
    manectric: [
      "electric"
    ],
    "mega-manectric": [
      "electric"
    ],
    plusle: [
      "electric"
    ],
    minun: [
      "electric"
    ],
    volbeat: [
      "bug"
    ],
    illumise: [
      "bug"
    ],
    roselia: [
      "grass",
      "poison"
    ],
    gulpin: [
      "poison"
    ],
    swalot: [
      "poison"
    ],
    carvanha: [
      "water",
      "dark"
    ],
    sharpedo: [
      "water",
      "dark"
    ],
    "mega-sharpedo": [
      "water",
      "dark"
    ],
    wailmer: [
      "water"
    ],
    wailord: [
      "water"
    ],
    numel: [
      "fire",
      "ground"
    ],
    camerupt: [
      "fire",
      "ground"
    ],
    "mega-camerupt": [
      "fire",
      "ground"
    ],
    torkoal: [
      "fire"
    ],
    spoink: [
      "psychic"
    ],
    grumpig: [
      "psychic"
    ],
    spinda: [
      "normal"
    ],
    trapinch: [
      "ground"
    ],
    vibrava: [
      "ground",
      "dragon"
    ],
    flygon: [
      "ground",
      "dragon"
    ],
    cacnea: [
      "grass"
    ],
    cacturne: [
      "grass",
      "dark"
    ],
    swablu: [
      "normal",
      "flying"
    ],
    altaria: [
      "dragon",
      "flying"
    ],
    "mega-altaria": [
      "dragon",
      "fairy"
    ],
    zangoose: [
      "normal"
    ],
    seviper: [
      "poison"
    ],
    lunatone: [
      "rock",
      "psychic"
    ],
    solrock: [
      "rock",
      "psychic"
    ],
    barboach: [
      "water",
      "ground"
    ],
    whiscash: [
      "water",
      "ground"
    ],
    corphish: [
      "water"
    ],
    crawdaunt: [
      "water",
      "dark"
    ],
    baltoy: [
      "ground",
      "psychic"
    ],
    claydol: [
      "ground",
      "psychic"
    ],
    lileep: [
      "rock",
      "grass"
    ],
    cradily: [
      "rock",
      "grass"
    ],
    anorith: [
      "rock",
      "bug"
    ],
    armaldo: [
      "rock",
      "bug"
    ],
    feebas: [
      "water"
    ],
    milotic: [
      "water"
    ],
    castform: [
      "normal"
    ],
    kecleon: [
      "normal"
    ],
    shuppet: [
      "ghost"
    ],
    banette: [
      "ghost"
    ],
    "mega-banette": [
      "ghost"
    ],
    duskull: [
      "ghost"
    ],
    dusclops: [
      "ghost"
    ],
    tropius: [
      "grass",
      "flying"
    ],
    chimecho: [
      "psychic"
    ],
    "mega-chimecho": [
      "psychic",
      "steel"
    ],
    absol: [
      "dark"
    ],
    "mega-absol": [
      "dark"
    ],
    "mega-absol-z": [
      "dark",
      "ghost"
    ],
    wynaut: [
      "psychic"
    ],
    snorunt: [
      "ice"
    ],
    glalie: [
      "ice"
    ],
    "mega-glalie": [
      "ice"
    ],
    spheal: [
      "ice",
      "water"
    ],
    sealeo: [
      "ice",
      "water"
    ],
    walrein: [
      "ice",
      "water"
    ],
    clamperl: [
      "water"
    ],
    huntail: [
      "water"
    ],
    gorebyss: [
      "water"
    ],
    relicanth: [
      "water",
      "rock"
    ],
    luvdisc: [
      "water"
    ],
    bagon: [
      "dragon"
    ],
    shelgon: [
      "dragon"
    ],
    salamence: [
      "dragon",
      "flying"
    ],
    "mega-salamence": [
      "dragon",
      "flying"
    ],
    beldum: [
      "steel",
      "psychic"
    ],
    metang: [
      "steel",
      "psychic"
    ],
    metagross: [
      "steel",
      "psychic"
    ],
    "mega-metagross": [
      "steel",
      "psychic"
    ],
    regirock: [
      "rock"
    ],
    regice: [
      "ice"
    ],
    registeel: [
      "steel"
    ],
    latias: [
      "dragon",
      "psychic"
    ],
    "mega-latias": [
      "dragon",
      "psychic"
    ],
    latios: [
      "dragon",
      "psychic"
    ],
    "mega-latios": [
      "dragon",
      "psychic"
    ],
    kyogre: [
      "water"
    ],
    "primal-kyogre": [
      "water"
    ],
    groudon: [
      "ground"
    ],
    "primal-groudon": [
      "ground",
      "fire"
    ],
    rayquaza: [
      "dragon",
      "flying"
    ],
    "mega-rayquaza": [
      "dragon",
      "flying"
    ],
    jirachi: [
      "steel",
      "psychic"
    ],
    deoxys: [
      "psychic"
    ],
    "deoxys-attack-forme": [
      "psychic"
    ],
    "deoxys-defense-forme": [
      "psychic"
    ],
    "deoxys-speed-forme": [
      "psychic"
    ],
    turtwig: [
      "grass"
    ],
    grotle: [
      "grass"
    ],
    torterra: [
      "grass",
      "ground"
    ],
    chimchar: [
      "fire"
    ],
    monferno: [
      "fire",
      "fighting"
    ],
    infernape: [
      "fire",
      "fighting"
    ],
    piplup: [
      "water"
    ],
    prinplup: [
      "water"
    ],
    empoleon: [
      "water",
      "steel"
    ],
    starly: [
      "normal",
      "flying"
    ],
    staravia: [
      "normal",
      "flying"
    ],
    staraptor: [
      "normal",
      "flying"
    ],
    "mega-staraptor": [
      "fighting",
      "flying"
    ],
    bidoof: [
      "normal"
    ],
    bibarel: [
      "normal",
      "water"
    ],
    kricketot: [
      "bug"
    ],
    kricketune: [
      "bug"
    ],
    shinx: [
      "electric"
    ],
    luxio: [
      "electric"
    ],
    luxray: [
      "electric"
    ],
    budew: [
      "grass",
      "poison"
    ],
    roserade: [
      "grass",
      "poison"
    ],
    cranidos: [
      "rock"
    ],
    rampardos: [
      "rock"
    ],
    shieldon: [
      "rock",
      "steel"
    ],
    bastiodon: [
      "rock",
      "steel"
    ],
    "burmy-plant-cloak": [
      "bug"
    ],
    "wormadam-plant-cloak": [
      "bug",
      "grass"
    ],
    "wormadam-sandy-cloak": [
      "bug",
      "ground"
    ],
    "wormadam-trash-cloak": [
      "bug",
      "steel"
    ],
    mothim: [
      "bug",
      "flying"
    ],
    combee: [
      "bug",
      "flying"
    ],
    vespiquen: [
      "bug",
      "flying"
    ],
    pachirisu: [
      "electric"
    ],
    buizel: [
      "water"
    ],
    floatzel: [
      "water"
    ],
    cherubi: [
      "grass"
    ],
    cherrim: [
      "grass"
    ],
    shellos: [
      "water"
    ],
    gastrodon: [
      "water",
      "ground"
    ],
    ambipom: [
      "normal"
    ],
    drifloon: [
      "ghost",
      "flying"
    ],
    drifblim: [
      "ghost",
      "flying"
    ],
    buneary: [
      "normal"
    ],
    lopunny: [
      "normal"
    ],
    "mega-lopunny": [
      "normal",
      "fighting"
    ],
    mismagius: [
      "ghost"
    ],
    honchkrow: [
      "dark",
      "flying"
    ],
    glameow: [
      "normal"
    ],
    purugly: [
      "normal"
    ],
    chingling: [
      "psychic"
    ],
    stunky: [
      "poison",
      "dark"
    ],
    skuntank: [
      "poison",
      "dark"
    ],
    bronzor: [
      "steel",
      "psychic"
    ],
    bronzong: [
      "steel",
      "psychic"
    ],
    bonsly: [
      "rock"
    ],
    "mime-jr": [
      "psychic",
      "fairy"
    ],
    happiny: [
      "normal"
    ],
    chatot: [
      "normal",
      "flying"
    ],
    spiritomb: [
      "ghost",
      "dark"
    ],
    gible: [
      "dragon",
      "ground"
    ],
    gabite: [
      "dragon",
      "ground"
    ],
    garchomp: [
      "dragon",
      "ground"
    ],
    "mega-garchomp": [
      "dragon",
      "ground"
    ],
    "mega-garchomp-z": [
      "dragon"
    ],
    munchlax: [
      "normal"
    ],
    riolu: [
      "fighting"
    ],
    lucario: [
      "fighting",
      "steel"
    ],
    "mega-lucario": [
      "fighting",
      "steel"
    ],
    "mega-lucario-z": [
      "fighting",
      "steel"
    ],
    hippopotas: [
      "ground"
    ],
    hippowdon: [
      "ground"
    ],
    skorupi: [
      "poison",
      "bug"
    ],
    drapion: [
      "poison",
      "dark"
    ],
    croagunk: [
      "poison",
      "fighting"
    ],
    toxicroak: [
      "poison",
      "fighting"
    ],
    carnivine: [
      "grass"
    ],
    finneon: [
      "water"
    ],
    lumineon: [
      "water"
    ],
    mantyke: [
      "water",
      "flying"
    ],
    snover: [
      "grass",
      "ice"
    ],
    abomasnow: [
      "grass",
      "ice"
    ],
    "mega-abomasnow": [
      "grass",
      "ice"
    ],
    weavile: [
      "dark",
      "ice"
    ],
    magnezone: [
      "electric",
      "steel"
    ],
    lickilicky: [
      "normal"
    ],
    rhyperior: [
      "ground",
      "rock"
    ],
    tangrowth: [
      "grass"
    ],
    electivire: [
      "electric"
    ],
    magmortar: [
      "fire"
    ],
    togekiss: [
      "fairy",
      "flying"
    ],
    yanmega: [
      "bug",
      "flying"
    ],
    leafeon: [
      "grass"
    ],
    glaceon: [
      "ice"
    ],
    gliscor: [
      "ground",
      "flying"
    ],
    mamoswine: [
      "ice",
      "ground"
    ],
    "porygon-z": [
      "normal"
    ],
    gallade: [
      "psychic",
      "fighting"
    ],
    "mega-gallade": [
      "psychic",
      "fighting"
    ],
    probopass: [
      "rock",
      "steel"
    ],
    dusknoir: [
      "ghost"
    ],
    froslass: [
      "ice",
      "ghost"
    ],
    "mega-froslass": [
      "ice",
      "ghost"
    ],
    rotom: [
      "electric",
      "ghost"
    ],
    "fan-rotom": [
      "electric",
      "flying"
    ],
    "frost-rotom": [
      "electric",
      "ice"
    ],
    "heat-rotom": [
      "electric",
      "fire"
    ],
    "mow-rotom": [
      "electric",
      "grass"
    ],
    "wash-rotom": [
      "electric",
      "water"
    ],
    uxie: [
      "psychic"
    ],
    mesprit: [
      "psychic"
    ],
    azelf: [
      "psychic"
    ],
    dialga: [
      "steel",
      "dragon"
    ],
    palkia: [
      "water",
      "dragon"
    ],
    heatran: [
      "fire",
      "steel"
    ],
    "mega-heatran": [
      "fire",
      "steel"
    ],
    regigigas: [
      "normal"
    ],
    "giratina-another-forme": [
      "ghost",
      "dragon"
    ],
    "giratina-origin-forme": [
      "ghost",
      "dragon"
    ],
    cresselia: [
      "psychic"
    ],
    phione: [
      "water"
    ],
    manaphy: [
      "water"
    ],
    darkrai: [
      "dark"
    ],
    "mega-darkrai": [
      "dark"
    ],
    "shaymin-land-forme": [
      "grass"
    ],
    "shaymin-sky-forme": [
      "grass",
      "flying"
    ],
    arceus: [
      "normal"
    ],
    victini: [
      "psychic",
      "fire"
    ],
    snivy: [
      "grass"
    ],
    servine: [
      "grass"
    ],
    serperior: [
      "grass"
    ],
    tepig: [
      "fire"
    ],
    pignite: [
      "fire",
      "fighting"
    ],
    emboar: [
      "fire",
      "fighting"
    ],
    "mega-emboar": [
      "fire",
      "fighting"
    ],
    oshawott: [
      "water"
    ],
    dewott: [
      "water"
    ],
    samurott: [
      "water"
    ],
    "samurott-hisuian": [
      "water",
      "dark"
    ],
    patrat: [
      "normal"
    ],
    watchog: [
      "normal"
    ],
    lillipup: [
      "normal"
    ],
    herdier: [
      "normal"
    ],
    stoutland: [
      "normal"
    ],
    purrloin: [
      "dark"
    ],
    liepard: [
      "dark"
    ],
    pansage: [
      "grass"
    ],
    simisage: [
      "grass"
    ],
    pansear: [
      "fire"
    ],
    simisear: [
      "fire"
    ],
    panpour: [
      "water"
    ],
    simipour: [
      "water"
    ],
    munna: [
      "psychic"
    ],
    musharna: [
      "psychic"
    ],
    pidove: [
      "normal",
      "flying"
    ],
    tranquill: [
      "normal",
      "flying"
    ],
    unfezant: [
      "normal",
      "flying"
    ],
    blitzle: [
      "electric"
    ],
    zebstrika: [
      "electric"
    ],
    roggenrola: [
      "rock"
    ],
    boldore: [
      "rock"
    ],
    gigalith: [
      "rock"
    ],
    woobat: [
      "psychic",
      "flying"
    ],
    swoobat: [
      "psychic",
      "flying"
    ],
    drilbur: [
      "ground"
    ],
    excadrill: [
      "ground",
      "steel"
    ],
    "mega-excadrill": [
      "ground",
      "steel"
    ],
    audino: [
      "normal"
    ],
    "mega-audino": [
      "normal",
      "fairy"
    ],
    timburr: [
      "fighting"
    ],
    gurdurr: [
      "fighting"
    ],
    conkeldurr: [
      "fighting"
    ],
    tympole: [
      "water"
    ],
    palpitoad: [
      "water",
      "ground"
    ],
    seismitoad: [
      "water",
      "ground"
    ],
    throh: [
      "fighting"
    ],
    sawk: [
      "fighting"
    ],
    sewaddle: [
      "bug",
      "grass"
    ],
    swadloon: [
      "bug",
      "grass"
    ],
    leavanny: [
      "bug",
      "grass"
    ],
    venipede: [
      "bug",
      "poison"
    ],
    whirlipede: [
      "bug",
      "poison"
    ],
    scolipede: [
      "bug",
      "poison"
    ],
    "mega-scolipede": [
      "bug",
      "poison"
    ],
    cottonee: [
      "grass",
      "fairy"
    ],
    whimsicott: [
      "grass",
      "fairy"
    ],
    petilil: [
      "grass"
    ],
    lilligant: [
      "grass"
    ],
    "lilligant-hisuian": [
      "grass",
      "fighting"
    ],
    "basculin-red-striped": [
      "water"
    ],
    sandile: [
      "ground",
      "dark"
    ],
    krokorok: [
      "ground",
      "dark"
    ],
    krookodile: [
      "ground",
      "dark"
    ],
    darumaka: [
      "fire"
    ],
    "darumaka-galarian": [
      "ice"
    ],
    darmanitan: [
      "fire"
    ],
    "darmanitan-galarian": [
      "ice"
    ],
    maractus: [
      "grass"
    ],
    dwebble: [
      "bug",
      "rock"
    ],
    crustle: [
      "bug",
      "rock"
    ],
    scraggy: [
      "dark",
      "fighting"
    ],
    scrafty: [
      "dark",
      "fighting"
    ],
    "mega-scrafty": [
      "dark",
      "fighting"
    ],
    sigilyph: [
      "psychic",
      "flying"
    ],
    yamask: [
      "ghost"
    ],
    "yamask-galarian": [
      "ground",
      "ghost"
    ],
    cofagrigus: [
      "ghost"
    ],
    tirtouga: [
      "water",
      "rock"
    ],
    carracosta: [
      "water",
      "rock"
    ],
    archen: [
      "rock",
      "flying"
    ],
    archeops: [
      "rock",
      "flying"
    ],
    trubbish: [
      "poison"
    ],
    garbodor: [
      "poison"
    ],
    "garbodor-gigantamax": [
      "poison"
    ],
    zorua: [
      "dark"
    ],
    "zorua-hisuian": [
      "normal",
      "ghost"
    ],
    zoroark: [
      "dark"
    ],
    "zoroark-hisuian": [
      "normal",
      "ghost"
    ],
    minccino: [
      "normal"
    ],
    cinccino: [
      "normal"
    ],
    gothita: [
      "psychic"
    ],
    gothorita: [
      "psychic"
    ],
    gothitelle: [
      "psychic"
    ],
    solosis: [
      "psychic"
    ],
    duosion: [
      "psychic"
    ],
    reuniclus: [
      "psychic"
    ],
    ducklett: [
      "water",
      "flying"
    ],
    swanna: [
      "water",
      "flying"
    ],
    vanillite: [
      "ice"
    ],
    vanillish: [
      "ice"
    ],
    vanilluxe: [
      "ice"
    ],
    deerling: [
      "normal",
      "grass"
    ],
    sawsbuck: [
      "normal",
      "grass"
    ],
    emolga: [
      "electric",
      "flying"
    ],
    karrablast: [
      "bug"
    ],
    escavalier: [
      "bug",
      "steel"
    ],
    foongus: [
      "grass",
      "poison"
    ],
    amoonguss: [
      "grass",
      "poison"
    ],
    frillish: [
      "water",
      "ghost"
    ],
    jellicent: [
      "water",
      "ghost"
    ],
    alomomola: [
      "water"
    ],
    joltik: [
      "bug",
      "electric"
    ],
    galvantula: [
      "bug",
      "electric"
    ],
    ferroseed: [
      "grass",
      "steel"
    ],
    ferrothorn: [
      "grass",
      "steel"
    ],
    klink: [
      "steel"
    ],
    klang: [
      "steel"
    ],
    klinklang: [
      "steel"
    ],
    tynamo: [
      "electric"
    ],
    eelektrik: [
      "electric"
    ],
    eelektross: [
      "electric"
    ],
    "mega-eelektross": [
      "electric"
    ],
    elgyem: [
      "psychic"
    ],
    beheeyem: [
      "psychic"
    ],
    litwick: [
      "ghost",
      "fire"
    ],
    lampent: [
      "ghost",
      "fire"
    ],
    chandelure: [
      "ghost",
      "fire"
    ],
    "mega-chandelure": [
      "ghost",
      "fire"
    ],
    axew: [
      "dragon"
    ],
    fraxure: [
      "dragon"
    ],
    haxorus: [
      "dragon"
    ],
    cubchoo: [
      "ice"
    ],
    beartic: [
      "ice"
    ],
    cryogonal: [
      "ice"
    ],
    shelmet: [
      "bug"
    ],
    accelgor: [
      "bug"
    ],
    stunfisk: [
      "ground",
      "electric"
    ],
    "stunfisk-galarian": [
      "ground",
      "steel"
    ],
    mienfoo: [
      "fighting"
    ],
    mienshao: [
      "fighting"
    ],
    druddigon: [
      "dragon"
    ],
    golett: [
      "ground",
      "ghost"
    ],
    golurk: [
      "ground",
      "ghost"
    ],
    "mega-golurk": [
      "ground",
      "ghost"
    ],
    pawniard: [
      "dark",
      "steel"
    ],
    bisharp: [
      "dark",
      "steel"
    ],
    bouffalant: [
      "normal"
    ],
    rufflet: [
      "normal",
      "flying"
    ],
    braviary: [
      "normal",
      "flying"
    ],
    braviaryhisuian: [
      "psychic",
      "flying"
    ],
    vullaby: [
      "dark",
      "flying"
    ],
    mandibuzz: [
      "dark",
      "flying"
    ],
    heatmor: [
      "fire"
    ],
    durant: [
      "bug",
      "steel"
    ],
    deino: [
      "dark",
      "dragon"
    ],
    zweilous: [
      "dark",
      "dragon"
    ],
    hydreigon: [
      "dark",
      "dragon"
    ],
    larvesta: [
      "bug",
      "fire"
    ],
    volcarona: [
      "bug",
      "fire"
    ],
    cobalion: [
      "steel",
      "fighting"
    ],
    terrakion: [
      "rock",
      "fighting"
    ],
    virizion: [
      "grass",
      "fighting"
    ],
    "tornadus-incarnate": [
      "flying"
    ],
    "tornadus-therian": [
      "flying"
    ],
    "thundurus-incarnate": [
      "electric",
      "flying"
    ],
    "thundurus-therian": [
      "electric",
      "flying"
    ],
    reshiram: [
      "dragon",
      "fire"
    ],
    zekrom: [
      "dragon",
      "electric"
    ],
    "landorus-incarnate": [
      "ground",
      "flying"
    ],
    "landorus-therian": [
      "ground",
      "flying"
    ],
    "black-kyurem": [
      "dragon",
      "ice"
    ],
    kyurem: [
      "dragon",
      "ice"
    ],
    "white-kyurem": [
      "dragon",
      "ice"
    ],
    keldeo: [
      "water",
      "fighting"
    ],
    "meloetta-aria": [
      "normal",
      "psychic"
    ],
    "meloetta-pirouette": [
      "normal",
      "fighting"
    ],
    genesect: [
      "bug",
      "steel"
    ],
    chespin: [
      "grass"
    ],
    quilladin: [
      "grass"
    ],
    chesnaught: [
      "grass",
      "fighting"
    ],
    "mega-chesnaught": [
      "grass",
      "fighting"
    ],
    fennekin: [
      "fire"
    ],
    braixen: [
      "fire"
    ],
    delphox: [
      "fire",
      "psychic"
    ],
    "mega-delphox": [
      "fire",
      "psychic"
    ],
    froakie: [
      "water"
    ],
    frogadier: [
      "water"
    ],
    "ash-greninja": [
      "water",
      "dark"
    ],
    greninja: [
      "water",
      "dark"
    ],
    "mega-greninja": [
      "water",
      "dark"
    ],
    bunnelby: [
      "normal"
    ],
    diggersby: [
      "normal",
      "ground"
    ],
    fletchling: [
      "normal",
      "flying"
    ],
    fletchinder: [
      "fire",
      "flying"
    ],
    talonflame: [
      "fire",
      "flying"
    ],
    scatterbug: [
      "bug"
    ],
    spewpa: [
      "bug"
    ],
    vivillon: [
      "bug",
      "flying"
    ],
    litleo: [
      "fire",
      "normal"
    ],
    pyroar: [
      "fire",
      "normal"
    ],
    "mega-pyroar": [
      "fire",
      "normal"
    ],
    flabebe: [
      "fairy"
    ],
    floette: [
      "fairy"
    ],
    "floette-eternal-flower": [
      "fairy"
    ],
    "mega-floette": [
      "fairy"
    ],
    florges: [
      "fairy"
    ],
    skiddo: [
      "grass"
    ],
    gogoat: [
      "grass"
    ],
    pancham: [
      "fighting"
    ],
    pangoro: [
      "fighting",
      "dark"
    ],
    furfrou: [
      "normal"
    ],
    espurr: [
      "psychic"
    ],
    "mega-meowstic": [
      "psychic"
    ],
    "meowstic-f": [
      "psychic"
    ],
    "meowstic-m": [
      "psychic"
    ],
    honedge: [
      "steel",
      "ghost"
    ],
    doublade: [
      "steel",
      "ghost"
    ],
    aegislash: [
      "steel",
      "ghost"
    ],
    spritzee: [
      "fairy"
    ],
    aromatisse: [
      "fairy"
    ],
    swirlix: [
      "fairy"
    ],
    slurpuff: [
      "fairy"
    ],
    inkay: [
      "dark",
      "psychic"
    ],
    malamar: [
      "dark",
      "psychic"
    ],
    "mega-malamar": [
      "dark",
      "psychic"
    ],
    binacle: [
      "rock",
      "water"
    ],
    barbaracle: [
      "rock",
      "water"
    ],
    "mega-barbaracle": [
      "rock",
      "fighting"
    ],
    skrelp: [
      "poison",
      "water"
    ],
    dragalge: [
      "poison",
      "dragon"
    ],
    "mega-dragalge": [
      "poison",
      "dragon"
    ],
    clauncher: [
      "water"
    ],
    clawitzer: [
      "water"
    ],
    helioptile: [
      "electric",
      "normal"
    ],
    heliolisk: [
      "electric",
      "normal"
    ],
    tyrunt: [
      "rock",
      "dragon"
    ],
    tyrantrum: [
      "rock",
      "dragon"
    ],
    amaura: [
      "rock",
      "ice"
    ],
    aurorus: [
      "rock",
      "ice"
    ],
    sylveon: [
      "fairy"
    ],
    hawlucha: [
      "fighting",
      "flying"
    ],
    "mega-hawlucha": [
      "fighting",
      "flying"
    ],
    dedenne: [
      "electric",
      "fairy"
    ],
    carbink: [
      "rock",
      "fairy"
    ],
    goomy: [
      "dragon"
    ],
    sliggoo: [
      "dragon"
    ],
    "sliggoo-hisuian": [
      "steel",
      "dragon"
    ],
    goodra: [
      "dragon"
    ],
    "goodra-hisuian": [
      "steel",
      "dragon"
    ],
    klefki: [
      "steel",
      "fairy"
    ],
    phantump: [
      "ghost",
      "grass"
    ],
    trevenant: [
      "ghost",
      "grass"
    ],
    pumpkaboo: [
      "ghost",
      "grass"
    ],
    gourgeist: [
      "ghost",
      "grass"
    ],
    bergmite: [
      "ice"
    ],
    avalugg: [
      "ice"
    ],
    "avalugg-hisuian": [
      "ice",
      "rock"
    ],
    noibat: [
      "flying",
      "dragon"
    ],
    noivern: [
      "flying",
      "dragon"
    ],
    xerneas: [
      "fairy"
    ],
    yveltal: [
      "dark",
      "flying"
    ],
    "mega-zygarde": [
      "dragon",
      "ground"
    ],
    "zygarde-10-forme": [
      "dragon",
      "ground"
    ],
    "zygarde-50-forme": [
      "dragon",
      "ground"
    ],
    "zygarde-complete-forme": [
      "dragon",
      "ground"
    ],
    diancie: [
      "rock",
      "fairy"
    ],
    "mega-diancie": [
      "rock",
      "fairy"
    ],
    "hoopa-confined": [
      "psychic",
      "ghost"
    ],
    "hoopa-unbound": [
      "psychic",
      "dark"
    ],
    volcanion: [
      "fire",
      "water"
    ],
    rowlet: [
      "grass",
      "flying"
    ],
    dartrix: [
      "grass",
      "flying"
    ],
    decidueye: [
      "grass",
      "ghost"
    ],
    "decidueye-hisuian": [
      "grass",
      "fighting"
    ],
    litten: [
      "fire"
    ],
    torracat: [
      "fire"
    ],
    incineroar: [
      "fire",
      "dark"
    ],
    popplio: [
      "water"
    ],
    brionne: [
      "water"
    ],
    primarina: [
      "water",
      "fairy"
    ],
    pikipek: [
      "normal",
      "flying"
    ],
    trumbeak: [
      "normal",
      "flying"
    ],
    toucannon: [
      "normal",
      "flying"
    ],
    yungoos: [
      "normal"
    ],
    gumshoos: [
      "normal"
    ],
    grubbin: [
      "bug"
    ],
    charjabug: [
      "bug",
      "electric"
    ],
    vikavolt: [
      "bug",
      "electric"
    ],
    crabrawler: [
      "fighting"
    ],
    crabominable: [
      "fighting",
      "ice"
    ],
    "mega-crabominable": [
      "fighting",
      "ice"
    ],
    "oricorio-baile": [
      "fire",
      "flying"
    ],
    "oricorio-pau": [
      "psychic",
      "flying"
    ],
    "oricorio-pom-pom": [
      "electric",
      "flying"
    ],
    "oricorio-sensu": [
      "ghost",
      "flying"
    ],
    cutiefly: [
      "bug",
      "fairy"
    ],
    ribombee: [
      "bug",
      "fairy"
    ],
    rockruff: [
      "rock"
    ],
    "lycanroc-dusk": [
      "rock"
    ],
    "lycanroc-midday": [
      "rock"
    ],
    "lycanroc-midnight": [
      "rock"
    ],
    "wishiwashi-school": [
      "water"
    ],
    mareanie: [
      "poison",
      "water"
    ],
    toxapex: [
      "poison",
      "water"
    ],
    mudbray: [
      "ground"
    ],
    mudsdale: [
      "ground"
    ],
    dewpider: [
      "water",
      "bug"
    ],
    araquanid: [
      "water",
      "bug"
    ],
    fomantis: [
      "grass"
    ],
    lurantis: [
      "grass"
    ],
    morelull: [
      "grass",
      "fairy"
    ],
    shiinotic: [
      "grass",
      "fairy"
    ],
    salandit: [
      "poison",
      "fire"
    ],
    salazzle: [
      "poison",
      "fire"
    ],
    stufful: [
      "normal",
      "fighting"
    ],
    bewear: [
      "normal",
      "fighting"
    ],
    bounsweet: [
      "grass"
    ],
    steenee: [
      "grass"
    ],
    tsareena: [
      "grass"
    ],
    comfey: [
      "fairy"
    ],
    oranguru: [
      "normal",
      "psychic"
    ],
    passimian: [
      "fighting"
    ],
    wimpod: [
      "bug",
      "water"
    ],
    golisopod: [
      "bug",
      "water"
    ],
    "mega-golisopod": [
      "bug",
      "steel"
    ],
    sandygast: [
      "ghost",
      "ground"
    ],
    palossand: [
      "ghost",
      "ground"
    ],
    pyukumuku: [
      "water"
    ],
    "type-null": [
      "normal"
    ],
    silvally: [
      "normal"
    ],
    "minior-core": [
      "rock",
      "flying"
    ],
    komala: [
      "normal"
    ],
    turtonator: [
      "fire",
      "dragon"
    ],
    togedemaru: [
      "electric",
      "steel"
    ],
    mimikyu: [
      "ghost",
      "fairy"
    ],
    bruxish: [
      "water",
      "psychic"
    ],
    drampa: [
      "normal",
      "dragon"
    ],
    "mega-drampa": [
      "normal",
      "dragon"
    ],
    dhelmise: [
      "ghost",
      "grass"
    ],
    "jangmo-o": [
      "dragon"
    ],
    "hakamo-o": [
      "dragon",
      "fighting"
    ],
    "kommo-o": [
      "dragon",
      "fighting"
    ],
    "tapu-koko": [
      "electric",
      "fairy"
    ],
    "tapu-lele": [
      "psychic",
      "fairy"
    ],
    "tapu-bulu": [
      "grass",
      "fairy"
    ],
    "tapu-fini": [
      "water",
      "fairy"
    ],
    cosmog: [
      "psychic"
    ],
    cosmoem: [
      "psychic"
    ],
    solgaleo: [
      "psychic",
      "steel"
    ],
    lunala: [
      "psychic",
      "ghost"
    ],
    nihilego: [
      "rock",
      "poison"
    ],
    buzzwole: [
      "bug",
      "fighting"
    ],
    pheromosa: [
      "bug",
      "fighting"
    ],
    xurkitree: [
      "electric"
    ],
    celesteela: [
      "steel",
      "flying"
    ],
    kartana: [
      "grass",
      "steel"
    ],
    guzzlord: [
      "dark",
      "dragon"
    ],
    necrozma: [
      "psychic"
    ],
    "necrozma-dawn-wings": [
      "psychic",
      "ghost"
    ],
    "necrozma-dusk-mane": [
      "psychic",
      "steel"
    ],
    "ultra-necrozma": [
      "psychic",
      "dragon"
    ],
    magearna: [
      "steel",
      "fairy"
    ],
    "mega-magearna": [
      "steel",
      "fairy"
    ],
    marshadow: [
      "fighting",
      "ghost"
    ],
    poipole: [
      "poison"
    ],
    naganadel: [
      "poison",
      "dragon"
    ],
    stakataka: [
      "rock",
      "steel"
    ],
    blacephalon: [
      "fire",
      "ghost"
    ],
    zeraora: [
      "electric"
    ],
    "mega-zeraora": [
      "electric"
    ],
    meltan: [
      "steel"
    ],
    melmetal: [
      "steel"
    ],
    "melmetal-gigantamax": [
      "steel"
    ],
    grookey: [
      "grass"
    ],
    thwackey: [
      "grass"
    ],
    rillaboom: [
      "grass"
    ],
    "rillaboom-gigantamax": [
      "grass"
    ],
    scorbunny: [
      "fire"
    ],
    raboot: [
      "fire"
    ],
    cinderace: [
      "fire"
    ],
    "cinderace-gigantamax": [
      "fire"
    ],
    sobble: [
      "water"
    ],
    drizzile: [
      "water"
    ],
    inteleon: [
      "water"
    ],
    "inteleon-gigantamax": [
      "water"
    ],
    skwovet: [
      "normal"
    ],
    greedent: [
      "normal"
    ],
    rookidee: [
      "flying"
    ],
    corvisquire: [
      "flying"
    ],
    corviknight: [
      "flying",
      "steel"
    ],
    "corviknight-gigantamax": [
      "flying",
      "steel"
    ],
    blipbug: [
      "bug"
    ],
    dottler: [
      "bug",
      "psychic"
    ],
    orbeetle: [
      "bug",
      "psychic"
    ],
    "orbeetle-gigantamax": [
      "bug",
      "psychic"
    ],
    nickit: [
      "dark"
    ],
    thievul: [
      "dark"
    ],
    gossifleur: [
      "grass"
    ],
    eldegoss: [
      "grass"
    ],
    wooloo: [
      "normal"
    ],
    dubwool: [
      "normal"
    ],
    chewtle: [
      "water"
    ],
    drednaw: [
      "water",
      "rock"
    ],
    "drednaw-gigantamax": [
      "water",
      "rock"
    ],
    yamper: [
      "electric"
    ],
    boltund: [
      "electric"
    ],
    rolycoly: [
      "rock"
    ],
    carkol: [
      "rock",
      "fire"
    ],
    coalossal: [
      "rock",
      "fire"
    ],
    "coalossal-gigantamax": [
      "rock",
      "fire"
    ],
    applin: [
      "grass",
      "dragon"
    ],
    flapple: [
      "grass",
      "dragon"
    ],
    "flapple-gigantamax": [
      "grass",
      "dragon"
    ],
    appletun: [
      "grass",
      "dragon"
    ],
    "appletun-gigantamax": [
      "grass",
      "dragon"
    ],
    silicobra: [
      "ground"
    ],
    sandaconda: [
      "ground"
    ],
    "sandaconda-gigantamax": [
      "ground"
    ],
    cramorant: [
      "flying",
      "water"
    ],
    arrokuda: [
      "water"
    ],
    barraskewda: [
      "water"
    ],
    toxel: [
      "electric",
      "poison"
    ],
    "toxtricity-gigantamax": [
      "electric",
      "poison"
    ],
    "toxtricity-high": [
      "electric",
      "poison"
    ],
    "toxtricity-low": [
      "electric",
      "poison"
    ],
    sizzlipede: [
      "fire",
      "bug"
    ],
    centiskorch: [
      "fire",
      "bug"
    ],
    "centiskorch-gigantamax": [
      "fire",
      "bug"
    ],
    clobbopus: [
      "fighting"
    ],
    grapploct: [
      "fighting"
    ],
    sinistea: [
      "ghost"
    ],
    polteageist: [
      "ghost"
    ],
    hatenna: [
      "psychic"
    ],
    hattrem: [
      "psychic"
    ],
    hatterene: [
      "psychic",
      "fairy"
    ],
    "hatterene-gigantamax": [
      "psychic",
      "fairy"
    ],
    impidimp: [
      "dark",
      "fairy"
    ],
    morgrem: [
      "dark",
      "fairy"
    ],
    grimmsnarl: [
      "dark",
      "fairy"
    ],
    "grimmsnarl-gigantamax": [
      "dark",
      "fairy"
    ],
    obstagoon: [
      "dark",
      "normal"
    ],
    perrserker: [
      "steel"
    ],
    cursola: [
      "ghost"
    ],
    sirfetchd: [
      "fighting"
    ],
    "mr-rime": [
      "ice",
      "psychic"
    ],
    runerigus: [
      "ground",
      "ghost"
    ],
    milcery: [
      "fairy"
    ],
    alcremie: [
      "fairy"
    ],
    "alcremie-gigantamax": [
      "fairy"
    ],
    falinks: [
      "fighting"
    ],
    "mega-falinks": [
      "fighting"
    ],
    pincurchin: [
      "electric"
    ],
    snom: [
      "ice",
      "bug"
    ],
    frosmoth: [
      "ice",
      "bug"
    ],
    stonjourner: [
      "rock"
    ],
    eiscue: [
      "ice"
    ],
    "indeedee-f": [
      "psychic",
      "normal"
    ],
    "indeedee-m": [
      "psychic",
      "normal"
    ],
    morpeko: [
      "electric",
      "dark"
    ],
    cufant: [
      "steel"
    ],
    copperajah: [
      "steel"
    ],
    "copperajah-gigantamax": [
      "steel"
    ],
    dracozolt: [
      "electric",
      "dragon"
    ],
    arctozolt: [
      "electric",
      "ice"
    ],
    dracovish: [
      "water",
      "dragon"
    ],
    arctovish: [
      "water",
      "ice"
    ],
    duraludon: [
      "steel",
      "dragon"
    ],
    "duraludon-gigantamax": [
      "steel",
      "dragon"
    ],
    dreepy: [
      "dragon",
      "ghost"
    ],
    drakloak: [
      "dragon",
      "ghost"
    ],
    dragapult: [
      "dragon",
      "ghost"
    ],
    "zacian-crowned-sword": [
      "fairy",
      "steel"
    ],
    "zacian-hero-of-many-battles": [
      "fairy"
    ],
    "zamazenta-crowned-shield": [
      "fighting",
      "steel"
    ],
    "zamazenta-hero-of-many-battles": [
      "fighting"
    ],
    eternatus: [
      "poison",
      "dragon"
    ],
    kubfu: [
      "fighting"
    ],
    "urshifu-rapid-strike": [
      "fighting",
      "water"
    ],
    "urshifu-rapid-strike-gigantamax": [
      "fighting",
      "water"
    ],
    "urshifu-single-strike": [
      "fighting",
      "dark"
    ],
    "urshifu-single-strike-gigantamax": [
      "fighting",
      "dark"
    ],
    zarude: [
      "dark",
      "grass"
    ],
    regieleki: [
      "electric"
    ],
    regidrago: [
      "dragon"
    ],
    glastrier: [
      "ice"
    ],
    spectrier: [
      "ghost"
    ],
    calyrex: [
      "psychic",
      "grass"
    ],
    "calyrex-ice-rider": [
      "psychic",
      "ice"
    ],
    "calyrex-shadow-rider": [
      "psychic",
      "ghost"
    ],
    wyrdeer: [
      "normal",
      "psychic"
    ],
    kleavor: [
      "bug",
      "rock"
    ],
    ursaluna: [
      "ground",
      "normal"
    ],
    "basculegion-f": [
      "water",
      "ghost"
    ],
    "basculegion-m": [
      "water",
      "ghost"
    ],
    sneasler: [
      "fighting",
      "poison"
    ],
    overqwil: [
      "dark",
      "poison"
    ],
    "enamorus-incarnate": [
      "fairy",
      "flying"
    ],
    "enamorus-therian": [
      "fairy",
      "flying"
    ],
    sprigatito: [
      "grass"
    ],
    floragato: [
      "grass"
    ],
    meowscarada: [
      "grass",
      "dark"
    ],
    fuecoco: [
      "fire"
    ],
    crocalor: [
      "fire"
    ],
    skeledirge: [
      "fire",
      "ghost"
    ],
    quaxly: [
      "water"
    ],
    quaxwell: [
      "water"
    ],
    quaquaval: [
      "water",
      "fighting"
    ],
    lechonk: [
      "normal"
    ],
    "oinkologne-f": [
      "normal"
    ],
    "oinkologne-m": [
      "normal"
    ],
    tarountula: [
      "bug"
    ],
    spidops: [
      "bug"
    ],
    nymble: [
      "bug"
    ],
    lokix: [
      "bug",
      "dark"
    ],
    pawmi: [
      "electric"
    ],
    pawmo: [
      "electric",
      "fighting"
    ],
    pawmot: [
      "electric",
      "fighting"
    ],
    tandemaus: [
      "normal"
    ],
    maushold: [
      "normal"
    ],
    fidough: [
      "fairy"
    ],
    dachsbun: [
      "fairy"
    ],
    smoliv: [
      "grass",
      "normal"
    ],
    dolliv: [
      "grass",
      "normal"
    ],
    arboliva: [
      "grass",
      "normal"
    ],
    squawkabilly: [
      "normal",
      "flying"
    ],
    nacli: [
      "rock"
    ],
    naclstack: [
      "rock"
    ],
    garganacl: [
      "rock"
    ],
    charcadet: [
      "fire"
    ],
    armarouge: [
      "fire",
      "psychic"
    ],
    ceruledge: [
      "fire",
      "ghost"
    ],
    tadbulb: [
      "electric"
    ],
    bellibolt: [
      "electric"
    ],
    wattrel: [
      "electric",
      "flying"
    ],
    kilowattrel: [
      "electric",
      "flying"
    ],
    maschiff: [
      "dark"
    ],
    mabosstiff: [
      "dark"
    ],
    shroodle: [
      "poison",
      "normal"
    ],
    grafaiai: [
      "poison",
      "normal"
    ],
    bramblin: [
      "grass",
      "ghost"
    ],
    brambleghast: [
      "grass",
      "ghost"
    ],
    toedscool: [
      "ground",
      "grass"
    ],
    toedscruel: [
      "ground",
      "grass"
    ],
    klawf: [
      "rock"
    ],
    capsakid: [
      "grass"
    ],
    scovillain: [
      "grass",
      "fire"
    ],
    "mega-scovillain": [
      "grass",
      "fire"
    ],
    rellor: [
      "bug"
    ],
    rabsca: [
      "bug",
      "psychic"
    ],
    flittle: [
      "psychic"
    ],
    espathra: [
      "psychic"
    ],
    tinkatink: [
      "fairy",
      "steel"
    ],
    tinkatuff: [
      "fairy",
      "steel"
    ],
    tinkaton: [
      "fairy",
      "steel"
    ],
    wiglett: [
      "water"
    ],
    wugtrio: [
      "water"
    ],
    bombirdier: [
      "flying",
      "dark"
    ],
    finizen: [
      "water"
    ],
    palafin: [
      "water"
    ],
    varoom: [
      "steel",
      "poison"
    ],
    revavroom: [
      "steel",
      "poison"
    ],
    cyclizar: [
      "dragon",
      "normal"
    ],
    orthworm: [
      "steel"
    ],
    glimmet: [
      "rock",
      "poison"
    ],
    glimmora: [
      "rock",
      "poison"
    ],
    "mega-glimmora": [
      "rock",
      "poison"
    ],
    greavard: [
      "ghost"
    ],
    houndstone: [
      "ghost"
    ],
    flamigo: [
      "flying",
      "fighting"
    ],
    cetoddle: [
      "ice"
    ],
    cetitan: [
      "ice"
    ],
    veluza: [
      "water",
      "psychic"
    ],
    dondozo: [
      "water"
    ],
    tatsugiri: [
      "dragon",
      "water"
    ],
    "mega-tatsugiri": [
      "dragon",
      "water"
    ],
    annihilape: [
      "fighting",
      "ghost"
    ],
    clodsire: [
      "poison",
      "ground"
    ],
    farigiraf: [
      "normal",
      "psychic"
    ],
    dudunsparce: [
      "normal"
    ],
    kingambit: [
      "dark",
      "steel"
    ],
    "great-tusk": [
      "ground",
      "fighting"
    ],
    "scream-tail": [
      "fairy",
      "psychic"
    ],
    "brute-bonnet": [
      "grass",
      "dark"
    ],
    "flutter-mane": [
      "ghost",
      "fairy"
    ],
    "slither-wing": [
      "bug",
      "fighting"
    ],
    "sandy-shocks": [
      "electric",
      "ground"
    ],
    "iron-treads": [
      "ground",
      "steel"
    ],
    "iron-bundle": [
      "ice",
      "water"
    ],
    "iron-hands": [
      "fighting",
      "electric"
    ],
    "iron-jugulis": [
      "dark",
      "flying"
    ],
    "iron-moth": [
      "fire",
      "poison"
    ],
    "iron-thorns": [
      "rock",
      "electric"
    ],
    frigibax: [
      "dragon",
      "ice"
    ],
    arctibax: [
      "dragon",
      "ice"
    ],
    baxcalibur: [
      "dragon",
      "ice"
    ],
    "mega-baxcalibur": [
      "dragon",
      "ice"
    ],
    gimmighoul: [
      "ghost"
    ],
    gholdengo: [
      "steel",
      "ghost"
    ],
    "wo-chien": [
      "dark",
      "grass"
    ],
    "chien-pao": [
      "dark",
      "ice"
    ],
    "ting-lu": [
      "dark",
      "ground"
    ],
    "chi-yu": [
      "dark",
      "fire"
    ],
    "roaring-moon": [
      "dragon",
      "dark"
    ],
    "iron-valiant": [
      "fairy",
      "fighting"
    ],
    koraidon: [
      "fighting",
      "dragon"
    ],
    miraidon: [
      "electric",
      "dragon"
    ],
    "walking-wake": [
      "water",
      "dragon"
    ],
    "iron-leaves": [
      "grass",
      "psychic"
    ],
    dipplin: [
      "grass",
      "dragon"
    ],
    poltchageist: [
      "grass",
      "ghost"
    ],
    sinistcha: [
      "grass",
      "ghost"
    ],
    okidogi: [
      "poison",
      "fighting"
    ],
    munkidori: [
      "poison",
      "psychic"
    ],
    fezandipiti: [
      "poison",
      "fairy"
    ],
    "ogerpon-cornerstone-mask": [
      "grass",
      "rock"
    ],
    "ogerpon-hearthflame-mask": [
      "grass",
      "fire"
    ],
    "ogerpon-teal-mask": [
      "grass"
    ],
    "ogerpon-wellspring-mask": [
      "grass",
      "water"
    ],
    archaludon: [
      "steel",
      "dragon"
    ],
    hydrapple: [
      "grass",
      "dragon"
    ],
    "gouging-fire": [
      "fire",
      "dragon"
    ],
    "raging-bolt": [
      "electric",
      "dragon"
    ],
    "iron-boulder": [
      "rock",
      "psychic"
    ],
    "iron-crown": [
      "steel",
      "psychic"
    ],
    terapagos: [
      "normal"
    ],
    "terapagos-terastal": [
      "normal"
    ],
    pecharunt: [
      "poison",
      "ghost"
    ],
    "ursaluna-blood-moon": [
      "ground",
      "normal"
    ]
  },
  byDex: {
    "1": [
      "grass",
      "poison"
    ],
    "2": [
      "grass",
      "poison"
    ],
    "3": [
      "grass",
      "poison"
    ],
    "4": [
      "fire"
    ],
    "5": [
      "fire"
    ],
    "6": [
      "fire",
      "flying"
    ],
    "7": [
      "water"
    ],
    "8": [
      "water"
    ],
    "9": [
      "water"
    ],
    "10": [
      "bug"
    ],
    "11": [
      "bug"
    ],
    "12": [
      "bug",
      "flying"
    ],
    "13": [
      "bug",
      "poison"
    ],
    "14": [
      "bug",
      "poison"
    ],
    "15": [
      "bug",
      "poison"
    ],
    "16": [
      "normal",
      "flying"
    ],
    "17": [
      "normal",
      "flying"
    ],
    "18": [
      "normal",
      "flying"
    ],
    "19": [
      "normal"
    ],
    "20": [
      "normal"
    ],
    "21": [
      "normal",
      "flying"
    ],
    "22": [
      "normal",
      "flying"
    ],
    "23": [
      "poison"
    ],
    "24": [
      "poison"
    ],
    "25": [
      "electric"
    ],
    "26": [
      "electric"
    ],
    "27": [
      "ground"
    ],
    "28": [
      "ground"
    ],
    "29": [
      "poison"
    ],
    "30": [
      "poison"
    ],
    "31": [
      "poison",
      "ground"
    ],
    "32": [
      "poison"
    ],
    "33": [
      "poison"
    ],
    "34": [
      "poison",
      "ground"
    ],
    "35": [
      "fairy"
    ],
    "36": [
      "fairy"
    ],
    "37": [
      "fire"
    ],
    "38": [
      "fire"
    ],
    "39": [
      "normal",
      "fairy"
    ],
    "40": [
      "normal",
      "fairy"
    ],
    "41": [
      "poison",
      "flying"
    ],
    "42": [
      "poison",
      "flying"
    ],
    "43": [
      "grass",
      "poison"
    ],
    "44": [
      "grass",
      "poison"
    ],
    "45": [
      "grass",
      "poison"
    ],
    "46": [
      "bug",
      "grass"
    ],
    "47": [
      "bug",
      "grass"
    ],
    "48": [
      "bug",
      "poison"
    ],
    "49": [
      "bug",
      "poison"
    ],
    "50": [
      "ground"
    ],
    "51": [
      "ground"
    ],
    "52": [
      "normal"
    ],
    "53": [
      "normal"
    ],
    "54": [
      "water"
    ],
    "55": [
      "water"
    ],
    "56": [
      "fighting"
    ],
    "57": [
      "fighting"
    ],
    "58": [
      "fire"
    ],
    "59": [
      "fire"
    ],
    "60": [
      "water"
    ],
    "61": [
      "water"
    ],
    "62": [
      "water",
      "fighting"
    ],
    "63": [
      "psychic"
    ],
    "64": [
      "psychic"
    ],
    "65": [
      "psychic"
    ],
    "66": [
      "fighting"
    ],
    "67": [
      "fighting"
    ],
    "68": [
      "fighting"
    ],
    "69": [
      "grass",
      "poison"
    ],
    "70": [
      "grass",
      "poison"
    ],
    "71": [
      "grass",
      "poison"
    ],
    "72": [
      "water",
      "poison"
    ],
    "73": [
      "water",
      "poison"
    ],
    "74": [
      "rock",
      "ground"
    ],
    "75": [
      "rock",
      "ground"
    ],
    "76": [
      "rock",
      "ground"
    ],
    "77": [
      "fire"
    ],
    "78": [
      "fire"
    ],
    "79": [
      "water",
      "psychic"
    ],
    "80": [
      "water",
      "psychic"
    ],
    "81": [
      "electric",
      "steel"
    ],
    "82": [
      "electric",
      "steel"
    ],
    "83": [
      "normal",
      "flying"
    ],
    "84": [
      "normal",
      "flying"
    ],
    "85": [
      "normal",
      "flying"
    ],
    "86": [
      "water"
    ],
    "87": [
      "water",
      "ice"
    ],
    "88": [
      "poison"
    ],
    "89": [
      "poison"
    ],
    "90": [
      "water"
    ],
    "91": [
      "water",
      "ice"
    ],
    "92": [
      "ghost",
      "poison"
    ],
    "93": [
      "ghost",
      "poison"
    ],
    "94": [
      "ghost",
      "poison"
    ],
    "95": [
      "rock",
      "ground"
    ],
    "96": [
      "psychic"
    ],
    "97": [
      "psychic"
    ],
    "98": [
      "water"
    ],
    "99": [
      "water"
    ],
    "100": [
      "electric"
    ],
    "101": [
      "electric"
    ],
    "102": [
      "grass",
      "psychic"
    ],
    "103": [
      "grass",
      "psychic"
    ],
    "104": [
      "ground"
    ],
    "105": [
      "ground"
    ],
    "106": [
      "fighting"
    ],
    "107": [
      "fighting"
    ],
    "108": [
      "normal"
    ],
    "109": [
      "poison"
    ],
    "110": [
      "poison"
    ],
    "111": [
      "ground",
      "rock"
    ],
    "112": [
      "ground",
      "rock"
    ],
    "113": [
      "normal"
    ],
    "114": [
      "grass"
    ],
    "115": [
      "normal"
    ],
    "116": [
      "water"
    ],
    "117": [
      "water"
    ],
    "118": [
      "water"
    ],
    "119": [
      "water"
    ],
    "120": [
      "water"
    ],
    "121": [
      "water",
      "psychic"
    ],
    "122": [
      "psychic",
      "fairy"
    ],
    "123": [
      "bug",
      "flying"
    ],
    "124": [
      "ice",
      "psychic"
    ],
    "125": [
      "electric"
    ],
    "126": [
      "fire"
    ],
    "127": [
      "bug"
    ],
    "128": [
      "normal"
    ],
    "129": [
      "water"
    ],
    "130": [
      "water",
      "flying"
    ],
    "131": [
      "water",
      "ice"
    ],
    "132": [
      "normal"
    ],
    "133": [
      "normal"
    ],
    "134": [
      "water"
    ],
    "135": [
      "electric"
    ],
    "136": [
      "fire"
    ],
    "137": [
      "normal"
    ],
    "138": [
      "rock",
      "water"
    ],
    "139": [
      "rock",
      "water"
    ],
    "140": [
      "rock",
      "water"
    ],
    "141": [
      "rock",
      "water"
    ],
    "142": [
      "rock",
      "flying"
    ],
    "143": [
      "normal"
    ],
    "144": [
      "ice",
      "flying"
    ],
    "145": [
      "electric",
      "flying"
    ],
    "146": [
      "fire",
      "flying"
    ],
    "147": [
      "dragon"
    ],
    "148": [
      "dragon"
    ],
    "149": [
      "dragon",
      "flying"
    ],
    "150": [
      "psychic"
    ],
    "151": [
      "psychic"
    ],
    "152": [
      "grass"
    ],
    "153": [
      "grass"
    ],
    "154": [
      "grass"
    ],
    "155": [
      "fire"
    ],
    "156": [
      "fire"
    ],
    "157": [
      "fire"
    ],
    "158": [
      "water"
    ],
    "159": [
      "water"
    ],
    "160": [
      "water"
    ],
    "161": [
      "normal"
    ],
    "162": [
      "normal"
    ],
    "163": [
      "normal",
      "flying"
    ],
    "164": [
      "normal",
      "flying"
    ],
    "165": [
      "bug",
      "flying"
    ],
    "166": [
      "bug",
      "flying"
    ],
    "167": [
      "bug",
      "poison"
    ],
    "168": [
      "bug",
      "poison"
    ],
    "169": [
      "poison",
      "flying"
    ],
    "170": [
      "water",
      "electric"
    ],
    "171": [
      "water",
      "electric"
    ],
    "172": [
      "electric"
    ],
    "173": [
      "fairy"
    ],
    "174": [
      "normal",
      "fairy"
    ],
    "175": [
      "fairy"
    ],
    "176": [
      "fairy",
      "flying"
    ],
    "177": [
      "psychic",
      "flying"
    ],
    "178": [
      "psychic",
      "flying"
    ],
    "179": [
      "electric"
    ],
    "180": [
      "electric"
    ],
    "181": [
      "electric"
    ],
    "182": [
      "grass"
    ],
    "183": [
      "water",
      "fairy"
    ],
    "184": [
      "water",
      "fairy"
    ],
    "185": [
      "rock"
    ],
    "186": [
      "water"
    ],
    "187": [
      "grass",
      "flying"
    ],
    "188": [
      "grass",
      "flying"
    ],
    "189": [
      "grass",
      "flying"
    ],
    "190": [
      "normal"
    ],
    "191": [
      "grass"
    ],
    "192": [
      "grass"
    ],
    "193": [
      "bug",
      "flying"
    ],
    "194": [
      "water",
      "ground"
    ],
    "195": [
      "water",
      "ground"
    ],
    "196": [
      "psychic"
    ],
    "197": [
      "dark"
    ],
    "198": [
      "dark",
      "flying"
    ],
    "199": [
      "water",
      "psychic"
    ],
    "200": [
      "ghost"
    ],
    "201": [
      "psychic"
    ],
    "202": [
      "psychic"
    ],
    "203": [
      "normal",
      "psychic"
    ],
    "204": [
      "bug"
    ],
    "205": [
      "bug",
      "steel"
    ],
    "206": [
      "normal"
    ],
    "207": [
      "ground",
      "flying"
    ],
    "208": [
      "steel",
      "ground"
    ],
    "209": [
      "fairy"
    ],
    "210": [
      "fairy"
    ],
    "211": [
      "water",
      "poison"
    ],
    "212": [
      "bug",
      "steel"
    ],
    "213": [
      "bug",
      "rock"
    ],
    "214": [
      "bug",
      "fighting"
    ],
    "215": [
      "dark",
      "ice"
    ],
    "216": [
      "normal"
    ],
    "217": [
      "normal"
    ],
    "218": [
      "fire"
    ],
    "219": [
      "fire",
      "rock"
    ],
    "220": [
      "ice",
      "ground"
    ],
    "221": [
      "ice",
      "ground"
    ],
    "222": [
      "water",
      "rock"
    ],
    "223": [
      "water"
    ],
    "224": [
      "water"
    ],
    "225": [
      "ice",
      "flying"
    ],
    "226": [
      "water",
      "flying"
    ],
    "227": [
      "steel",
      "flying"
    ],
    "228": [
      "dark",
      "fire"
    ],
    "229": [
      "dark",
      "fire"
    ],
    "230": [
      "water",
      "dragon"
    ],
    "231": [
      "ground"
    ],
    "232": [
      "ground"
    ],
    "233": [
      "normal"
    ],
    "234": [
      "normal"
    ],
    "235": [
      "normal"
    ],
    "236": [
      "fighting"
    ],
    "237": [
      "fighting"
    ],
    "238": [
      "ice",
      "psychic"
    ],
    "239": [
      "electric"
    ],
    "240": [
      "fire"
    ],
    "241": [
      "normal"
    ],
    "242": [
      "normal"
    ],
    "243": [
      "electric"
    ],
    "244": [
      "fire"
    ],
    "245": [
      "water"
    ],
    "246": [
      "rock",
      "ground"
    ],
    "247": [
      "rock",
      "ground"
    ],
    "248": [
      "rock",
      "dark"
    ],
    "249": [
      "psychic",
      "flying"
    ],
    "250": [
      "fire",
      "flying"
    ],
    "251": [
      "psychic",
      "grass"
    ],
    "252": [
      "grass"
    ],
    "253": [
      "grass"
    ],
    "254": [
      "grass"
    ],
    "255": [
      "fire"
    ],
    "256": [
      "fire",
      "fighting"
    ],
    "257": [
      "fire",
      "fighting"
    ],
    "258": [
      "water"
    ],
    "259": [
      "water",
      "ground"
    ],
    "260": [
      "water",
      "ground"
    ],
    "261": [
      "dark"
    ],
    "262": [
      "dark"
    ],
    "263": [
      "normal"
    ],
    "264": [
      "normal"
    ],
    "265": [
      "bug"
    ],
    "266": [
      "bug"
    ],
    "267": [
      "bug",
      "flying"
    ],
    "268": [
      "bug"
    ],
    "269": [
      "bug",
      "poison"
    ],
    "270": [
      "water",
      "grass"
    ],
    "271": [
      "water",
      "grass"
    ],
    "272": [
      "water",
      "grass"
    ],
    "273": [
      "grass"
    ],
    "274": [
      "grass",
      "dark"
    ],
    "275": [
      "grass",
      "dark"
    ],
    "276": [
      "normal",
      "flying"
    ],
    "277": [
      "normal",
      "flying"
    ],
    "278": [
      "water",
      "flying"
    ],
    "279": [
      "water",
      "flying"
    ],
    "280": [
      "psychic",
      "fairy"
    ],
    "281": [
      "psychic",
      "fairy"
    ],
    "282": [
      "psychic",
      "fairy"
    ],
    "283": [
      "bug",
      "water"
    ],
    "284": [
      "bug",
      "flying"
    ],
    "285": [
      "grass"
    ],
    "286": [
      "grass",
      "fighting"
    ],
    "287": [
      "normal"
    ],
    "288": [
      "normal"
    ],
    "289": [
      "normal"
    ],
    "290": [
      "bug",
      "ground"
    ],
    "291": [
      "bug",
      "flying"
    ],
    "292": [
      "bug",
      "ghost"
    ],
    "293": [
      "normal"
    ],
    "294": [
      "normal"
    ],
    "295": [
      "normal"
    ],
    "296": [
      "fighting"
    ],
    "297": [
      "fighting"
    ],
    "298": [
      "normal",
      "fairy"
    ],
    "299": [
      "rock"
    ],
    "300": [
      "normal"
    ],
    "301": [
      "normal"
    ],
    "302": [
      "dark",
      "ghost"
    ],
    "303": [
      "steel",
      "fairy"
    ],
    "304": [
      "steel",
      "rock"
    ],
    "305": [
      "steel",
      "rock"
    ],
    "306": [
      "steel",
      "rock"
    ],
    "307": [
      "fighting",
      "psychic"
    ],
    "308": [
      "fighting",
      "psychic"
    ],
    "309": [
      "electric"
    ],
    "310": [
      "electric"
    ],
    "311": [
      "electric"
    ],
    "312": [
      "electric"
    ],
    "313": [
      "bug"
    ],
    "314": [
      "bug"
    ],
    "315": [
      "grass",
      "poison"
    ],
    "316": [
      "poison"
    ],
    "317": [
      "poison"
    ],
    "318": [
      "water",
      "dark"
    ],
    "319": [
      "water",
      "dark"
    ],
    "320": [
      "water"
    ],
    "321": [
      "water"
    ],
    "322": [
      "fire",
      "ground"
    ],
    "323": [
      "fire",
      "ground"
    ],
    "324": [
      "fire"
    ],
    "325": [
      "psychic"
    ],
    "326": [
      "psychic"
    ],
    "327": [
      "normal"
    ],
    "328": [
      "ground"
    ],
    "329": [
      "ground",
      "dragon"
    ],
    "330": [
      "ground",
      "dragon"
    ],
    "331": [
      "grass"
    ],
    "332": [
      "grass",
      "dark"
    ],
    "333": [
      "normal",
      "flying"
    ],
    "334": [
      "dragon",
      "flying"
    ],
    "335": [
      "normal"
    ],
    "336": [
      "poison"
    ],
    "337": [
      "rock",
      "psychic"
    ],
    "338": [
      "rock",
      "psychic"
    ],
    "339": [
      "water",
      "ground"
    ],
    "340": [
      "water",
      "ground"
    ],
    "341": [
      "water"
    ],
    "342": [
      "water",
      "dark"
    ],
    "343": [
      "ground",
      "psychic"
    ],
    "344": [
      "ground",
      "psychic"
    ],
    "345": [
      "rock",
      "grass"
    ],
    "346": [
      "rock",
      "grass"
    ],
    "347": [
      "rock",
      "bug"
    ],
    "348": [
      "rock",
      "bug"
    ],
    "349": [
      "water"
    ],
    "350": [
      "water"
    ],
    "351": [
      "normal"
    ],
    "352": [
      "normal"
    ],
    "353": [
      "ghost"
    ],
    "354": [
      "ghost"
    ],
    "355": [
      "ghost"
    ],
    "356": [
      "ghost"
    ],
    "357": [
      "grass",
      "flying"
    ],
    "358": [
      "psychic"
    ],
    "359": [
      "dark"
    ],
    "360": [
      "psychic"
    ],
    "361": [
      "ice"
    ],
    "362": [
      "ice"
    ],
    "363": [
      "ice",
      "water"
    ],
    "364": [
      "ice",
      "water"
    ],
    "365": [
      "ice",
      "water"
    ],
    "366": [
      "water"
    ],
    "367": [
      "water"
    ],
    "368": [
      "water"
    ],
    "369": [
      "water",
      "rock"
    ],
    "370": [
      "water"
    ],
    "371": [
      "dragon"
    ],
    "372": [
      "dragon"
    ],
    "373": [
      "dragon",
      "flying"
    ],
    "374": [
      "steel",
      "psychic"
    ],
    "375": [
      "steel",
      "psychic"
    ],
    "376": [
      "steel",
      "psychic"
    ],
    "377": [
      "rock"
    ],
    "378": [
      "ice"
    ],
    "379": [
      "steel"
    ],
    "380": [
      "dragon",
      "psychic"
    ],
    "381": [
      "dragon",
      "psychic"
    ],
    "382": [
      "water"
    ],
    "383": [
      "ground"
    ],
    "384": [
      "dragon",
      "flying"
    ],
    "385": [
      "steel",
      "psychic"
    ],
    "386": [
      "psychic"
    ],
    "387": [
      "grass"
    ],
    "388": [
      "grass"
    ],
    "389": [
      "grass",
      "ground"
    ],
    "390": [
      "fire"
    ],
    "391": [
      "fire",
      "fighting"
    ],
    "392": [
      "fire",
      "fighting"
    ],
    "393": [
      "water"
    ],
    "394": [
      "water"
    ],
    "395": [
      "water",
      "steel"
    ],
    "396": [
      "normal",
      "flying"
    ],
    "397": [
      "normal",
      "flying"
    ],
    "398": [
      "normal",
      "flying"
    ],
    "399": [
      "normal"
    ],
    "400": [
      "normal",
      "water"
    ],
    "401": [
      "bug"
    ],
    "402": [
      "bug"
    ],
    "403": [
      "electric"
    ],
    "404": [
      "electric"
    ],
    "405": [
      "electric"
    ],
    "406": [
      "grass",
      "poison"
    ],
    "407": [
      "grass",
      "poison"
    ],
    "408": [
      "rock"
    ],
    "409": [
      "rock"
    ],
    "410": [
      "rock",
      "steel"
    ],
    "411": [
      "rock",
      "steel"
    ],
    "412": [
      "bug"
    ],
    "413": [
      "bug",
      "grass"
    ],
    "414": [
      "bug",
      "flying"
    ],
    "415": [
      "bug",
      "flying"
    ],
    "416": [
      "bug",
      "flying"
    ],
    "417": [
      "electric"
    ],
    "418": [
      "water"
    ],
    "419": [
      "water"
    ],
    "420": [
      "grass"
    ],
    "421": [
      "grass"
    ],
    "422": [
      "water"
    ],
    "423": [
      "water",
      "ground"
    ],
    "424": [
      "normal"
    ],
    "425": [
      "ghost",
      "flying"
    ],
    "426": [
      "ghost",
      "flying"
    ],
    "427": [
      "normal"
    ],
    "428": [
      "normal"
    ],
    "429": [
      "ghost"
    ],
    "430": [
      "dark",
      "flying"
    ],
    "431": [
      "normal"
    ],
    "432": [
      "normal"
    ],
    "433": [
      "psychic"
    ],
    "434": [
      "poison",
      "dark"
    ],
    "435": [
      "poison",
      "dark"
    ],
    "436": [
      "steel",
      "psychic"
    ],
    "437": [
      "steel",
      "psychic"
    ],
    "438": [
      "rock"
    ],
    "439": [
      "psychic",
      "fairy"
    ],
    "440": [
      "normal"
    ],
    "441": [
      "normal",
      "flying"
    ],
    "442": [
      "ghost",
      "dark"
    ],
    "443": [
      "dragon",
      "ground"
    ],
    "444": [
      "dragon",
      "ground"
    ],
    "445": [
      "dragon",
      "ground"
    ],
    "446": [
      "normal"
    ],
    "447": [
      "fighting"
    ],
    "448": [
      "fighting",
      "steel"
    ],
    "449": [
      "ground"
    ],
    "450": [
      "ground"
    ],
    "451": [
      "poison",
      "bug"
    ],
    "452": [
      "poison",
      "dark"
    ],
    "453": [
      "poison",
      "fighting"
    ],
    "454": [
      "poison",
      "fighting"
    ],
    "455": [
      "grass"
    ],
    "456": [
      "water"
    ],
    "457": [
      "water"
    ],
    "458": [
      "water",
      "flying"
    ],
    "459": [
      "grass",
      "ice"
    ],
    "460": [
      "grass",
      "ice"
    ],
    "461": [
      "dark",
      "ice"
    ],
    "462": [
      "electric",
      "steel"
    ],
    "463": [
      "normal"
    ],
    "464": [
      "ground",
      "rock"
    ],
    "465": [
      "grass"
    ],
    "466": [
      "electric"
    ],
    "467": [
      "fire"
    ],
    "468": [
      "fairy",
      "flying"
    ],
    "469": [
      "bug",
      "flying"
    ],
    "470": [
      "grass"
    ],
    "471": [
      "ice"
    ],
    "472": [
      "ground",
      "flying"
    ],
    "473": [
      "ice",
      "ground"
    ],
    "474": [
      "normal"
    ],
    "475": [
      "psychic",
      "fighting"
    ],
    "476": [
      "rock",
      "steel"
    ],
    "477": [
      "ghost"
    ],
    "478": [
      "ice",
      "ghost"
    ],
    "479": [
      "electric",
      "ghost"
    ],
    "480": [
      "psychic"
    ],
    "481": [
      "psychic"
    ],
    "482": [
      "psychic"
    ],
    "483": [
      "steel",
      "dragon"
    ],
    "484": [
      "water",
      "dragon"
    ],
    "485": [
      "fire",
      "steel"
    ],
    "486": [
      "normal"
    ],
    "487": [
      "ghost",
      "dragon"
    ],
    "488": [
      "psychic"
    ],
    "489": [
      "water"
    ],
    "490": [
      "water"
    ],
    "491": [
      "dark"
    ],
    "492": [
      "grass"
    ],
    "493": [
      "normal"
    ],
    "494": [
      "psychic",
      "fire"
    ],
    "495": [
      "grass"
    ],
    "496": [
      "grass"
    ],
    "497": [
      "grass"
    ],
    "498": [
      "fire"
    ],
    "499": [
      "fire",
      "fighting"
    ],
    "500": [
      "fire",
      "fighting"
    ],
    "501": [
      "water"
    ],
    "502": [
      "water"
    ],
    "503": [
      "water"
    ],
    "504": [
      "normal"
    ],
    "505": [
      "normal"
    ],
    "506": [
      "normal"
    ],
    "507": [
      "normal"
    ],
    "508": [
      "normal"
    ],
    "509": [
      "dark"
    ],
    "510": [
      "dark"
    ],
    "511": [
      "grass"
    ],
    "512": [
      "grass"
    ],
    "513": [
      "fire"
    ],
    "514": [
      "fire"
    ],
    "515": [
      "water"
    ],
    "516": [
      "water"
    ],
    "517": [
      "psychic"
    ],
    "518": [
      "psychic"
    ],
    "519": [
      "normal",
      "flying"
    ],
    "520": [
      "normal",
      "flying"
    ],
    "521": [
      "normal",
      "flying"
    ],
    "522": [
      "electric"
    ],
    "523": [
      "electric"
    ],
    "524": [
      "rock"
    ],
    "525": [
      "rock"
    ],
    "526": [
      "rock"
    ],
    "527": [
      "psychic",
      "flying"
    ],
    "528": [
      "psychic",
      "flying"
    ],
    "529": [
      "ground"
    ],
    "530": [
      "ground",
      "steel"
    ],
    "531": [
      "normal"
    ],
    "532": [
      "fighting"
    ],
    "533": [
      "fighting"
    ],
    "534": [
      "fighting"
    ],
    "535": [
      "water"
    ],
    "536": [
      "water",
      "ground"
    ],
    "537": [
      "water",
      "ground"
    ],
    "538": [
      "fighting"
    ],
    "539": [
      "fighting"
    ],
    "540": [
      "bug",
      "grass"
    ],
    "541": [
      "bug",
      "grass"
    ],
    "542": [
      "bug",
      "grass"
    ],
    "543": [
      "bug",
      "poison"
    ],
    "544": [
      "bug",
      "poison"
    ],
    "545": [
      "bug",
      "poison"
    ],
    "546": [
      "grass",
      "fairy"
    ],
    "547": [
      "grass",
      "fairy"
    ],
    "548": [
      "grass"
    ],
    "549": [
      "grass"
    ],
    "550": [
      "water"
    ],
    "551": [
      "ground",
      "dark"
    ],
    "552": [
      "ground",
      "dark"
    ],
    "553": [
      "ground",
      "dark"
    ],
    "554": [
      "fire"
    ],
    "555": [
      "fire"
    ],
    "556": [
      "grass"
    ],
    "557": [
      "bug",
      "rock"
    ],
    "558": [
      "bug",
      "rock"
    ],
    "559": [
      "dark",
      "fighting"
    ],
    "560": [
      "dark",
      "fighting"
    ],
    "561": [
      "psychic",
      "flying"
    ],
    "562": [
      "ghost"
    ],
    "563": [
      "ghost"
    ],
    "564": [
      "water",
      "rock"
    ],
    "565": [
      "water",
      "rock"
    ],
    "566": [
      "rock",
      "flying"
    ],
    "567": [
      "rock",
      "flying"
    ],
    "568": [
      "poison"
    ],
    "569": [
      "poison"
    ],
    "570": [
      "dark"
    ],
    "571": [
      "dark"
    ],
    "572": [
      "normal"
    ],
    "573": [
      "normal"
    ],
    "574": [
      "psychic"
    ],
    "575": [
      "psychic"
    ],
    "576": [
      "psychic"
    ],
    "577": [
      "psychic"
    ],
    "578": [
      "psychic"
    ],
    "579": [
      "psychic"
    ],
    "580": [
      "water",
      "flying"
    ],
    "581": [
      "water",
      "flying"
    ],
    "582": [
      "ice"
    ],
    "583": [
      "ice"
    ],
    "584": [
      "ice"
    ],
    "585": [
      "normal",
      "grass"
    ],
    "586": [
      "normal",
      "grass"
    ],
    "587": [
      "electric",
      "flying"
    ],
    "588": [
      "bug"
    ],
    "589": [
      "bug",
      "steel"
    ],
    "590": [
      "grass",
      "poison"
    ],
    "591": [
      "grass",
      "poison"
    ],
    "592": [
      "water",
      "ghost"
    ],
    "593": [
      "water",
      "ghost"
    ],
    "594": [
      "water"
    ],
    "595": [
      "bug",
      "electric"
    ],
    "596": [
      "bug",
      "electric"
    ],
    "597": [
      "grass",
      "steel"
    ],
    "598": [
      "grass",
      "steel"
    ],
    "599": [
      "steel"
    ],
    "600": [
      "steel"
    ],
    "601": [
      "steel"
    ],
    "602": [
      "electric"
    ],
    "603": [
      "electric"
    ],
    "604": [
      "electric"
    ],
    "605": [
      "psychic"
    ],
    "606": [
      "psychic"
    ],
    "607": [
      "ghost",
      "fire"
    ],
    "608": [
      "ghost",
      "fire"
    ],
    "609": [
      "ghost",
      "fire"
    ],
    "610": [
      "dragon"
    ],
    "611": [
      "dragon"
    ],
    "612": [
      "dragon"
    ],
    "613": [
      "ice"
    ],
    "614": [
      "ice"
    ],
    "615": [
      "ice"
    ],
    "616": [
      "bug"
    ],
    "617": [
      "bug"
    ],
    "618": [
      "ground",
      "electric"
    ],
    "619": [
      "fighting"
    ],
    "620": [
      "fighting"
    ],
    "621": [
      "dragon"
    ],
    "622": [
      "ground",
      "ghost"
    ],
    "623": [
      "ground",
      "ghost"
    ],
    "624": [
      "dark",
      "steel"
    ],
    "625": [
      "dark",
      "steel"
    ],
    "626": [
      "normal"
    ],
    "627": [
      "normal",
      "flying"
    ],
    "628": [
      "normal",
      "flying"
    ],
    "629": [
      "dark",
      "flying"
    ],
    "630": [
      "dark",
      "flying"
    ],
    "631": [
      "fire"
    ],
    "632": [
      "bug",
      "steel"
    ],
    "633": [
      "dark",
      "dragon"
    ],
    "634": [
      "dark",
      "dragon"
    ],
    "635": [
      "dark",
      "dragon"
    ],
    "636": [
      "bug",
      "fire"
    ],
    "637": [
      "bug",
      "fire"
    ],
    "638": [
      "steel",
      "fighting"
    ],
    "639": [
      "rock",
      "fighting"
    ],
    "640": [
      "grass",
      "fighting"
    ],
    "641": [
      "flying"
    ],
    "642": [
      "electric",
      "flying"
    ],
    "643": [
      "dragon",
      "fire"
    ],
    "644": [
      "dragon",
      "electric"
    ],
    "645": [
      "ground",
      "flying"
    ],
    "646": [
      "dragon",
      "ice"
    ],
    "647": [
      "water",
      "fighting"
    ],
    "648": [
      "normal",
      "psychic"
    ],
    "649": [
      "bug",
      "steel"
    ],
    "650": [
      "grass"
    ],
    "651": [
      "grass"
    ],
    "652": [
      "grass",
      "fighting"
    ],
    "653": [
      "fire"
    ],
    "654": [
      "fire"
    ],
    "655": [
      "fire",
      "psychic"
    ],
    "656": [
      "water"
    ],
    "657": [
      "water"
    ],
    "658": [
      "water",
      "dark"
    ],
    "659": [
      "normal"
    ],
    "660": [
      "normal",
      "ground"
    ],
    "661": [
      "normal",
      "flying"
    ],
    "662": [
      "fire",
      "flying"
    ],
    "663": [
      "fire",
      "flying"
    ],
    "664": [
      "bug"
    ],
    "665": [
      "bug"
    ],
    "666": [
      "bug",
      "flying"
    ],
    "667": [
      "fire",
      "normal"
    ],
    "668": [
      "fire",
      "normal"
    ],
    "669": [
      "fairy"
    ],
    "670": [
      "fairy"
    ],
    "671": [
      "fairy"
    ],
    "672": [
      "grass"
    ],
    "673": [
      "grass"
    ],
    "674": [
      "fighting"
    ],
    "675": [
      "fighting",
      "dark"
    ],
    "676": [
      "normal"
    ],
    "677": [
      "psychic"
    ],
    "678": [
      "psychic"
    ],
    "679": [
      "steel",
      "ghost"
    ],
    "680": [
      "steel",
      "ghost"
    ],
    "681": [
      "steel",
      "ghost"
    ],
    "682": [
      "fairy"
    ],
    "683": [
      "fairy"
    ],
    "684": [
      "fairy"
    ],
    "685": [
      "fairy"
    ],
    "686": [
      "dark",
      "psychic"
    ],
    "687": [
      "dark",
      "psychic"
    ],
    "688": [
      "rock",
      "water"
    ],
    "689": [
      "rock",
      "water"
    ],
    "690": [
      "poison",
      "water"
    ],
    "691": [
      "poison",
      "dragon"
    ],
    "692": [
      "water"
    ],
    "693": [
      "water"
    ],
    "694": [
      "electric",
      "normal"
    ],
    "695": [
      "electric",
      "normal"
    ],
    "696": [
      "rock",
      "dragon"
    ],
    "697": [
      "rock",
      "dragon"
    ],
    "698": [
      "rock",
      "ice"
    ],
    "699": [
      "rock",
      "ice"
    ],
    "700": [
      "fairy"
    ],
    "701": [
      "fighting",
      "flying"
    ],
    "702": [
      "electric",
      "fairy"
    ],
    "703": [
      "rock",
      "fairy"
    ],
    "704": [
      "dragon"
    ],
    "705": [
      "dragon"
    ],
    "706": [
      "dragon"
    ],
    "707": [
      "steel",
      "fairy"
    ],
    "708": [
      "ghost",
      "grass"
    ],
    "709": [
      "ghost",
      "grass"
    ],
    "710": [
      "ghost",
      "grass"
    ],
    "711": [
      "ghost",
      "grass"
    ],
    "712": [
      "ice"
    ],
    "713": [
      "ice"
    ],
    "714": [
      "flying",
      "dragon"
    ],
    "715": [
      "flying",
      "dragon"
    ],
    "716": [
      "fairy"
    ],
    "717": [
      "dark",
      "flying"
    ],
    "718": [
      "dragon",
      "ground"
    ],
    "719": [
      "rock",
      "fairy"
    ],
    "720": [
      "psychic",
      "ghost"
    ],
    "721": [
      "fire",
      "water"
    ],
    "722": [
      "grass",
      "flying"
    ],
    "723": [
      "grass",
      "flying"
    ],
    "724": [
      "grass",
      "ghost"
    ],
    "725": [
      "fire"
    ],
    "726": [
      "fire"
    ],
    "727": [
      "fire",
      "dark"
    ],
    "728": [
      "water"
    ],
    "729": [
      "water"
    ],
    "730": [
      "water",
      "fairy"
    ],
    "731": [
      "normal",
      "flying"
    ],
    "732": [
      "normal",
      "flying"
    ],
    "733": [
      "normal",
      "flying"
    ],
    "734": [
      "normal"
    ],
    "735": [
      "normal"
    ],
    "736": [
      "bug"
    ],
    "737": [
      "bug",
      "electric"
    ],
    "738": [
      "bug",
      "electric"
    ],
    "739": [
      "fighting"
    ],
    "740": [
      "fighting",
      "ice"
    ],
    "741": [
      "fire",
      "flying"
    ],
    "742": [
      "bug",
      "fairy"
    ],
    "743": [
      "bug",
      "fairy"
    ],
    "744": [
      "rock"
    ],
    "745": [
      "rock"
    ],
    "746": [
      "water"
    ],
    "747": [
      "poison",
      "water"
    ],
    "748": [
      "poison",
      "water"
    ],
    "749": [
      "ground"
    ],
    "750": [
      "ground"
    ],
    "751": [
      "water",
      "bug"
    ],
    "752": [
      "water",
      "bug"
    ],
    "753": [
      "grass"
    ],
    "754": [
      "grass"
    ],
    "755": [
      "grass",
      "fairy"
    ],
    "756": [
      "grass",
      "fairy"
    ],
    "757": [
      "poison",
      "fire"
    ],
    "758": [
      "poison",
      "fire"
    ],
    "759": [
      "normal",
      "fighting"
    ],
    "760": [
      "normal",
      "fighting"
    ],
    "761": [
      "grass"
    ],
    "762": [
      "grass"
    ],
    "763": [
      "grass"
    ],
    "764": [
      "fairy"
    ],
    "765": [
      "normal",
      "psychic"
    ],
    "766": [
      "fighting"
    ],
    "767": [
      "bug",
      "water"
    ],
    "768": [
      "bug",
      "water"
    ],
    "769": [
      "ghost",
      "ground"
    ],
    "770": [
      "ghost",
      "ground"
    ],
    "771": [
      "water"
    ],
    "772": [
      "normal"
    ],
    "773": [
      "normal"
    ],
    "774": [
      "rock",
      "flying"
    ],
    "775": [
      "normal"
    ],
    "776": [
      "fire",
      "dragon"
    ],
    "777": [
      "electric",
      "steel"
    ],
    "778": [
      "ghost",
      "fairy"
    ],
    "779": [
      "water",
      "psychic"
    ],
    "780": [
      "normal",
      "dragon"
    ],
    "781": [
      "ghost",
      "grass"
    ],
    "782": [
      "dragon"
    ],
    "783": [
      "dragon",
      "fighting"
    ],
    "784": [
      "dragon",
      "fighting"
    ],
    "785": [
      "electric",
      "fairy"
    ],
    "786": [
      "psychic",
      "fairy"
    ],
    "787": [
      "grass",
      "fairy"
    ],
    "788": [
      "water",
      "fairy"
    ],
    "789": [
      "psychic"
    ],
    "790": [
      "psychic"
    ],
    "791": [
      "psychic",
      "steel"
    ],
    "792": [
      "psychic",
      "ghost"
    ],
    "793": [
      "rock",
      "poison"
    ],
    "794": [
      "bug",
      "fighting"
    ],
    "795": [
      "bug",
      "fighting"
    ],
    "796": [
      "electric"
    ],
    "797": [
      "steel",
      "flying"
    ],
    "798": [
      "grass",
      "steel"
    ],
    "799": [
      "dark",
      "dragon"
    ],
    "800": [
      "psychic"
    ],
    "801": [
      "steel",
      "fairy"
    ],
    "802": [
      "fighting",
      "ghost"
    ],
    "803": [
      "poison"
    ],
    "804": [
      "poison",
      "dragon"
    ],
    "805": [
      "rock",
      "steel"
    ],
    "806": [
      "fire",
      "ghost"
    ],
    "807": [
      "electric"
    ],
    "808": [
      "steel"
    ],
    "809": [
      "steel"
    ],
    "810": [
      "grass"
    ],
    "811": [
      "grass"
    ],
    "812": [
      "grass"
    ],
    "813": [
      "fire"
    ],
    "814": [
      "fire"
    ],
    "815": [
      "fire"
    ],
    "816": [
      "water"
    ],
    "817": [
      "water"
    ],
    "818": [
      "water"
    ],
    "819": [
      "normal"
    ],
    "820": [
      "normal"
    ],
    "821": [
      "flying"
    ],
    "822": [
      "flying"
    ],
    "823": [
      "flying",
      "steel"
    ],
    "824": [
      "bug"
    ],
    "825": [
      "bug",
      "psychic"
    ],
    "826": [
      "bug",
      "psychic"
    ],
    "827": [
      "dark"
    ],
    "828": [
      "dark"
    ],
    "829": [
      "grass"
    ],
    "830": [
      "grass"
    ],
    "831": [
      "normal"
    ],
    "832": [
      "normal"
    ],
    "833": [
      "water"
    ],
    "834": [
      "water",
      "rock"
    ],
    "835": [
      "electric"
    ],
    "836": [
      "electric"
    ],
    "837": [
      "rock"
    ],
    "838": [
      "rock",
      "fire"
    ],
    "839": [
      "rock",
      "fire"
    ],
    "840": [
      "grass",
      "dragon"
    ],
    "841": [
      "grass",
      "dragon"
    ],
    "842": [
      "grass",
      "dragon"
    ],
    "843": [
      "ground"
    ],
    "844": [
      "ground"
    ],
    "845": [
      "flying",
      "water"
    ],
    "846": [
      "water"
    ],
    "847": [
      "water"
    ],
    "848": [
      "electric",
      "poison"
    ],
    "849": [
      "electric",
      "poison"
    ],
    "850": [
      "fire",
      "bug"
    ],
    "851": [
      "fire",
      "bug"
    ],
    "852": [
      "fighting"
    ],
    "853": [
      "fighting"
    ],
    "854": [
      "ghost"
    ],
    "855": [
      "ghost"
    ],
    "856": [
      "psychic"
    ],
    "857": [
      "psychic"
    ],
    "858": [
      "psychic",
      "fairy"
    ],
    "859": [
      "dark",
      "fairy"
    ],
    "860": [
      "dark",
      "fairy"
    ],
    "861": [
      "dark",
      "fairy"
    ],
    "862": [
      "dark",
      "normal"
    ],
    "863": [
      "steel"
    ],
    "864": [
      "ghost"
    ],
    "865": [
      "fighting"
    ],
    "866": [
      "ice",
      "psychic"
    ],
    "867": [
      "ground",
      "ghost"
    ],
    "868": [
      "fairy"
    ],
    "869": [
      "fairy"
    ],
    "870": [
      "fighting"
    ],
    "871": [
      "electric"
    ],
    "872": [
      "ice",
      "bug"
    ],
    "873": [
      "ice",
      "bug"
    ],
    "874": [
      "rock"
    ],
    "875": [
      "ice"
    ],
    "876": [
      "psychic",
      "normal"
    ],
    "877": [
      "electric",
      "dark"
    ],
    "878": [
      "steel"
    ],
    "879": [
      "steel"
    ],
    "880": [
      "electric",
      "dragon"
    ],
    "881": [
      "electric",
      "ice"
    ],
    "882": [
      "water",
      "dragon"
    ],
    "883": [
      "water",
      "ice"
    ],
    "884": [
      "steel",
      "dragon"
    ],
    "885": [
      "dragon",
      "ghost"
    ],
    "886": [
      "dragon",
      "ghost"
    ],
    "887": [
      "dragon",
      "ghost"
    ],
    "888": [
      "fairy"
    ],
    "889": [
      "fighting"
    ],
    "890": [
      "poison",
      "dragon"
    ],
    "891": [
      "fighting"
    ],
    "892": [
      "fighting",
      "dark"
    ],
    "893": [
      "dark",
      "grass"
    ],
    "894": [
      "electric"
    ],
    "895": [
      "dragon"
    ],
    "896": [
      "ice"
    ],
    "897": [
      "ghost"
    ],
    "898": [
      "psychic",
      "grass"
    ],
    "899": [
      "normal",
      "psychic"
    ],
    "900": [
      "bug",
      "rock"
    ],
    "901": [
      "ground",
      "normal"
    ],
    "902": [
      "water",
      "ghost"
    ],
    "903": [
      "fighting",
      "poison"
    ],
    "904": [
      "dark",
      "poison"
    ],
    "905": [
      "fairy",
      "flying"
    ],
    "906": [
      "grass"
    ],
    "907": [
      "grass"
    ],
    "908": [
      "grass",
      "dark"
    ],
    "909": [
      "fire"
    ],
    "910": [
      "fire"
    ],
    "911": [
      "fire",
      "ghost"
    ],
    "912": [
      "water"
    ],
    "913": [
      "water"
    ],
    "914": [
      "water",
      "fighting"
    ],
    "915": [
      "normal"
    ],
    "916": [
      "normal"
    ],
    "917": [
      "bug"
    ],
    "918": [
      "bug"
    ],
    "919": [
      "bug"
    ],
    "920": [
      "bug",
      "dark"
    ],
    "921": [
      "electric"
    ],
    "922": [
      "electric",
      "fighting"
    ],
    "923": [
      "electric",
      "fighting"
    ],
    "924": [
      "normal"
    ],
    "925": [
      "normal"
    ],
    "926": [
      "fairy"
    ],
    "927": [
      "fairy"
    ],
    "928": [
      "grass",
      "normal"
    ],
    "929": [
      "grass",
      "normal"
    ],
    "930": [
      "grass",
      "normal"
    ],
    "931": [
      "normal",
      "flying"
    ],
    "932": [
      "rock"
    ],
    "933": [
      "rock"
    ],
    "934": [
      "rock"
    ],
    "935": [
      "fire"
    ],
    "936": [
      "fire",
      "psychic"
    ],
    "937": [
      "fire",
      "ghost"
    ],
    "938": [
      "electric"
    ],
    "939": [
      "electric"
    ],
    "940": [
      "electric",
      "flying"
    ],
    "941": [
      "electric",
      "flying"
    ],
    "942": [
      "dark"
    ],
    "943": [
      "dark"
    ],
    "944": [
      "poison",
      "normal"
    ],
    "945": [
      "poison",
      "normal"
    ],
    "946": [
      "grass",
      "ghost"
    ],
    "947": [
      "grass",
      "ghost"
    ],
    "948": [
      "ground",
      "grass"
    ],
    "949": [
      "ground",
      "grass"
    ],
    "950": [
      "rock"
    ],
    "951": [
      "grass"
    ],
    "952": [
      "grass",
      "fire"
    ],
    "953": [
      "bug"
    ],
    "954": [
      "bug",
      "psychic"
    ],
    "955": [
      "psychic"
    ],
    "956": [
      "psychic"
    ],
    "957": [
      "fairy",
      "steel"
    ],
    "958": [
      "fairy",
      "steel"
    ],
    "959": [
      "fairy",
      "steel"
    ],
    "960": [
      "water"
    ],
    "961": [
      "water"
    ],
    "962": [
      "flying",
      "dark"
    ],
    "963": [
      "water"
    ],
    "964": [
      "water"
    ],
    "965": [
      "steel",
      "poison"
    ],
    "966": [
      "steel",
      "poison"
    ],
    "967": [
      "dragon",
      "normal"
    ],
    "968": [
      "steel"
    ],
    "969": [
      "rock",
      "poison"
    ],
    "970": [
      "rock",
      "poison"
    ],
    "971": [
      "ghost"
    ],
    "972": [
      "ghost"
    ],
    "973": [
      "flying",
      "fighting"
    ],
    "974": [
      "ice"
    ],
    "975": [
      "ice"
    ],
    "976": [
      "water",
      "psychic"
    ],
    "977": [
      "water"
    ],
    "978": [
      "dragon",
      "water"
    ],
    "979": [
      "fighting",
      "ghost"
    ],
    "980": [
      "poison",
      "ground"
    ],
    "981": [
      "normal",
      "psychic"
    ],
    "982": [
      "normal"
    ],
    "983": [
      "dark",
      "steel"
    ],
    "984": [
      "ground",
      "fighting"
    ],
    "985": [
      "fairy",
      "psychic"
    ],
    "986": [
      "grass",
      "dark"
    ],
    "987": [
      "ghost",
      "fairy"
    ],
    "988": [
      "bug",
      "fighting"
    ],
    "989": [
      "electric",
      "ground"
    ],
    "990": [
      "ground",
      "steel"
    ],
    "991": [
      "ice",
      "water"
    ],
    "992": [
      "fighting",
      "electric"
    ],
    "993": [
      "dark",
      "flying"
    ],
    "994": [
      "fire",
      "poison"
    ],
    "995": [
      "rock",
      "electric"
    ],
    "996": [
      "dragon",
      "ice"
    ],
    "997": [
      "dragon",
      "ice"
    ],
    "998": [
      "dragon",
      "ice"
    ],
    "999": [
      "ghost"
    ],
    "1000": [
      "steel",
      "ghost"
    ],
    "1001": [
      "dark",
      "grass"
    ],
    "1002": [
      "dark",
      "ice"
    ],
    "1003": [
      "dark",
      "ground"
    ],
    "1004": [
      "dark",
      "fire"
    ],
    "1005": [
      "dragon",
      "dark"
    ],
    "1006": [
      "fairy",
      "fighting"
    ],
    "1007": [
      "fighting",
      "dragon"
    ],
    "1008": [
      "electric",
      "dragon"
    ],
    "1009": [
      "water",
      "dragon"
    ],
    "1010": [
      "grass",
      "psychic"
    ],
    "1011": [
      "grass",
      "dragon"
    ],
    "1012": [
      "grass",
      "ghost"
    ],
    "1013": [
      "grass",
      "ghost"
    ],
    "1014": [
      "poison",
      "fighting"
    ],
    "1015": [
      "poison",
      "psychic"
    ],
    "1016": [
      "poison",
      "fairy"
    ],
    "1017": [
      "grass"
    ],
    "1018": [
      "steel",
      "dragon"
    ],
    "1019": [
      "grass",
      "dragon"
    ],
    "1020": [
      "fire",
      "dragon"
    ],
    "1021": [
      "electric",
      "dragon"
    ],
    "1022": [
      "rock",
      "psychic"
    ],
    "1023": [
      "steel",
      "psychic"
    ],
    "1024": [
      "normal"
    ],
    "1025": [
      "poison",
      "ghost"
    ]
  }
};

// data/background-catalog.json
var background_catalog_default = {
  byType: {
    water: "water",
    fire: "fire",
    ice: "ice",
    flying: "fly",
    grass: "leaf-bug",
    bug: "leaf-bug",
    fighting: "fight",
    ground: "ground",
    rock: "ground",
    poison: "poison",
    steel: "steel",
    ghost: "ghost",
    dark: "dark",
    fairy: "fairy",
    normal: "normal",
    dragon: "dragon",
    psychic: "psychic",
    electric: "electric"
  },
  bySlug: {
    zapdos: "special/zapdos",
    articuno: "special/articuno",
    moltres: "special/moltres",
    raikou: "special/raikou",
    entei: "special/entei",
    suicune: "special/suicune",
    lugia: "special/lugia",
    "ho-oh": "special/ho-oh",
    latias: "special/latias-latios",
    latios: "special/latias-latios",
    "mega-latias": "special/latias-latios",
    "mega-latios": "special/latias-latios",
    kyogre: "special/kyogre",
    "primal-kyogre": "special/kyogre",
    groudon: "special/groudon",
    "primal-groudon": "special/groudon",
    rayquaza: "special/rayquaza",
    "mega-rayquaza": "special/rayquaza",
    jirachi: "special/jirachi",
    arceus: "special/arceus",
    celebi: "special/celebi",
    cresselia: "special/cresselia",
    darkrai: "special/darkrai",
    "mega-darkrai": "special/darkrai",
    deoxys: "special/deoxys",
    "deoxys-attack-forme": "special/deoxys",
    "deoxys-defense-forme": "special/deoxys",
    "deoxys-speed-forme": "special/deoxys",
    dialga: "special/dialga",
    diancie: "special/diancie",
    "mega-diancie": "special/diancie",
    genesect: "special/genesect",
    "giratina-another-forme": "special/giratina",
    "giratina-origin-forme": "special/giratina",
    "hoopa-confined": "special/hoopa-confined",
    "hoopa-unbound": "special/hoopa-confined",
    manaphy: "special/manaphy-phione",
    phione: "special/manaphy-phione",
    "meloetta-aria": "special/meloetta-aria",
    "meloetta-pirouette": "special/meloetta-pirouette",
    mewtwo: "special/mewtwo",
    "mega-mewtwo-x": "special/mewtwo",
    "mega-mewtwo-y": "special/mewtwo",
    palkia: "special/palkia",
    regigigas: "special/regigigas",
    victini: "special/victini",
    zarude: "special/zarude",
    cosmog: "special/ultra-beast",
    cosmoem: "special/ultra-beast",
    nihilego: "special/ultra-beast",
    buzzwole: "special/ultra-beast",
    pheromosa: "special/ultra-beast",
    xurkitree: "special/ultra-beast",
    celesteela: "special/ultra-beast",
    kartana: "special/ultra-beast",
    guzzlord: "special/ultra-beast",
    poipole: "special/ultra-beast",
    naganadel: "special/ultra-beast",
    stakataka: "special/ultra-beast",
    blacephalon: "special/ultra-beast",
    regice: "special/regice",
    regirock: "special/regirock",
    registeel: "special/registeel",
    "shaymin-land-forme": "special/shaymin",
    "shaymin-sky-forme": "special/shaymin",
    "ultra-necrozma": "special/ultranecrozma",
    xerneas: "special/xerneas",
    yveltal: "special/yveltal",
    uxie: "special/uxie-mesprit-azelf",
    mesprit: "special/uxie-mesprit-azelf",
    azelf: "special/uxie-mesprit-azelf",
    zeraora: "special/zeraora",
    "mega-zeraora": "special/zeraora",
    cobalion: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    terrakion: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    virizion: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    keldeo: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    "keldeo-resolute": "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    lunala: "special/lunala",
    "necrozma-dawn-wings": "special/lunala",
    marshadow: "special/marshadow",
    solgaleo: "special/solgaleo",
    "necrozma-dusk-mane": "special/solgaleo",
    koraidon: "special/koraidon",
    kyurem: "special/kyurem",
    "black-kyurem": "special/kyurem",
    "white-kyurem": "special/kyurem",
    mew: "special/mew",
    miraidon: "special/miraidon",
    okidogi: "special/okidogi-munkidori-fezandipiti-pecharunt",
    munkidori: "special/okidogi-munkidori-fezandipiti-pecharunt",
    fezandipiti: "special/okidogi-munkidori-fezandipiti-pecharunt",
    pecharunt: "special/okidogi-munkidori-fezandipiti-pecharunt",
    zekrom: "special/zekrom",
    "tornadus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "tornadus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "thundurus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "thundurus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "landorus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "landorus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "enamorus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "enamorus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "tapu-koko": "special/tapu",
    "tapu-lele": "special/tapu",
    "tapu-bulu": "special/tapu",
    "tapu-fini": "special/tapu",
    "articuno-galarian": "special/articuno-galarian",
    "zapdos-galarian": "special/zapdos-galarian",
    "moltres-galarian": "special/moltres-galarian",
    eternatus: "special/eternatus",
    kubfu: "special/kubfu",
    necrozma: "special/necrozma",
    reshiram: "special/reshiram",
    "urshifu-rapid-strike": "special/urshifu-rapid-strike",
    "urshifu-rapid-strike-gigantamax": "special/gigantamax",
    "urshifu-single-strike": "special/urshifu-single-strike",
    "urshifu-single-strike-gigantamax": "special/gigantamax",
    "zacian-crowned-sword": "special/zacian",
    "zacian-hero-of-many-battles": "special/zacian",
    "zamazenta-crowned-shield": "special/zamazenta",
    "zamazenta-hero-of-many-battles": "special/zamazenta",
    "mega-zygarde": "special/zygarde",
    "zygarde-10-forme": "special/zygarde",
    "zygarde-50-forme": "special/zygarde",
    "zygarde-complete-forme": "special/zygarde",
    "type-null": "special/typenullsilvally",
    silvally: "special/typenullsilvally",
    "chien-pao": "special/chienpao",
    "chi-yu": "special/chiyu",
    "ting-lu": "special/tinglu",
    "wo-chien": "special/wochien",
    "ogerpon-cornerstone-mask": "special/ogerpon",
    "ogerpon-hearthflame-mask": "special/ogerpon",
    "ogerpon-teal-mask": "special/ogerpon",
    "ogerpon-wellspring-mask": "special/ogerpon",
    calyrex: "special/calyrex-glastrier-calyrex-ice-rider",
    glastrier: "special/calyrex-glastrier-calyrex-ice-rider",
    "calyrex-ice-rider": "special/calyrex-glastrier-calyrex-ice-rider",
    spectrier: "special/spectrier-calyrex-shadow-rider",
    "calyrex-shadow-rider": "special/spectrier-calyrex-shadow-rider",
    heatran: "special/heatran",
    "mega-heatran": "special/heatran",
    magearna: "special/magearna",
    "mega-magearna": "special/magearna",
    meltan: "special/meltan-melmetal",
    melmetal: "special/meltan-melmetal",
    "melmetal-gigantamax": "special/gigantamax",
    regidrago: "special/regidrago",
    regieleki: "special/regieleki",
    volcanion: "special/volcanion",
    "venusaur-gigantamax": "special/gigantamax",
    "charizard-gigantamax": "special/gigantamax",
    "blastoise-gigantamax": "special/gigantamax",
    "butterfree-gigantamax": "special/gigantamax",
    "pikachu-gigantamax": "special/gigantamax",
    "meowth-gigantamax": "special/gigantamax",
    "machamp-gigantamax": "special/gigantamax",
    "gengar-gigantamax": "special/gigantamax",
    "kingler-gigantamax": "special/gigantamax",
    "lapras-gigantamax": "special/gigantamax",
    "eevee-gigantamax": "special/gigantamax",
    "snorlax-gigantamax": "special/gigantamax",
    "garbodor-gigantamax": "special/gigantamax",
    "rillaboom-gigantamax": "special/gigantamax",
    "cinderace-gigantamax": "special/gigantamax",
    "inteleon-gigantamax": "special/gigantamax",
    "corviknight-gigantamax": "special/gigantamax",
    "orbeetle-gigantamax": "special/gigantamax",
    "drednaw-gigantamax": "special/gigantamax",
    "coalossal-gigantamax": "special/gigantamax",
    "flapple-gigantamax": "special/gigantamax",
    "appletun-gigantamax": "special/gigantamax",
    "sandaconda-gigantamax": "special/gigantamax",
    "toxtricity-gigantamax": "special/gigantamax",
    "centiskorch-gigantamax": "special/gigantamax",
    "hatterene-gigantamax": "special/gigantamax",
    "grimmsnarl-gigantamax": "special/gigantamax",
    "alcremie-gigantamax": "special/gigantamax",
    "copperajah-gigantamax": "special/gigantamax",
    "duraludon-gigantamax": "special/gigantamax",
    "great-tusk": "special/paradox-ancient",
    "scream-tail": "special/paradox-ancient",
    "brute-bonnet": "special/paradox-ancient",
    "flutter-mane": "special/paradox-ancient",
    "slither-wing": "special/paradox-ancient",
    "sandy-shocks": "special/paradox-ancient",
    "roaring-moon": "special/paradox-ancient",
    "walking-wake": "special/paradox-ancient",
    "gouging-fire": "special/paradox-ancient",
    "raging-bolt": "special/paradox-ancient",
    "iron-treads": "special/paradox-future",
    "iron-bundle": "special/paradox-future",
    "iron-hands": "special/paradox-future",
    "iron-jugulis": "special/paradox-future",
    "iron-moth": "special/paradox-future",
    "iron-thorns": "special/paradox-future",
    "iron-valiant": "special/paradox-future",
    "iron-leaves": "special/paradox-future",
    "iron-boulder": "special/paradox-future",
    "iron-crown": "special/paradox-future",
    terapagos: "special/terapagos",
    "terapagos-terastal": "special/terapagos"
  },
  items: {
    water: {
      id: "water",
      title: "물 타입 배경",
      path: "./assets/backgrounds/water.webp"
    },
    fire: {
      id: "fire",
      title: "불꽃 타입 배경",
      path: "./assets/backgrounds/fire.webp"
    },
    ice: {
      id: "ice",
      title: "얼음 타입 배경",
      path: "./assets/backgrounds/ice.webp"
    },
    fly: {
      id: "fly",
      title: "비행 타입 배경",
      path: "./assets/backgrounds/fly.webp"
    },
    "leaf-bug": {
      id: "leaf-bug",
      title: "풀 · 벌레 타입 배경",
      path: "./assets/backgrounds/leaf-bug.webp"
    },
    fight: {
      id: "fight",
      title: "격투 타입 배경",
      path: "./assets/backgrounds/fight.webp"
    },
    ground: {
      id: "ground",
      title: "땅 · 바위 타입 배경",
      path: "./assets/backgrounds/ground.webp"
    },
    poison: {
      id: "poison",
      title: "독 타입 배경",
      path: "./assets/backgrounds/poison.webp"
    },
    steel: {
      id: "steel",
      title: "강철 타입 배경",
      path: "./assets/backgrounds/steel.webp"
    },
    ghost: {
      id: "ghost",
      title: "고스트 타입 배경",
      path: "./assets/backgrounds/ghost.webp"
    },
    dark: {
      id: "dark",
      title: "악 타입 배경",
      path: "./assets/backgrounds/dark.webp"
    },
    fairy: {
      id: "fairy",
      title: "페어리 타입 배경",
      path: "./assets/backgrounds/fairy.webp"
    },
    normal: {
      id: "normal",
      title: "노말 타입 배경",
      path: "./assets/backgrounds/normal.webp"
    },
    dragon: {
      id: "dragon",
      title: "드래곤 타입 배경",
      path: "./assets/backgrounds/dragon.webp"
    },
    psychic: {
      id: "psychic",
      title: "에스퍼 타입 배경",
      path: "./assets/backgrounds/psychic.webp"
    },
    electric: {
      id: "electric",
      title: "전기 타입 배경",
      path: "./assets/backgrounds/electric.webp"
    },
    "special/zapdos": {
      id: "special/zapdos",
      title: "썬더 전용 배경",
      path: "./assets/backgrounds/special/zapdos.webp"
    },
    "special/articuno": {
      id: "special/articuno",
      title: "프리져 전용 배경",
      path: "./assets/backgrounds/special/articuno.webp"
    },
    "special/moltres": {
      id: "special/moltres",
      title: "파이어 전용 배경",
      path: "./assets/backgrounds/special/moltres.webp"
    },
    "special/raikou": {
      id: "special/raikou",
      title: "라이코 전용 배경",
      path: "./assets/backgrounds/special/raikou.webp"
    },
    "special/entei": {
      id: "special/entei",
      title: "앤테이 전용 배경",
      path: "./assets/backgrounds/special/entei.webp"
    },
    "special/suicune": {
      id: "special/suicune",
      title: "스이쿤 전용 배경",
      path: "./assets/backgrounds/special/suicune.webp"
    },
    "special/lugia": {
      id: "special/lugia",
      title: "루기아 전용 배경",
      path: "./assets/backgrounds/special/lugia.webp"
    },
    "special/ho-oh": {
      id: "special/ho-oh",
      title: "칠색조 전용 배경",
      path: "./assets/backgrounds/special/ho-oh.webp"
    },
    "special/latias-latios": {
      id: "special/latias-latios",
      title: "라티아스 전용 배경",
      path: "./assets/backgrounds/special/latias-latios.webp"
    },
    "special/kyogre": {
      id: "special/kyogre",
      title: "가이오가 전용 배경",
      path: "./assets/backgrounds/special/kyogre.webp"
    },
    "special/groudon": {
      id: "special/groudon",
      title: "그란돈 전용 배경",
      path: "./assets/backgrounds/special/groudon.webp"
    },
    "special/rayquaza": {
      id: "special/rayquaza",
      title: "레쿠쟈 전용 배경",
      path: "./assets/backgrounds/special/rayquaza.webp"
    },
    "special/jirachi": {
      id: "special/jirachi",
      title: "지라치 전용 배경",
      path: "./assets/backgrounds/special/jirachi.webp"
    },
    "special/arceus": {
      id: "special/arceus",
      title: "아르세우스 전용 배경",
      path: "./assets/backgrounds/special/arceus.webp"
    },
    "special/celebi": {
      id: "special/celebi",
      title: "세레비 전용 배경",
      path: "./assets/backgrounds/special/celebi.webp"
    },
    "special/cresselia": {
      id: "special/cresselia",
      title: "크레세리아 전용 배경",
      path: "./assets/backgrounds/special/cresselia.webp"
    },
    "special/darkrai": {
      id: "special/darkrai",
      title: "다크라이 전용 배경",
      path: "./assets/backgrounds/special/darkrai.webp"
    },
    "special/deoxys": {
      id: "special/deoxys",
      title: "테오키스 전용 배경",
      path: "./assets/backgrounds/special/deoxys.webp"
    },
    "special/dialga": {
      id: "special/dialga",
      title: "디아루가 전용 배경",
      path: "./assets/backgrounds/special/dialga.webp"
    },
    "special/diancie": {
      id: "special/diancie",
      title: "디안시 전용 배경",
      path: "./assets/backgrounds/special/diancie.webp"
    },
    "special/genesect": {
      id: "special/genesect",
      title: "게노세크트 전용 배경",
      path: "./assets/backgrounds/special/genesect.webp"
    },
    "special/giratina": {
      id: "special/giratina",
      title: "기라티나 전용 배경",
      path: "./assets/backgrounds/special/giratina.webp"
    },
    "special/hoopa-confined": {
      id: "special/hoopa-confined",
      title: "차원의 회랑",
      path: "./assets/backgrounds/special/hoopa-confined.webp"
    },
    "special/manaphy-phione": {
      id: "special/manaphy-phione",
      title: "바다의 요람",
      path: "./assets/backgrounds/special/manaphy-phione.webp"
    },
    "special/meloetta-aria": {
      id: "special/meloetta-aria",
      title: "메로엣타 전용 배경",
      path: "./assets/backgrounds/special/meloetta-aria.webp"
    },
    "special/meloetta-pirouette": {
      id: "special/meloetta-pirouette",
      title: "메로엣타(스텝폼) 전용 배경",
      path: "./assets/backgrounds/special/meloetta-pirouette.webp"
    },
    "special/mewtwo": {
      id: "special/mewtwo",
      title: "뮤츠 전용 배경",
      path: "./assets/backgrounds/special/mewtwo.webp"
    },
    "special/palkia": {
      id: "special/palkia",
      title: "펄기아 전용 배경",
      path: "./assets/backgrounds/special/palkia.webp"
    },
    "special/regigigas": {
      id: "special/regigigas",
      title: "레지기가스 전용 배경",
      path: "./assets/backgrounds/special/regigigas.webp"
    },
    "special/victini": {
      id: "special/victini",
      title: "비크티니 전용 배경",
      path: "./assets/backgrounds/special/victini.webp"
    },
    "special/zarude": {
      id: "special/zarude",
      title: "자루도 전용 배경",
      path: "./assets/backgrounds/special/zarude.webp"
    },
    "special/ultra-beast": {
      id: "special/ultra-beast",
      title: "울트라스페이스",
      path: "./assets/backgrounds/special/ultra-beast.webp"
    },
    "special/regice": {
      id: "special/regice",
      title: "레지아이스 전용 배경",
      path: "./assets/backgrounds/special/regice.webp"
    },
    "special/regirock": {
      id: "special/regirock",
      title: "레지락 전용 배경",
      path: "./assets/backgrounds/special/regirock.webp"
    },
    "special/registeel": {
      id: "special/registeel",
      title: "레지스틸 전용 배경",
      path: "./assets/backgrounds/special/registeel.webp"
    },
    "special/shaymin": {
      id: "special/shaymin",
      title: "쉐이미 전용 배경",
      path: "./assets/backgrounds/special/shaymin.webp"
    },
    "special/ultranecrozma": {
      id: "special/ultranecrozma",
      title: "울트라네크로즈마 전용 배경",
      path: "./assets/backgrounds/special/ultranecrozma.webp"
    },
    "special/xerneas": {
      id: "special/xerneas",
      title: "제르네아스 전용 배경",
      path: "./assets/backgrounds/special/xerneas.webp"
    },
    "special/yveltal": {
      id: "special/yveltal",
      title: "이벨타르 전용 배경",
      path: "./assets/backgrounds/special/yveltal.webp"
    },
    "special/uxie-mesprit-azelf": {
      id: "special/uxie-mesprit-azelf",
      title: "진실 호수",
      path: "./assets/backgrounds/special/uxie-mesprit-azelf.webp"
    },
    "special/zeraora": {
      id: "special/zeraora",
      title: "제라오라 전용 배경",
      path: "./assets/backgrounds/special/zeraora.webp"
    },
    "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute": {
      id: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
      title: "성검사",
      path: "./assets/backgrounds/special/cobalion-terrakion-virizion-keldeo-keldeo-resolute.webp"
    },
    "special/lunala": {
      id: "special/lunala",
      title: "루나아라 전용 배경",
      path: "./assets/backgrounds/special/lunala.webp"
    },
    "special/marshadow": {
      id: "special/marshadow",
      title: "마샤도 전용 배경",
      path: "./assets/backgrounds/special/marshadow.webp"
    },
    "special/solgaleo": {
      id: "special/solgaleo",
      title: "솔가레오 전용 배경",
      path: "./assets/backgrounds/special/solgaleo.webp"
    },
    "special/koraidon": {
      id: "special/koraidon",
      title: "코라이돈 전용 배경",
      path: "./assets/backgrounds/special/koraidon.webp"
    },
    "special/kyurem": {
      id: "special/kyurem",
      title: "큐레무 전용 배경",
      path: "./assets/backgrounds/special/kyurem.webp"
    },
    "special/mew": {
      id: "special/mew",
      title: "뮤 전용 배경",
      path: "./assets/backgrounds/special/mew.webp"
    },
    "special/miraidon": {
      id: "special/miraidon",
      title: "미라이돈 전용 배경",
      path: "./assets/backgrounds/special/miraidon.webp"
    },
    "special/okidogi-munkidori-fezandipiti-pecharunt": {
      id: "special/okidogi-munkidori-fezandipiti-pecharunt",
      title: "복숭아 신사",
      path: "./assets/backgrounds/special/okidogi-munkidori-fezandipiti-pecharunt.webp"
    },
    "special/zekrom": {
      id: "special/zekrom",
      title: "제크로무 전용 배경",
      path: "./assets/backgrounds/special/zekrom.webp"
    },
    "special/tornadus-thundurus-landorus-enamorus": {
      id: "special/tornadus-thundurus-landorus-enamorus",
      title: "풍요의 사당",
      path: "./assets/backgrounds/special/tornadus-thundurus-landorus-enamorus.webp"
    },
    "special/tapu": {
      id: "special/tapu",
      title: "수호신의 제단",
      path: "./assets/backgrounds/special/tapu.webp"
    },
    "special/articuno-galarian": {
      id: "special/articuno-galarian",
      title: "가라르 프리져 전용 배경",
      path: "./assets/backgrounds/special/articuno-galarian.webp"
    },
    "special/zapdos-galarian": {
      id: "special/zapdos-galarian",
      title: "가라르 썬더 전용 배경",
      path: "./assets/backgrounds/special/zapdos-galarian.webp"
    },
    "special/moltres-galarian": {
      id: "special/moltres-galarian",
      title: "가라르 파이어 전용 배경",
      path: "./assets/backgrounds/special/moltres-galarian.webp"
    },
    "special/eternatus": {
      id: "special/eternatus",
      title: "무한다이노 전용 배경",
      path: "./assets/backgrounds/special/eternatus.webp"
    },
    "special/kubfu": {
      id: "special/kubfu",
      title: "치고마 전용 배경",
      path: "./assets/backgrounds/special/kubfu.webp"
    },
    "special/necrozma": {
      id: "special/necrozma",
      title: "네크로즈마 전용 배경",
      path: "./assets/backgrounds/special/necrozma.webp"
    },
    "special/reshiram": {
      id: "special/reshiram",
      title: "레시라무 전용 배경",
      path: "./assets/backgrounds/special/reshiram.webp"
    },
    "special/urshifu-rapid-strike": {
      id: "special/urshifu-rapid-strike",
      title: "우라오스 (연격의태세) 전용 배경",
      path: "./assets/backgrounds/special/urshifu-rapid-strike.webp"
    },
    "special/urshifu-single-strike": {
      id: "special/urshifu-single-strike",
      title: "우라오스 (일격의태세) 전용 배경",
      path: "./assets/backgrounds/special/urshifu-single-strike.webp"
    },
    "special/zacian": {
      id: "special/zacian",
      title: "자시안 전용 배경",
      path: "./assets/backgrounds/special/zacian.webp"
    },
    "special/zamazenta": {
      id: "special/zamazenta",
      title: "자마젠타 전용 배경",
      path: "./assets/backgrounds/special/zamazenta.webp"
    },
    "special/zygarde": {
      id: "special/zygarde",
      title: "지가르데 전용 배경",
      path: "./assets/backgrounds/special/zygarde.webp"
    },
    "special/typenullsilvally": {
      id: "special/typenullsilvally",
      title: "에테르파라다이스",
      path: "./assets/backgrounds/special/typenullsilvally.webp"
    },
    "special/chienpao": {
      id: "special/chienpao",
      title: "파오젠 전용 배경",
      path: "./assets/backgrounds/special/chienpao.webp"
    },
    "special/chiyu": {
      id: "special/chiyu",
      title: "위유이 전용 배경",
      path: "./assets/backgrounds/special/chiyu.webp"
    },
    "special/tinglu": {
      id: "special/tinglu",
      title: "딩루 전용 배경",
      path: "./assets/backgrounds/special/tinglu.webp"
    },
    "special/wochien": {
      id: "special/wochien",
      title: "총지엔 전용 배경",
      path: "./assets/backgrounds/special/wochien.webp"
    },
    "special/ogerpon": {
      id: "special/ogerpon",
      title: "오거폰 전용 배경",
      path: "./assets/backgrounds/special/ogerpon.webp"
    },
    "special/calyrex-glastrier-calyrex-ice-rider": {
      id: "special/calyrex-glastrier-calyrex-ice-rider",
      title: "설원의 왕좌",
      path: "./assets/backgrounds/special/calyrex-glastrier-calyrex-ice-rider.webp"
    },
    "special/spectrier-calyrex-shadow-rider": {
      id: "special/spectrier-calyrex-shadow-rider",
      title: "월영의 왕좌",
      path: "./assets/backgrounds/special/spectrier-calyrex-shadow-rider.webp"
    },
    "special/heatran": {
      id: "special/heatran",
      title: "히드런 전용 배경",
      path: "./assets/backgrounds/special/heatran.webp"
    },
    "special/magearna": {
      id: "special/magearna",
      title: "마기아나 전용 배경",
      path: "./assets/backgrounds/special/magearna.webp"
    },
    "special/meltan-melmetal": {
      id: "special/meltan-melmetal",
      title: "강철 제련소",
      path: "./assets/backgrounds/special/meltan-melmetal.webp"
    },
    "special/regidrago": {
      id: "special/regidrago",
      title: "레지드래고 전용 배경",
      path: "./assets/backgrounds/special/regidrago.webp"
    },
    "special/regieleki": {
      id: "special/regieleki",
      title: "레지에레키 전용 배경",
      path: "./assets/backgrounds/special/regieleki.webp"
    },
    "special/volcanion": {
      id: "special/volcanion",
      title: "볼케니온 전용 배경",
      path: "./assets/backgrounds/special/volcanion.webp"
    },
    "special/gigantamax": {
      id: "special/gigantamax",
      title: "거다이맥스 폭풍",
      path: "./assets/backgrounds/special/gigantamax.webp"
    },
    "special/paradox-ancient": {
      id: "special/paradox-ancient",
      title: "태고의 대지",
      path: "./assets/backgrounds/special/paradox-ancient.webp"
    },
    "special/paradox-future": {
      id: "special/paradox-future",
      title: "미래의 도시",
      path: "./assets/backgrounds/special/paradox-future.webp"
    },
    "special/terapagos": {
      id: "special/terapagos",
      title: "결정의 성전",
      path: "./assets/backgrounds/special/terapagos.webp"
    }
  }
};

// cloudflare/worker.mjs
var VERSION = "2026-03-11";
var DEFAULT_ORIGIN = "https://pokemon.loraticon.com";
var SETTINGS_SLUG = "__widget_settings_v1__";
var SETTINGS_CAPTION = "pokemon-widget-preferences-v1";
var remoteImages = "https://raw.githubusercontent.com/loraticon/random_pokemon_widget-ver1/main/images";
var koreaDay = (time = Date.now()) => new Date(new Date(time).getTime() + 324e5).toISOString().slice(0, 10);
var normalizeSlug = (slug) => String(slug).replace(/^mr[.-]+mime$/i, "mr-mime").replace(/farfetch['’]d/gi, "farfetchd").replace(/^nidoran♀$/i, "nidoran-f").replace(/^nidoran♂$/i, "nidoran-m");
var captureKey = (record) => normalizeSlug(record.slug) + ":false";
var entries = new Map(pokemon_final_with_forms_default.map((entry) => [normalizeSlug(entry.slug), entry]));
var defaultPreferences = { mode: "draw", pokemonKey: "", backgroundId: "", favoritePokemon: [], favoriteBackgrounds: [] };
var properties = { "이름": { title: {} }, "폼 식별자": { rich_text: {} }, "배경 식별자": { rich_text: {} }, "즐겨찾기": { checkbox: {} } };
function backgroundFor(record) {
  if (record.backgroundId) return background_catalog_default.items[record.backgroundId] || null;
  const slug = normalizeSlug(record.slug);
  const types = pokemon_background_types_default.bySlug[slug] || pokemon_background_types_default.byDex[record.dexId] || [];
  const id = background_catalog_default.bySlug[slug] || types.map((type) => background_catalog_default.byType[type]).find(Boolean);
  return background_catalog_default.items[id] || null;
}
var richText = (content) => [{ type: "text", text: { content: String(content) } }];
var plain = (property) => (property?.title || property?.rich_text || []).map((part) => part.plain_text || part.text?.content || "").join("");
var json = (data, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } });
var ServiceError = class extends Error {
  constructor(message, status = 503, uncertain = false, code) {
    super(message);
    Object.assign(this, { status, uncertain, code });
  }
};
function pageId(value) {
  const input = String(value || "").trim();
  if (/^[0-9a-f]{32}$/i.test(input)) return input.toLowerCase();
  if (/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(input)) return input.replaceAll("-", "").toLowerCase();
  let url;
  try {
    url = new URL(input);
  } catch {
  }
  if (!url || url.protocol !== "https:" || url.username || url.password || !/(^|\.)(notion\.so|notion\.site)$/.test(url.hostname)) {
    throw new ServiceError("복제한 노션 수집 DB의 HTTPS 주소를 입력해주세요.", 400);
  }
  const id = decodeURIComponent(url.pathname).match(/([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}|[0-9a-f]{32})\/?$/i)?.[1];
  if (!id) throw new ServiceError("복제한 원본 노션 DB 주소를 확인해주세요.", 400);
  return id.replaceAll("-", "").toLowerCase();
}
var queues = /* @__PURE__ */ new Map();
async function serial(databaseId, task) {
  const previous = queues.get(databaseId) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => {
    release = resolve;
  });
  queues.set(databaseId, current);
  await previous;
  try {
    return await task();
  } finally {
    release();
    if (queues.get(databaseId) === current) queues.delete(databaseId);
  }
}
var worker_default = {
  async fetch(request, env) {
    const origin = request.headers.get("Origin");
    let allowedOrigin;
    try {
      const configured = new URL(env.WIDGET_ORIGIN || DEFAULT_ORIGIN);
      if (configured.protocol === "https:" && !configured.username && !configured.password && !configured.search && !configured.hash && configured.pathname === "/") allowedOrigin = configured.origin;
    } catch {
    }
    const respond = (response) => {
      const headers = new Headers(response.headers);
      headers.set("Vary", "Origin");
      if (origin && origin === allowedOrigin) headers.set("Access-Control-Allow-Origin", origin);
      return new Response(response.body, { status: response.status, headers });
    };
    const reject = (message, status) => respond(json({ error: message }, status));
    if (!allowedOrigin) return reject("Worker의 WIDGET_ORIGIN 설정을 확인해주세요.", 503);
    if (origin && origin !== allowedOrigin) return reject("허용되지 않은 위젯 주소입니다.", 403);
    const url = new URL(request.url);
    const methods = { "/api/setup": "POST", "/api/collection": "GET", "/api/capture": "POST", "/api/preferences": "POST" };
    if (!methods[url.pathname]) return reject("개인 Worker는 수집 API만 제공합니다.", 404);
    if (request.method === "OPTIONS") {
      const asked = (request.headers.get("Access-Control-Request-Headers") || "").split(",").map((x) => x.trim().toLowerCase()).filter(Boolean);
      if (!origin || request.headers.get("Access-Control-Request-Method") !== methods[url.pathname] || asked.some((x) => x !== "content-type")) return reject("지원하지 않는 연결 요청입니다.", 403);
      return respond(new Response(null, { status: 204, headers: { "Access-Control-Allow-Methods": methods[url.pathname], "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Max-Age": "86400" } }));
    }
    if (request.method !== methods[url.pathname]) return reject("지원하지 않는 요청 방식입니다.", 405);
    if (!env.NOTION_TOKEN) return reject("개인 Worker의 Secret에 NOTION_TOKEN을 등록하고 배포해주세요.", 503);
    try {
      let body = {};
      if (request.method === "POST") {
        const text = await request.text();
        if (new TextEncoder().encode(text).length > 65536) throw new ServiceError("저장 요청이 너무 커요.", 413);
        try {
          body = JSON.parse(text);
        } catch {
          throw new ServiceError("연결 요청 형식을 확인해주세요.", 400);
        }
        if (!body || typeof body !== "object" || Array.isArray(body)) throw new ServiceError("연결 요청 형식을 확인해주세요.", 400);
      }
      const databaseId = pageId(body.databaseId || url.searchParams.get("db"));
      const collection = new NotionCollection(env, databaseId, allowedOrigin);
      const result = await serial(databaseId, async () => {
        if (url.pathname === "/api/setup") {
          const config = await collection.database(true);
          await collection.settings(true);
          return { databaseId, databaseUrl: config.url, dailyLimit: collection.limit };
        }
        if (url.pathname === "/api/capture") return collection.capture(body);
        if (url.pathname === "/api/preferences") return collection.savePreferences(body);
        return collection.getSnapshot(url.searchParams.get("records") === "1");
      });
      return respond(json(result));
    } catch (error) {
      return respond(json({ error: error instanceof ServiceError ? error.message : "노션 연결을 처리하지 못했어요. 잠시 후 다시 확인해주세요.", ...error.code ? { code: error.code } : {} }, error.status || 503));
    }
  }
};
var NotionCollection = class {
  constructor(env, databaseId, origin = DEFAULT_ORIGIN) {
    this.env = env;
    this.databaseId = pageId(databaseId);
    this.origin = origin;
    const limit = Number(env.DAILY_LIMIT ?? 3);
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new ServiceError("DAILY_LIMIT은 1~100 사이의 정수로 설정해주세요.", 400);
    this.limit = limit;
  }
  async notion(path, body, method = body ? "POST" : "GET") {
    let response;
    try {
      response = await fetch("https://api.notion.com/v1/" + path, {
        method,
        headers: { Authorization: "Bearer " + this.env.NOTION_TOKEN, "Notion-Version": VERSION, "Content-Type": "application/json" },
        body: body ? JSON.stringify(body) : void 0,
        signal: AbortSignal.timeout(18e3)
      });
    } catch {
      throw new ServiceError("노션 응답이 지연되고 있어요. 잠시 후 저장 상태를 확인해주세요.", 503, true);
    }
    if (!response.ok) {
      const message = response.status === 401 ? "노션 연결 토큰을 확인해주세요." : [403, 404].includes(response.status) ? "복제한 원본 DB 주소와 노션의 연결 추가 권한을 확인해주세요." : response.status === 429 ? "노션 요청이 잠시 많아졌어요. 조금 뒤 다시 확인해주세요." : "노션 기록을 처리하지 못했어요. DB 속성과 연결 설정을 확인해주세요.";
      throw new ServiceError(message, response.status === 429 ? 429 : 503, response.status >= 500 || response.status === 408);
    }
    try {
      return await response.json();
    } catch {
      throw new ServiceError("노션 응답을 읽지 못했어요. 저장 상태를 확인해주세요.", 503, true);
    }
  }
  async database(prepare = false) {
    if (!this.config) {
      const database = await this.notion("databases/" + this.databaseId);
      if (database.data_sources?.length !== 1) throw new ServiceError("데이터 소스가 하나인 원본 수집 DB를 연결해주세요.", 400);
      this.config = { source: database.data_sources[0].id, url: database.url || "https://www.notion.so/" + this.databaseId };
    }
    if (prepare) {
      const source = await this.notion("data_sources/" + this.config.source);
      for (const [name, definition] of Object.entries(properties)) {
        if (source.properties?.[name] && !(Object.keys(definition)[0] in source.properties[name])) throw new ServiceError(`노션의 '${name}' 속성 유형을 확인해주세요.`, 400);
      }
      const missing = Object.fromEntries(Object.entries(properties).filter(([name]) => !source.properties?.[name]));
      if (Object.keys(missing).length) await this.notion("data_sources/" + this.config.source, { properties: missing }, "PATCH");
    }
    return this.config;
  }
  async query(filter) {
    const config = await this.database();
    const pages = [];
    let cursor;
    for (let count = 0; count < 100; count++) {
      const data = await this.notion(`data_sources/${config.source}/query`, { page_size: 100, ...filter ? { filter } : {}, ...cursor ? { start_cursor: cursor } : {} });
      pages.push(...data.results.filter((page) => !page.archived && !page.in_trash));
      if (!data.has_more) return pages;
      cursor = data.next_cursor;
      if (!cursor) break;
    }
    throw new ServiceError("노션 기록을 모두 읽지 못했어요. 다시 확인해주세요.");
  }
  async settings(create = false) {
    if (this.settingsRecord) return this.settingsRecord;
    const pages = await this.query({ property: "폼 식별자", rich_text: { equals: SETTINGS_SLUG } });
    let page = pages.sort((a, b) => String(a.created_time).localeCompare(String(b.created_time)) || a.id.localeCompare(b.id))[0];
    if (!page && create) {
      page = await this.notion("pages", {
        parent: { type: "data_source_id", data_source_id: (await this.database()).source },
        properties: { "이름": { title: richText("위젯 설정") }, "폼 식별자": { rich_text: richText(SETTINGS_SLUG) } },
        children: [{ object: "block", type: "code", code: { language: "json", caption: richText(SETTINGS_CAPTION), rich_text: this.settingsText(defaultPreferences) } }]
      });
    }
    if (!page) throw new ServiceError("연결 페이지에서 DB를 연결해 위젯 설정 페이지를 준비해주세요.", 400);
    let cursor;
    let block;
    for (let count = 0; count < 10; count++) {
      const data = await this.notion(`blocks/${page.id}/children?page_size=100${cursor ? "&start_cursor=" + encodeURIComponent(cursor) : ""}`);
      block = data.results.find((item) => item.type === "code" && plain({ rich_text: item.code.caption }) === SETTINGS_CAPTION);
      if (block || !data.has_more) break;
      cursor = data.next_cursor;
      if (!cursor) break;
    }
    if (!block) throw new ServiceError("노션의 위젯 설정 페이지에서 설정 블록을 찾지 못했어요.", 400);
    let preferences;
    try {
      preferences = JSON.parse(plain({ rich_text: block.code.rich_text }));
    } catch {
      throw new ServiceError("노션 위젯 설정 내용을 확인해주세요.", 400);
    }
    if (!preferences || !["draw", "sleep"].includes(preferences.mode) || typeof preferences.pokemonKey !== "string" || typeof preferences.backgroundId !== "string" || !Array.isArray(preferences.favoriteBackgrounds)) throw new ServiceError("노션 위젯 설정 형식을 확인해주세요.", 400);
    return this.settingsRecord = { pageId: page.id, blockId: block.id, preferences: { ...defaultPreferences, ...preferences } };
  }
  settingsText(preferences) {
    const text = JSON.stringify({ mode: preferences.mode, pokemonKey: preferences.pokemonKey, backgroundId: preferences.backgroundId, favoriteBackgrounds: preferences.favoriteBackgrounds });
    return text.match(/[\s\S]{1,1800}/gu).map((part) => richText(part)[0]);
  }
  toRecord(page) {
    const p = page.properties;
    const slug = normalizeSlug(plain(p["폼 식별자"]));
    const entry = entries.get(slug);
    if (!entry) throw new ServiceError(`노션의 폼 식별자 '${slug}'를 확인해주세요.`, 400);
    const backgroundId = plain(p["배경 식별자"]).trim();
    if (backgroundId && !background_catalog_default.items[backgroundId]) throw new ServiceError(`노션의 배경 식별자 '${backgroundId}'를 확인해주세요.`, 400);
    const record = {
      id: page.id,
      pageId: page.id,
      slug,
      dexId: entry.dexId,
      name: plain(p["이름"]) || entry.ko || entry.en,
      isShiny: false,
      favorite: Boolean(p["즐겨찾기"]?.checkbox),
      backgroundId,
      capturedAt: page.created_time,
      imageSrc: `${remoteImages}/normal/${encodeURIComponent(slug)}.webp`
    };
    const background = backgroundFor(record);
    return { ...record, backgroundId: background?.id || "", backgroundName: background?.title || "", backgroundSrc: background ? new URL(background.path.slice(2), this.origin).href : "" };
  }
  async readRecords() {
    return (await this.query()).filter((page) => plain(page.properties["폼 식별자"]) !== SETTINGS_SLUG && !page.properties["색이 다름"]?.checkbox).map((page) => this.toRecord(page)).sort((a, b) => a.dexId - b.dexId);
  }
  preferences(records, stored) {
    const pokemon = new Set(records.map(captureKey));
    const backgrounds = new Set(records.map((record) => record.backgroundId).filter(Boolean));
    return {
      ...defaultPreferences,
      ...stored,
      pokemonKey: pokemon.has(stored.pokemonKey) ? stored.pokemonKey : "",
      backgroundId: backgrounds.has(stored.backgroundId) ? stored.backgroundId : "",
      favoritePokemon: [...new Set(records.filter((record) => record.favorite).map(captureKey))],
      favoriteBackgrounds: [...new Set(stored.favoriteBackgrounds)].filter((id) => backgrounds.has(id))
    };
  }
  async getSnapshot(all = true) {
    const records = await this.readRecords();
    const settings = await this.settings();
    const day = koreaDay();
    const used = records.filter((record) => koreaDay(record.capturedAt) === day).length;
    return {
      schemaVersion: 4,
      day,
      used,
      limit: this.limit,
      remaining: Math.max(0, this.limit - used),
      pending: [],
      owned: [...new Set(records.map(captureKey))],
      records: all ? records : [],
      nextCursor: null,
      preferences: this.preferences(records, settings.preferences)
    };
  }
  async capture(body) {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(body.id || "") || body.isShiny !== false) throw new ServiceError("일반 포켓몬의 수집 요청을 확인해주세요.", 400);
    const slug = normalizeSlug(body.slug);
    const entry = entries.get(slug);
    if (!entry) throw new ServiceError("도감에 없는 포켓몬입니다.", 400);
    const before = await this.getSnapshot();
    if (before.owned.includes(captureKey(entry))) throw new ServiceError("이미 잡은 포켓몬이에요.", 409, false, "ALREADY_COLLECTED");
    if (!before.remaining) throw new ServiceError("오늘의 수집 기회를 모두 사용했어요.", 409, false, "DAILY_LIMIT");
    const background = backgroundFor(entry);
    try {
      await this.notion("pages", { parent: { type: "data_source_id", data_source_id: (await this.database()).source }, properties: {
        "이름": { title: richText(entry.ko || entry.en) },
        "폼 식별자": { rich_text: richText(slug) },
        "배경 식별자": { rich_text: richText(background?.id || "") },
        "즐겨찾기": { checkbox: false }
      } });
    } catch (error) {
      if (!error.uncertain) throw error;
      const after = await this.getSnapshot();
      if (after.owned.includes(captureKey(entry))) return after;
      throw error;
    }
    return this.getSnapshot();
  }
  async savePreferences(body) {
    const records = await this.readRecords();
    const settings = await this.settings();
    const current = this.preferences(records, settings.preferences);
    if (body.favoriteChange) {
      const { pokemonKey, favorite } = body.favoriteChange;
      const matches = records.filter((record) => captureKey(record) === pokemonKey);
      if (typeof favorite !== "boolean" || !matches.length) throw new ServiceError("수집한 포켓몬만 즐겨찾기에 추가할 수 있어요.", 400);
      for (const record of matches) if (record.favorite !== favorite) await this.notion("pages/" + record.pageId, { properties: { "즐겨찾기": { checkbox: favorite } } }, "PATCH");
      return { schemaVersion: 4, preferences: this.preferences(await this.readRecords(), settings.preferences) };
    }
    const next = { ...current, ...body };
    if (!["draw", "sleep"].includes(next.mode) || typeof next.pokemonKey !== "string" || typeof next.backgroundId !== "string" || !Array.isArray(next.favoriteBackgrounds) || next.favoriteBackgrounds.length > 3e3 || next.favoriteBackgrounds.some((id) => typeof id !== "string" || id.length > 160)) throw new ServiceError("화면 설정을 확인해주세요.", 400);
    if (next.pokemonKey && !records.some((record) => captureKey(record) === next.pokemonKey)) throw new ServiceError("수집한 포켓몬만 선택할 수 있어요.", 400);
    const owned = new Set(records.map((record) => record.backgroundId).filter(Boolean));
    if (next.backgroundId && !owned.has(next.backgroundId) || next.favoriteBackgrounds.some((id) => !owned.has(id))) throw new ServiceError("수집한 배경만 선택할 수 있어요.", 400);
    next.favoriteBackgrounds = [...new Set(next.favoriteBackgrounds)];
    await this.notion("blocks/" + settings.blockId, { code: { rich_text: this.settingsText(next) } }, "PATCH");
    settings.preferences = next;
    return { schemaVersion: 4, preferences: this.preferences(records, next) };
  }
};
export {
  NotionCollection,
  backgroundFor,
  worker_default as default,
  koreaDay,
  normalizeSlug,
  pageId
};
