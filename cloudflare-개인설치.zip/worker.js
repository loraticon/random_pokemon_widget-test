// data/pokemon-final-with-forms.json
var pokemon_final_with_forms_default = [
  {
    dexId: 1,
    slug: "bulbasaur",
    en: "Bulbasaur",
    ko: "\uC774\uC0C1\uD574\uC528",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 2,
    slug: "ivysaur",
    en: "Ivysaur",
    ko: "\uC774\uC0C1\uD574\uD480",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 3,
    slug: "venusaur",
    en: "Venusaur",
    ko: "\uC774\uC0C1\uD574\uAF43",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 3,
    slug: "mega-venusaur",
    en: "Mega Venusaur",
    ko: "\uBA54\uAC00\uC774\uC0C1\uD574\uAF43",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 3,
    slug: "venusaur-gigantamax",
    en: "Venusaur (G)",
    ko: "\uC774\uC0C1\uD574\uAF43 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 4,
    slug: "charmander",
    en: "Charmander",
    ko: "\uD30C\uC774\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 5,
    slug: "charmeleon",
    en: "Charmeleon",
    ko: "\uB9AC\uC790\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 6,
    slug: "charizard",
    en: "Charizard",
    ko: "\uB9AC\uC790\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 6,
    slug: "charizard-gigantamax",
    en: "Charizard (G)",
    ko: "\uB9AC\uC790\uBABD (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 6,
    slug: "mega-charizard-x",
    en: "Mega Charizard X",
    ko: "\uBA54\uAC00\uB9AC\uC790\uBABDX",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 6,
    slug: "mega-charizard-y",
    en: "Mega Charizard Y",
    ko: "\uBA54\uAC00\uB9AC\uC790\uBABDY",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 7,
    slug: "squirtle",
    en: "Squirtle",
    ko: "\uAF2C\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 8,
    slug: "wartortle",
    en: "Wartortle",
    ko: "\uC5B4\uB2C8\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 9,
    slug: "blastoise",
    en: "Blastoise",
    ko: "\uAC70\uBD81\uC655",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 9,
    slug: "blastoise-gigantamax",
    en: "Blastoise (G)",
    ko: "\uAC70\uBD81\uC655 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 9,
    slug: "mega-blastoise",
    en: "Mega Blastoise",
    ko: "\uBA54\uAC00\uAC70\uBD81\uC655",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 10,
    slug: "caterpie",
    en: "Caterpie",
    ko: "\uCE90\uD130\uD53C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 11,
    slug: "metapod",
    en: "Metapod",
    ko: "\uB2E8\uB370\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 12,
    slug: "butterfree",
    en: "Butterfree",
    ko: "\uBC84\uD130\uD50C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 12,
    slug: "butterfree-gigantamax",
    en: "Butterfree (G)",
    ko: "\uBC84\uD130\uD50C (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 13,
    slug: "weedle",
    en: "Weedle",
    ko: "\uBFD4\uCDA9\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 14,
    slug: "kakuna",
    en: "Kakuna",
    ko: "\uB531\uCDA9\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 15,
    slug: "beedrill",
    en: "Beedrill",
    ko: "\uB3C5\uCE68\uBD95",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 15,
    slug: "mega-beedrill",
    en: "Mega Beedrill",
    ko: "\uBA54\uAC00\uB3C5\uCE68\uBD95",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 16,
    slug: "pidgey",
    en: "Pidgey",
    ko: "\uAD6C\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 17,
    slug: "pidgeotto",
    en: "Pidgeotto",
    ko: "\uD53C\uC8E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 18,
    slug: "pidgeot",
    en: "Pidgeot",
    ko: "\uD53C\uC8E4\uD22C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 18,
    slug: "mega-pidgeot",
    en: "Mega Pidgeot",
    ko: "\uBA54\uAC00\uD53C\uC8E4\uD22C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 19,
    slug: "rattata",
    en: "Rattata",
    ko: "\uAF2C\uB81B",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 19,
    slug: "rattata-alolan",
    en: "Rattata (Alolan)",
    ko: "\uAF2C\uB81B (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 20,
    slug: "raticate",
    en: "Raticate",
    ko: "\uB808\uD2B8\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 20,
    slug: "raticate-alolan",
    en: "Raticate (Alolan)",
    ko: "\uB808\uD2B8\uB77C (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 21,
    slug: "spearow",
    en: "Spearow",
    ko: "\uAE68\uBE44\uCC38",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 22,
    slug: "fearow",
    en: "Fearow",
    ko: "\uAE68\uBE44\uB4DC\uB9B4\uC870",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 23,
    slug: "ekans",
    en: "Ekans",
    ko: "\uC544\uBCF4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 24,
    slug: "arbok",
    en: "Arbok",
    ko: "\uC544\uBCF4\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 25,
    slug: "pikachu",
    en: "Pikachu",
    ko: "\uD53C\uCE74\uCE04",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 25,
    slug: "pikachu-gigantamax",
    en: "Pikachu (G)",
    ko: "\uD53C\uCE74\uCE04 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 26,
    slug: "raichu",
    en: "Raichu",
    ko: "\uB77C\uC774\uCE04",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 26,
    slug: "mega-raichu-x",
    en: "Mega Raichu X",
    ko: "\uBA54\uAC00\uB77C\uC774\uCE04X",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 26,
    slug: "mega-raichu-y",
    en: "Mega Raichu Y",
    ko: "\uBA54\uAC00\uB77C\uC774\uCE04Y",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 26,
    slug: "raichu-alolan",
    en: "Raichu (Alolan)",
    ko: "\uB77C\uC774\uCE04 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 27,
    slug: "sandshrew",
    en: "Sandshrew",
    ko: "\uBAA8\uB798\uB450\uC9C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 27,
    slug: "sandshrew-alolan",
    en: "Sandshrew (Alolan)",
    ko: "\uBAA8\uB798\uB450\uC9C0 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 28,
    slug: "sandslash",
    en: "Sandslash",
    ko: "\uACE0\uC9C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 28,
    slug: "sandslash-alolan",
    en: "Sandslash (Alolan)",
    ko: "\uACE0\uC9C0 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 29,
    slug: "nidoran-f",
    en: "Nidoran\u2640",
    ko: "\uB2C8\uB4DC\uB7F0\u2640",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 29,
    slug: "nidoran\u2640",
    en: "Nidoran\u2640",
    ko: "\uB2C8\uB4DC\uB7F0\u2640",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 30,
    slug: "nidorina",
    en: "Nidorina",
    ko: "\uB2C8\uB4DC\uB9AC\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 31,
    slug: "nidoqueen",
    en: "Nidoqueen",
    ko: "\uB2C8\uB4DC\uD038",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 32,
    slug: "nidoran-m",
    en: "Nidoran\u2642",
    ko: "\uB2C8\uB4DC\uB7F0\u2642",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 32,
    slug: "nidoran\u2642",
    en: "Nidoran\u2642",
    ko: "\uB2C8\uB4DC\uB7F0\u2642",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 33,
    slug: "nidorino",
    en: "Nidorino",
    ko: "\uB2C8\uB4DC\uB9AC\uB178",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 34,
    slug: "nidoking",
    en: "Nidoking",
    ko: "\uB2C8\uB4DC\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 35,
    slug: "clefairy",
    en: "Clefairy",
    ko: "\uC090\uC090",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 36,
    slug: "clefable",
    en: "Clefable",
    ko: "\uD53D\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 36,
    slug: "mega-clefable",
    en: "Mega Clefable",
    ko: "\uBA54\uAC00\uD53D\uC2DC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 37,
    slug: "vulpix",
    en: "Vulpix",
    ko: "\uC2DD\uC2A4\uD14C\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 37,
    slug: "vulpix-alolan",
    en: "Vulpix (Alolan)",
    ko: "\uC2DD\uC2A4\uD14C\uC77C (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 38,
    slug: "ninetales",
    en: "Ninetales",
    ko: "\uB098\uC778\uD14C\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 38,
    slug: "ninetales-alolan",
    en: "Ninetales (Alolan)",
    ko: "\uB098\uC778\uD14C\uC77C (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 39,
    slug: "jigglypuff",
    en: "Jigglypuff",
    ko: "\uD478\uB9B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 40,
    slug: "wigglytuff",
    en: "Wigglytuff",
    ko: "\uD478\uD06C\uB9B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 41,
    slug: "zubat",
    en: "Zubat",
    ko: "\uC8FC\uBC43",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 42,
    slug: "golbat",
    en: "Golbat",
    ko: "\uACE8\uBC43",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 43,
    slug: "oddish",
    en: "Oddish",
    ko: "\uB69C\uBC85\uCD78",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 44,
    slug: "gloom",
    en: "Gloom",
    ko: "\uB0C4\uC0C8\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 45,
    slug: "vileplume",
    en: "Vileplume",
    ko: "\uB77C\uD50C\uB808\uC2DC\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 46,
    slug: "paras",
    en: "Paras",
    ko: "\uD30C\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 47,
    slug: "parasect",
    en: "Parasect",
    ko: "\uD30C\uB77C\uC139\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 48,
    slug: "venonat",
    en: "Venonat",
    ko: "\uCF58\uD321",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 49,
    slug: "venomoth",
    en: "Venomoth",
    ko: "\uB3C4\uB098\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 50,
    slug: "diglett",
    en: "Diglett",
    ko: "\uB514\uADF8\uB2E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 50,
    slug: "diglett-alolan",
    en: "Diglett (Alolan)",
    ko: "\uB514\uADF8\uB2E4 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 51,
    slug: "dugtrio",
    en: "Dugtrio",
    ko: "\uB2E5\uD2B8\uB9AC\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 51,
    slug: "dugtrio-alolan",
    en: "Dugtrio (Alolan)",
    ko: "\uB2E5\uD2B8\uB9AC\uC624 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 52,
    slug: "meowth",
    en: "Meowth",
    ko: "\uB098\uC639",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 52,
    slug: "meowth-alolan",
    en: "Meowth (Alolan)",
    ko: "\uB098\uC639 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 52,
    slug: "meowth-galarian",
    en: "Meowth (Galarian)",
    ko: "\uB098\uC639 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 52,
    slug: "meowth-gigantamax",
    en: "Meowth (G)",
    ko: "\uB098\uC639 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 53,
    slug: "persian",
    en: "Persian",
    ko: "\uD398\uB974\uC2DC\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 53,
    slug: "persian-alolan",
    en: "Persian (Alolan)",
    ko: "\uD398\uB974\uC2DC\uC628 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 54,
    slug: "psyduck",
    en: "Psyduck",
    ko: "\uACE0\uB77C\uD30C\uB355",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 55,
    slug: "golduck",
    en: "Golduck",
    ko: "\uACE8\uB355",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 56,
    slug: "mankey",
    en: "Mankey",
    ko: "\uB9DD\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 57,
    slug: "primeape",
    en: "Primeape",
    ko: "\uC131\uC6D0\uC22D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 58,
    slug: "growlithe",
    en: "Growlithe",
    ko: "\uAC00\uB514",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 58,
    slug: "growlithe-hisuian",
    en: "Growlithe (Hisuian)",
    ko: "\uAC00\uB514 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 59,
    slug: "arcanine",
    en: "Arcanine",
    ko: "\uC708\uB514",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 59,
    slug: "arcanine-hisuian",
    en: "Arcanine (Hisuian)",
    ko: "\uC708\uB514 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 60,
    slug: "poliwag",
    en: "Poliwag",
    ko: "\uBC1C\uCC59\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 61,
    slug: "poliwhirl",
    en: "Poliwhirl",
    ko: "\uC288\uB959\uCC59\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 62,
    slug: "poliwrath",
    en: "Poliwrath",
    ko: "\uAC15\uCC59\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 63,
    slug: "abra",
    en: "Abra",
    ko: "\uCE90\uC774\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 64,
    slug: "kadabra",
    en: "Kadabra",
    ko: "\uC724\uAC94\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 65,
    slug: "alakazam",
    en: "Alakazam",
    ko: "\uD6C4\uB518",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 65,
    slug: "mega-alakazam",
    en: "Mega Alakazam",
    ko: "\uBA54\uAC00\uD6C4\uB518",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 66,
    slug: "machop",
    en: "Machop",
    ko: "\uC54C\uD1B5\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 67,
    slug: "machoke",
    en: "Machoke",
    ko: "\uADFC\uC721\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 68,
    slug: "machamp",
    en: "Machamp",
    ko: "\uAD34\uB825\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 68,
    slug: "machamp-gigantamax",
    en: "Machamp (G)",
    ko: "\uAD34\uB825\uBAAC (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 69,
    slug: "bellsprout",
    en: "Bellsprout",
    ko: "\uBAA8\uB2E4\uD53C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 70,
    slug: "weepinbell",
    en: "Weepinbell",
    ko: "\uC6B0\uCE20\uB3D9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 71,
    slug: "victreebel",
    en: "Victreebel",
    ko: "\uC6B0\uCE20\uBCF4\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 71,
    slug: "mega-victreebel",
    en: "Mega Victreebel",
    ko: "\uBA54\uAC00\uC6B0\uCE20\uBCF4\uD2B8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 72,
    slug: "tentacool",
    en: "Tentacool",
    ko: "\uC655\uB208\uD574",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 73,
    slug: "tentacruel",
    en: "Tentacruel",
    ko: "\uB3C5\uD30C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 74,
    slug: "geodude",
    en: "Geodude",
    ko: "\uAF2C\uB9C8\uB3CC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 74,
    slug: "geodude-alolan",
    en: "Geodude (Alolan)",
    ko: "\uAF2C\uB9C8\uB3CC (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 75,
    slug: "graveler",
    en: "Graveler",
    ko: "\uB370\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 75,
    slug: "graveler-alolan",
    en: "Graveler (Alolan)",
    ko: "\uB370\uAD6C\uB9AC (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 76,
    slug: "golem",
    en: "Golem",
    ko: "\uB531\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 76,
    slug: "golem-alolan",
    en: "Golem (Alolan)",
    ko: "\uB531\uAD6C\uB9AC (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 77,
    slug: "ponyta",
    en: "Ponyta",
    ko: "\uD3EC\uB2C8\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 77,
    slug: "ponyta-galarian",
    en: "Ponyta (Galarian)",
    ko: "\uD3EC\uB2C8\uD0C0 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 78,
    slug: "rapidash",
    en: "Rapidash",
    ko: "\uB0A0\uC329\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 78,
    slug: "rapidash-galarian",
    en: "Rapidash (Galarian)",
    ko: "\uB0A0\uC329\uB9C8 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 79,
    slug: "slowpoke",
    en: "Slowpoke",
    ko: "\uC57C\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 79,
    slug: "slowpoke-galarian",
    en: "Slowpoke (Galarian)",
    ko: "\uC57C\uB3C8 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 80,
    slug: "slowbro",
    en: "Slowbro",
    ko: "\uC57C\uB3C4\uB780",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 80,
    slug: "mega-slowbro",
    en: "Mega Slowbro",
    ko: "\uBA54\uAC00\uC57C\uB3C4\uB780",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 80,
    slug: "slowbro-galarian",
    en: "Slowbro (Galarian)",
    ko: "\uC57C\uB3C4\uB780 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 81,
    slug: "magnemite",
    en: "Magnemite",
    ko: "\uCF54\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 82,
    slug: "magneton",
    en: "Magneton",
    ko: "\uB808\uC5B4\uCF54\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 83,
    slug: "farfetchd",
    en: "Farfetch'd",
    ko: "\uD30C\uC624\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 83,
    slug: "farfetch\u2019d",
    en: "Farfetch\u2019d",
    ko: "\uD30C\uC624\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 83,
    slug: "farfetchd-galarian",
    en: "Farfetch'd (Galarian)",
    ko: "\uD30C\uC624\uB9AC (\uAC00\uB77C\uB974)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 84,
    slug: "doduo",
    en: "Doduo",
    ko: "\uB450\uB450",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 85,
    slug: "dodrio",
    en: "Dodrio",
    ko: "\uB450\uD2B8\uB9AC\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 86,
    slug: "seel",
    en: "Seel",
    ko: "\uC96C\uC96C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 87,
    slug: "dewgong",
    en: "Dewgong",
    ko: "\uC96C\uB808\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 88,
    slug: "grimer",
    en: "Grimer",
    ko: "\uC9C8\uD37D\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 88,
    slug: "grimer-alolan",
    en: "Grimer (Alolan)",
    ko: "\uC9C8\uD37D\uC774 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 89,
    slug: "muk",
    en: "Muk",
    ko: "\uC9C8\uBED0\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 89,
    slug: "muk-alolan",
    en: "Muk (Alolan)",
    ko: "\uC9C8\uBED0\uAE30 (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 90,
    slug: "shellder",
    en: "Shellder",
    ko: "\uC140\uB7EC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 91,
    slug: "cloyster",
    en: "Cloyster",
    ko: "\uD30C\uB974\uC140",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 92,
    slug: "gastly",
    en: "Gastly",
    ko: "\uACE0\uC624\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 93,
    slug: "haunter",
    en: "Haunter",
    ko: "\uACE0\uC6B0\uC2A4\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 94,
    slug: "gengar",
    en: "Gengar",
    ko: "\uD32C\uD140",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 94,
    slug: "gengar-gigantamax",
    en: "Gengar (G)",
    ko: "\uD32C\uD140 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 94,
    slug: "mega-gengar",
    en: "Mega Gengar",
    ko: "\uBA54\uAC00\uD32C\uD140",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 95,
    slug: "onix",
    en: "Onix",
    ko: "\uB871\uC2A4\uD1A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 96,
    slug: "drowzee",
    en: "Drowzee",
    ko: "\uC2AC\uB9AC\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 97,
    slug: "hypno",
    en: "Hypno",
    ko: "\uC2AC\uB9AC\uD37C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 98,
    slug: "krabby",
    en: "Krabby",
    ko: "\uD06C\uB7A9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 99,
    slug: "kingler",
    en: "Kingler",
    ko: "\uD0B9\uD06C\uB7A9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 99,
    slug: "kingler-gigantamax",
    en: "Kingler (G)",
    ko: "\uD0B9\uD06C\uB7A9 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 100,
    slug: "voltorb",
    en: "Voltorb",
    ko: "\uCC0C\uB9AC\uB9AC\uACF5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 100,
    slug: "voltorb-hisuian",
    en: "Voltorb (Hisuian)",
    ko: "\uCC0C\uB9AC\uB9AC\uACF5 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 101,
    slug: "electrode",
    en: "Electrode",
    ko: "\uBD90\uBCFC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 101,
    slug: "electrode-hisuian",
    en: "Electrode (Hisuian)",
    ko: "\uBD90\uBCFC (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 102,
    slug: "exeggcute",
    en: "Exeggcute",
    ko: "\uC544\uB77C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 103,
    slug: "exeggutor",
    en: "Exeggutor",
    ko: "\uB098\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 103,
    slug: "exeggutor-alolan",
    en: "Exeggutor (Alolan)",
    ko: "\uB098\uC2DC (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 104,
    slug: "cubone",
    en: "Cubone",
    ko: "\uD0D5\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 105,
    slug: "marowak",
    en: "Marowak",
    ko: "\uD145\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 105,
    slug: "marowak-alolan",
    en: "Marowak (Alolan)",
    ko: "\uD145\uAD6C\uB9AC (\uC54C\uB85C\uB77C)",
    category: "alola",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 106,
    slug: "hitmonlee",
    en: "Hitmonlee",
    ko: "\uC2DC\uB77C\uC18C\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 107,
    slug: "hitmonchan",
    en: "Hitmonchan",
    ko: "\uD64D\uC218\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 108,
    slug: "lickitung",
    en: "Lickitung",
    ko: "\uB0B4\uB8E8\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 109,
    slug: "koffing",
    en: "Koffing",
    ko: "\uB610\uAC00\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 110,
    slug: "weezing",
    en: "Weezing",
    ko: "\uB610\uB3C4\uAC00\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 110,
    slug: "weezing-galarian",
    en: "Weezing (Galarian)",
    ko: "\uB610\uB3C4\uAC00\uC2A4 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 111,
    slug: "rhyhorn",
    en: "Rhyhorn",
    ko: "\uBFD4\uCE74\uB178",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 112,
    slug: "rhydon",
    en: "Rhydon",
    ko: "\uCF54\uBFCC\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 113,
    slug: "chansey",
    en: "Chansey",
    ko: "\uB7ED\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 114,
    slug: "tangela",
    en: "Tangela",
    ko: "\uB369\uCFE0\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 115,
    slug: "kangaskhan",
    en: "Kangaskhan",
    ko: "\uCEA5\uCE74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 115,
    slug: "mega-kangaskhan",
    en: "Mega Kangaskhan",
    ko: "\uBA54\uAC00\uCEA5\uCE74",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 116,
    slug: "horsea",
    en: "Horsea",
    ko: "\uC3D8\uB4DC\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 117,
    slug: "seadra",
    en: "Seadra",
    ko: "\uC2DC\uB4DC\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 118,
    slug: "goldeen",
    en: "Goldeen",
    ko: "\uCF58\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 119,
    slug: "seaking",
    en: "Seaking",
    ko: "\uC655\uCF58\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 120,
    slug: "staryu",
    en: "Staryu",
    ko: "\uBCC4\uAC00\uC0AC\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 121,
    slug: "starmie",
    en: "Starmie",
    ko: "\uC544\uCFE0\uC2A4\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 121,
    slug: "mega-starmie",
    en: "Mega Starmie",
    ko: "\uBA54\uAC00\uC544\uCFE0\uC2A4\uD0C0",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 122,
    slug: "mr.-mime",
    en: "Mr. Mime",
    ko: "\uB9C8\uC784\uB9E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 122,
    slug: "mr-mime",
    en: "Mr. Mime",
    ko: "\uB9C8\uC784\uB9E8",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 122,
    slug: "mr-mime-galarian",
    en: "Mr. Mime (Galarian)",
    ko: "\uB9C8\uC784\uB9E8 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 123,
    slug: "scyther",
    en: "Scyther",
    ko: "\uC2A4\uB77C\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 124,
    slug: "jynx",
    en: "Jynx",
    ko: "\uB8E8\uC8FC\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 125,
    slug: "electabuzz",
    en: "Electabuzz",
    ko: "\uC5D0\uB808\uBE0C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 126,
    slug: "magmar",
    en: "Magmar",
    ko: "\uB9C8\uADF8\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 127,
    slug: "pinsir",
    en: "Pinsir",
    ko: "\uC058\uC0AC\uC774\uC800",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 127,
    slug: "mega-pinsir",
    en: "Mega Pinsir",
    ko: "\uBA54\uAC00\uC058\uC0AC\uC774\uC800",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 128,
    slug: "tauros",
    en: "Tauros",
    ko: "\uCF04\uD0C0\uB85C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 128,
    slug: "tauros-aqua-breed",
    en: "Tauros (Aqua)",
    ko: "\uCF04\uD0C0\uB85C\uC2A4(\uC544\uCFE0\uC544\uC885)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 128,
    slug: "tauros-blaze-breed",
    en: "Tauros (Blaze)",
    ko: "\uCF04\uD0C0\uB85C\uC2A4(\uBE14\uB808\uC774\uC988\uC885)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 128,
    slug: "tauros-combat-breed",
    en: "Tauros (Combat)",
    ko: "\uCF04\uD0C0\uB85C\uC2A4(\uCEF4\uBC43\uC885)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 129,
    slug: "magikarp",
    en: "Magikarp",
    ko: "\uC789\uC5B4\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 130,
    slug: "gyarados",
    en: "Gyarados",
    ko: "\uAC38\uB77C\uB3C4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 130,
    slug: "mega-gyarados",
    en: "Mega Gyarados",
    ko: "\uBA54\uAC00\uAC38\uB77C\uB3C4\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 131,
    slug: "lapras",
    en: "Lapras",
    ko: "\uB77C\uD504\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 131,
    slug: "lapras-gigantamax",
    en: "Lapras (G)",
    ko: "\uB77C\uD504\uB77C\uC2A4 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 132,
    slug: "ditto",
    en: "Ditto",
    ko: "\uBA54\uD0C0\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 133,
    slug: "eevee",
    en: "Eevee",
    ko: "\uC774\uBE0C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 133,
    slug: "eevee-gigantamax",
    en: "Eevee (G)",
    ko: "\uC774\uBE0C\uC774 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 134,
    slug: "vaporeon",
    en: "Vaporeon",
    ko: "\uC0E4\uBBF8\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 135,
    slug: "jolteon",
    en: "Jolteon",
    ko: "\uC96C\uD53C\uC36C\uB354",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 136,
    slug: "flareon",
    en: "Flareon",
    ko: "\uBD80\uC2A4\uD130",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 137,
    slug: "porygon",
    en: "Porygon",
    ko: "\uD3F4\uB9AC\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 138,
    slug: "omanyte",
    en: "Omanyte",
    ko: "\uC554\uB098\uC774\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 139,
    slug: "omastar",
    en: "Omastar",
    ko: "\uC554\uC2A4\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 140,
    slug: "kabuto",
    en: "Kabuto",
    ko: "\uD22C\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 141,
    slug: "kabutops",
    en: "Kabutops",
    ko: "\uD22C\uAD6C\uD478\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 142,
    slug: "aerodactyl",
    en: "Aerodactyl",
    ko: "\uD504\uD14C\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 142,
    slug: "mega-aerodactyl",
    en: "Mega Aerodactyl",
    ko: "\uBA54\uAC00\uD504\uD14C\uB77C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 143,
    slug: "snorlax",
    en: "Snorlax",
    ko: "\uC7A0\uB9CC\uBCF4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 143,
    slug: "snorlax-gigantamax",
    en: "Snorlax (G)",
    ko: "\uC7A0\uB9CC\uBCF4 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 144,
    slug: "articuno",
    en: "Articuno",
    ko: "\uD504\uB9AC\uC838",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 144,
    slug: "articuno-galarian",
    en: "Articuno (Galarian)",
    ko: "\uD504\uB9AC\uC838 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 145,
    slug: "zapdos",
    en: "Zapdos",
    ko: "\uC36C\uB354",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 145,
    slug: "zapdos-galarian",
    en: "Zapdos (Galarian)",
    ko: "\uC36C\uB354 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 146,
    slug: "moltres",
    en: "Moltres",
    ko: "\uD30C\uC774\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 146,
    slug: "moltres-galarian",
    en: "Moltres (Galarian)",
    ko: "\uD30C\uC774\uC5B4 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 147,
    slug: "dratini",
    en: "Dratini",
    ko: "\uBBF8\uB1FD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 148,
    slug: "dragonair",
    en: "Dragonair",
    ko: "\uC2E0\uB1FD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 149,
    slug: "dragonite",
    en: "Dragonite",
    ko: "\uB9DD\uB098\uB1FD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 149,
    slug: "mega-dragonite",
    en: "Mega Dragonite",
    ko: "\uBA54\uAC00\uB9DD\uB098\uB1FD",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 150,
    slug: "mewtwo",
    en: "Mewtwo",
    ko: "\uBBA4\uCE20",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 150,
    slug: "mega-mewtwo-x",
    en: "Mega Mewtwo X",
    ko: "\uBA54\uAC00\uBBA4\uCE20X",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 150,
    slug: "mega-mewtwo-y",
    en: "Mega Mewtwo Y",
    ko: "\uBA54\uAC00\uBBA4\uCE20Y",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 151,
    slug: "mew",
    en: "Mew",
    ko: "\uBBA4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 152,
    slug: "chikorita",
    en: "Chikorita",
    ko: "\uCE58\uCF54\uB9AC\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 153,
    slug: "bayleef",
    en: "Bayleef",
    ko: "\uBCA0\uC774\uB9AC\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 154,
    slug: "meganium",
    en: "Meganium",
    ko: "\uBA54\uAC00\uB2C8\uC6C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 154,
    slug: "mega-meganium",
    en: "Mega Meganium",
    ko: "\uBA54\uAC00\uBA54\uAC00\uB2C8\uC6C0",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 155,
    slug: "cyndaquil",
    en: "Cyndaquil",
    ko: "\uBE0C\uCF00\uC778",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 156,
    slug: "quilava",
    en: "Quilava",
    ko: "\uB9C8\uADF8\uCF00\uC778",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 157,
    slug: "typhlosion",
    en: "Typhlosion",
    ko: "\uBE14\uB808\uC774\uBC94",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 157,
    slug: "typhlosion-hisuian",
    en: "Typhlosion (Hisuian)",
    ko: "\uBE14\uB808\uC774\uBC94 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 158,
    slug: "totodile",
    en: "Totodile",
    ko: "\uB9AC\uC544\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 159,
    slug: "croconaw",
    en: "Croconaw",
    ko: "\uC5D8\uB9AC\uAC8C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 160,
    slug: "feraligatr",
    en: "Feraligatr",
    ko: "\uC7A5\uD06C\uB85C\uB2E4\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 160,
    slug: "mega-feraligatr",
    en: "Mega Feraligatr",
    ko: "\uBA54\uAC00\uC7A5\uD06C\uB85C\uB2E4\uC77C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 161,
    slug: "sentret",
    en: "Sentret",
    ko: "\uAF2C\uB9AC\uC120",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 162,
    slug: "furret",
    en: "Furret",
    ko: "\uB2E4\uAF2C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 163,
    slug: "hoothoot",
    en: "Hoothoot",
    ko: "\uBD80\uC6B0\uBD80",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 164,
    slug: "noctowl",
    en: "Noctowl",
    ko: "\uC57C\uBD80\uC5C9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 165,
    slug: "ledyba",
    en: "Ledyba",
    ko: "\uB808\uB514\uBC14",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 166,
    slug: "ledian",
    en: "Ledian",
    ko: "\uB808\uB514\uC548",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 167,
    slug: "spinarak",
    en: "Spinarak",
    ko: "\uD398\uC774\uAC80",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 168,
    slug: "ariados",
    en: "Ariados",
    ko: "\uC544\uB9AC\uC544\uB3C4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 169,
    slug: "crobat",
    en: "Crobat",
    ko: "\uD06C\uB85C\uBC43",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 170,
    slug: "chinchou",
    en: "Chinchou",
    ko: "\uCD08\uB77C\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 171,
    slug: "lanturn",
    en: "Lanturn",
    ko: "\uB79C\uD134",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 172,
    slug: "pichu",
    en: "Pichu",
    ko: "\uD53C\uCE04",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 173,
    slug: "cleffa",
    en: "Cleffa",
    ko: "\uC090",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 174,
    slug: "igglybuff",
    en: "Igglybuff",
    ko: "\uD478\uD478\uB9B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 175,
    slug: "togepi",
    en: "Togepi",
    ko: "\uD1A0\uAC8C\uD53C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 176,
    slug: "togetic",
    en: "Togetic",
    ko: "\uD1A0\uAC8C\uD2F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 177,
    slug: "natu",
    en: "Natu",
    ko: "\uB124\uC774\uD2F0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 178,
    slug: "xatu",
    en: "Xatu",
    ko: "\uB124\uC774\uD2F0\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 179,
    slug: "mareep",
    en: "Mareep",
    ko: "\uBA54\uB9AC\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 180,
    slug: "flaaffy",
    en: "Flaaffy",
    ko: "\uBCF4\uC1A1\uC1A1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 181,
    slug: "ampharos",
    en: "Ampharos",
    ko: "\uC804\uB8E1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 181,
    slug: "mega-ampharos",
    en: "Mega Ampharos",
    ko: "\uBA54\uAC00\uC804\uB8E1",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 182,
    slug: "bellossom",
    en: "Bellossom",
    ko: "\uC544\uB974\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 183,
    slug: "marill",
    en: "Marill",
    ko: "\uB9C8\uB9B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 184,
    slug: "azumarill",
    en: "Azumarill",
    ko: "\uB9C8\uB9B4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 185,
    slug: "sudowoodo",
    en: "Sudowoodo",
    ko: "\uAF2C\uC9C0\uBAA8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 186,
    slug: "politoed",
    en: "Politoed",
    ko: "\uC655\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 187,
    slug: "hoppip",
    en: "Hoppip",
    ko: "\uD1B5\uD1B5\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 188,
    slug: "skiploom",
    en: "Skiploom",
    ko: "\uB450\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 189,
    slug: "jumpluff",
    en: "Jumpluff",
    ko: "\uC19C\uC19C\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 190,
    slug: "aipom",
    en: "Aipom",
    ko: "\uC5D0\uC774\uD31C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 191,
    slug: "sunkern",
    en: "Sunkern",
    ko: "\uD574\uB108\uCE20",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 192,
    slug: "sunflora",
    en: "Sunflora",
    ko: "\uD574\uB8E8\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 193,
    slug: "yanma",
    en: "Yanma",
    ko: "\uC655\uC790\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 194,
    slug: "wooper",
    en: "Wooper",
    ko: "\uC6B0\uD30C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 194,
    slug: "wooper-paldean",
    en: "Wooper (Paldean)",
    ko: "\uC6B0\uD30C (\uD314\uB370\uC544)",
    category: "paldea",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 195,
    slug: "quagsire",
    en: "Quagsire",
    ko: "\uB204\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 196,
    slug: "espeon",
    en: "Espeon",
    ko: "\uC5D0\uBE0C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 197,
    slug: "umbreon",
    en: "Umbreon",
    ko: "\uBE14\uB798\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 198,
    slug: "murkrow",
    en: "Murkrow",
    ko: "\uB2C8\uB85C\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 199,
    slug: "slowking",
    en: "Slowking",
    ko: "\uC57C\uB3C4\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 199,
    slug: "slowking-galarian",
    en: "Slowking (Galarian)",
    ko: "\uC57C\uB3C4\uD0B9 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 200,
    slug: "misdreavus",
    en: "Misdreavus",
    ko: "\uBB34\uC6B0\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 201,
    slug: "unown",
    en: "Unown",
    ko: "\uC548\uB18D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 202,
    slug: "wobbuffet",
    en: "Wobbuffet",
    ko: "\uB9C8\uC790\uC6A9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 203,
    slug: "girafarig",
    en: "Girafarig",
    ko: "\uD0A4\uB9C1\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 204,
    slug: "pineco",
    en: "Pineco",
    ko: "\uD53C\uCF58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 205,
    slug: "forretress",
    en: "Forretress",
    ko: "\uC3D8\uCF58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 206,
    slug: "dunsparce",
    en: "Dunsparce",
    ko: "\uB178\uACE0\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 207,
    slug: "gligar",
    en: "Gligar",
    ko: "\uAE00\uB77C\uC774\uAC70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 208,
    slug: "steelix",
    en: "Steelix",
    ko: "\uAC15\uCCA0\uD1A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 208,
    slug: "mega-steelix",
    en: "Mega Steelix",
    ko: "\uBA54\uAC00\uAC15\uCCA0\uD1A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 209,
    slug: "snubbull",
    en: "Snubbull",
    ko: "\uBE14\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 210,
    slug: "granbull",
    en: "Granbull",
    ko: "\uADF8\uB791\uBE14\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 211,
    slug: "qwilfish",
    en: "Qwilfish",
    ko: "\uCE68\uBC14\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 211,
    slug: "qwilfish-hisuian",
    en: "Qwilfish (Hisuian)",
    ko: "\uCE68\uBC14\uB8E8 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 212,
    slug: "scizor",
    en: "Scizor",
    ko: "\uD56B\uC0BC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 212,
    slug: "mega-scizor",
    en: "Mega Scizor",
    ko: "\uBA54\uAC00\uD56B\uC0BC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 213,
    slug: "shuckle",
    en: "Shuckle",
    ko: "\uB2E8\uB2E8\uC9C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 214,
    slug: "heracross",
    en: "Heracross",
    ko: "\uD5E4\uB77C\uD06C\uB85C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 214,
    slug: "mega-heracross",
    en: "Mega Heracross",
    ko: "\uBA54\uAC00\uD5E4\uB77C\uD06C\uB85C\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 215,
    slug: "sneasel",
    en: "Sneasel",
    ko: "\uD3EC\uD478\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 215,
    slug: "sneasel-hisuian",
    en: "Sneasel (Hisuian)",
    ko: "\uD3EC\uD478\uB2C8 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 216,
    slug: "teddiursa",
    en: "Teddiursa",
    ko: "\uAE5C\uC9C0\uACF0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 217,
    slug: "ursaring",
    en: "Ursaring",
    ko: "\uB9C1\uACF0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 218,
    slug: "slugma",
    en: "Slugma",
    ko: "\uB9C8\uADF8\uB9C8\uADF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 219,
    slug: "magcargo",
    en: "Magcargo",
    ko: "\uB9C8\uADF8\uCE74\uB974\uACE0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 220,
    slug: "swinub",
    en: "Swinub",
    ko: "\uAFB8\uAFB8\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 221,
    slug: "piloswine",
    en: "Piloswine",
    ko: "\uBA54\uAFB8\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 222,
    slug: "corsola",
    en: "Corsola",
    ko: "\uCF54\uC0B0\uD638",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 222,
    slug: "corsola-galarian",
    en: "Corsola (Galarian)",
    ko: "\uCF54\uC0B0\uD638 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 223,
    slug: "remoraid",
    en: "Remoraid",
    ko: "\uCD1D\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 224,
    slug: "octillery",
    en: "Octillery",
    ko: "\uB300\uD3EC\uBB34\uB178",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 225,
    slug: "delibird",
    en: "Delibird",
    ko: "\uB51C\uB9AC\uBC84\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 226,
    slug: "mantine",
    en: "Mantine",
    ko: "\uB9CC\uD0C0\uC778",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 227,
    slug: "skarmory",
    en: "Skarmory",
    ko: "\uBB34\uC7A5\uC870",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 227,
    slug: "mega-skarmory",
    en: "Mega Skarmory",
    ko: "\uBA54\uAC00\uBB34\uC7A5\uC870",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 228,
    slug: "houndour",
    en: "Houndour",
    ko: "\uB378\uBE4C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 229,
    slug: "houndoom",
    en: "Houndoom",
    ko: "\uD5EC\uAC00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 229,
    slug: "mega-houndoom",
    en: "Mega Houndoom",
    ko: "\uBA54\uAC00\uD5EC\uAC00",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 230,
    slug: "kingdra",
    en: "Kingdra",
    ko: "\uD0B9\uB4DC\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 231,
    slug: "phanpy",
    en: "Phanpy",
    ko: "\uCF54\uCF54\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 232,
    slug: "donphan",
    en: "Donphan",
    ko: "\uCF54\uB9AC\uAC11",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 233,
    slug: "porygon2",
    en: "Porygon2",
    ko: "\uD3F4\uB9AC\uACE42",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 234,
    slug: "stantler",
    en: "Stantler",
    ko: "\uB178\uB77C\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 235,
    slug: "smeargle",
    en: "Smeargle",
    ko: "\uB8E8\uBE0C\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 236,
    slug: "tyrogue",
    en: "Tyrogue",
    ko: "\uBC30\uB8E8\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 237,
    slug: "hitmontop",
    en: "Hitmontop",
    ko: "\uCE74\uD3EC\uC5D0\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 238,
    slug: "smoochum",
    en: "Smoochum",
    ko: "\uBF40\uBF40\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 239,
    slug: "elekid",
    en: "Elekid",
    ko: "\uC5D0\uB808\uD0A4\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 240,
    slug: "magby",
    en: "Magby",
    ko: "\uB9C8\uADF8\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 241,
    slug: "miltank",
    en: "Miltank",
    ko: "\uBC00\uD0F1\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 242,
    slug: "blissey",
    en: "Blissey",
    ko: "\uD574\uD53C\uB108\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 243,
    slug: "raikou",
    en: "Raikou",
    ko: "\uB77C\uC774\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 244,
    slug: "entei",
    en: "Entei",
    ko: "\uC564\uD14C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 245,
    slug: "suicune",
    en: "Suicune",
    ko: "\uC2A4\uC774\uCFE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 246,
    slug: "larvitar",
    en: "Larvitar",
    ko: "\uC560\uBC84\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 247,
    slug: "pupitar",
    en: "Pupitar",
    ko: "\uB370\uAE30\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 248,
    slug: "tyranitar",
    en: "Tyranitar",
    ko: "\uB9C8\uAE30\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 248,
    slug: "mega-tyranitar",
    en: "Mega Tyranitar",
    ko: "\uBA54\uAC00\uB9C8\uAE30\uB77C\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 249,
    slug: "lugia",
    en: "Lugia",
    ko: "\uB8E8\uAE30\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 250,
    slug: "ho-oh",
    en: "Ho-Oh",
    ko: "\uCE60\uC0C9\uC870",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 251,
    slug: "celebi",
    en: "Celebi",
    ko: "\uC138\uB808\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 252,
    slug: "treecko",
    en: "Treecko",
    ko: "\uB098\uBB34\uC9C0\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 253,
    slug: "grovyle",
    en: "Grovyle",
    ko: "\uB098\uBB34\uB3CC\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 254,
    slug: "sceptile",
    en: "Sceptile",
    ko: "\uB098\uBB34\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 254,
    slug: "mega-sceptile",
    en: "Mega Sceptile",
    ko: "\uBA54\uAC00\uB098\uBB34\uD0B9",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 255,
    slug: "torchic",
    en: "Torchic",
    ko: "\uC544\uCC28\uBAA8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 256,
    slug: "combusken",
    en: "Combusken",
    ko: "\uC601\uCE58\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 257,
    slug: "blaziken",
    en: "Blaziken",
    ko: "\uBC88\uCE58\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 257,
    slug: "mega-blaziken",
    en: "Mega Blaziken",
    ko: "\uBA54\uAC00\uBC88\uCE58\uCF54",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 258,
    slug: "mudkip",
    en: "Mudkip",
    ko: "\uBB3C\uC9F1\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 259,
    slug: "marshtomp",
    en: "Marshtomp",
    ko: "\uB2AA\uC9F1\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 260,
    slug: "swampert",
    en: "Swampert",
    ko: "\uB300\uC9F1\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 260,
    slug: "mega-swampert",
    en: "Mega Swampert",
    ko: "\uBA54\uAC00\uB300\uC9F1\uC774",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 261,
    slug: "poochyena",
    en: "Poochyena",
    ko: "\uD3EC\uCC60\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 262,
    slug: "mightyena",
    en: "Mightyena",
    ko: "\uADF8\uB77C\uC5D0\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 263,
    slug: "zigzagoon",
    en: "Zigzagoon",
    ko: "\uC9C0\uADF8\uC81C\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 263,
    slug: "zigzagoon-galarian",
    en: "Zigzagoon (Galarian)",
    ko: "\uC9C0\uADF8\uC81C\uAD6C\uB9AC (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 264,
    slug: "linoone",
    en: "Linoone",
    ko: "\uC9C1\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 264,
    slug: "linoone-galarian",
    en: "Linoone (Galarian)",
    ko: "\uC9C1\uAD6C\uB9AC (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 265,
    slug: "wurmple",
    en: "Wurmple",
    ko: "\uAC1C\uBB34\uC18C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 266,
    slug: "silcoon",
    en: "Silcoon",
    ko: "\uC2E4\uCFE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 267,
    slug: "beautifly",
    en: "Beautifly",
    ko: "\uBDF0\uD2F0\uD50C\uB77C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 268,
    slug: "cascoon",
    en: "Cascoon",
    ko: "\uCE74\uC2A4\uCFE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 269,
    slug: "dustox",
    en: "Dustox",
    ko: "\uB3C5\uCF00\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 270,
    slug: "lotad",
    en: "Lotad",
    ko: "\uC5F0\uAF43\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 271,
    slug: "lombre",
    en: "Lombre",
    ko: "\uB85C\uD1A0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 272,
    slug: "ludicolo",
    en: "Ludicolo",
    ko: "\uB85C\uD30C\uD30C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 273,
    slug: "seedot",
    en: "Seedot",
    ko: "\uB3C4\uD1A0\uB9C1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 274,
    slug: "nuzleaf",
    en: "Nuzleaf",
    ko: "\uC78E\uC0C8\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 275,
    slug: "shiftry",
    en: "Shiftry",
    ko: "\uB2E4\uD0F1\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 276,
    slug: "taillow",
    en: "Taillow",
    ko: "\uD14C\uC77C\uB85C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 277,
    slug: "swellow",
    en: "Swellow",
    ko: "\uC2A4\uC648\uB85C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 278,
    slug: "wingull",
    en: "Wingull",
    ko: "\uAC08\uBAA8\uB9E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 279,
    slug: "pelipper",
    en: "Pelipper",
    ko: "\uD328\uB9AC\uD37C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 280,
    slug: "ralts",
    en: "Ralts",
    ko: "\uB784\uD1A0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 281,
    slug: "kirlia",
    en: "Kirlia",
    ko: "\uD0AC\uB9AC\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 282,
    slug: "gardevoir",
    en: "Gardevoir",
    ko: "\uAC00\uB514\uC548",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 282,
    slug: "mega-gardevoir",
    en: "Mega Gardevoir",
    ko: "\uBA54\uAC00\uAC00\uB514\uC548",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 283,
    slug: "surskit",
    en: "Surskit",
    ko: "\uBE44\uAD6C\uC220",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 284,
    slug: "masquerain",
    en: "Masquerain",
    ko: "\uBE44\uB098\uBC29",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 285,
    slug: "shroomish",
    en: "Shroomish",
    ko: "\uBC84\uC12F\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 286,
    slug: "breloom",
    en: "Breloom",
    ko: "\uBC84\uC12F\uBAA8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 287,
    slug: "slakoth",
    en: "Slakoth",
    ko: "\uAC8C\uC744\uB85C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 288,
    slug: "vigoroth",
    en: "Vigoroth",
    ko: "\uBC1C\uBC14\uB85C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 289,
    slug: "slaking",
    en: "Slaking",
    ko: "\uAC8C\uC744\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 290,
    slug: "nincada",
    en: "Nincada",
    ko: "\uD1A0\uC911\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 291,
    slug: "ninjask",
    en: "Ninjask",
    ko: "\uC544\uC774\uC2A4\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 292,
    slug: "shedinja",
    en: "Shedinja",
    ko: "\uAECD\uC9C8\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 293,
    slug: "whismur",
    en: "Whismur",
    ko: "\uC18C\uACE4\uB8E1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 294,
    slug: "loudred",
    en: "Loudred",
    ko: "\uB178\uACF5\uB8E1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 295,
    slug: "exploud",
    en: "Exploud",
    ko: "\uD3ED\uC74C\uB8E1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 296,
    slug: "makuhita",
    en: "Makuhita",
    ko: "\uB9C8\uD06C\uD0D5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 297,
    slug: "hariyama",
    en: "Hariyama",
    ko: "\uD558\uB9AC\uBB49",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 298,
    slug: "azurill",
    en: "Azurill",
    ko: "\uB8E8\uB9AC\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 299,
    slug: "nosepass",
    en: "Nosepass",
    ko: "\uCF54\uCF54\uD30C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 300,
    slug: "skitty",
    en: "Skitty",
    ko: "\uC5D0\uB098\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 301,
    slug: "delcatty",
    en: "Delcatty",
    ko: "\uB378\uCF00\uD2F0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 302,
    slug: "sableye",
    en: "Sableye",
    ko: "\uAE5C\uAE4C\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 302,
    slug: "mega-sableye",
    en: "Mega Sableye",
    ko: "\uBA54\uAC00\uAE5C\uAE4C\uBBF8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 303,
    slug: "mawile",
    en: "Mawile",
    ko: "\uC785\uCE58\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 303,
    slug: "mega-mawile",
    en: "Mega Mawile",
    ko: "\uBA54\uAC00\uC785\uCE58\uD2B8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 304,
    slug: "aron",
    en: "Aron",
    ko: "\uAC00\uBCF4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 305,
    slug: "lairon",
    en: "Lairon",
    ko: "\uAC31\uB3C4\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 306,
    slug: "aggron",
    en: "Aggron",
    ko: "\uBCF4\uC2A4\uB85C\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 306,
    slug: "mega-aggron",
    en: "Mega Aggron",
    ko: "\uBA54\uAC00\uBCF4\uC2A4\uB85C\uB77C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 307,
    slug: "meditite",
    en: "Meditite",
    ko: "\uC694\uAC00\uB791",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 308,
    slug: "medicham",
    en: "Medicham",
    ko: "\uC694\uAC00\uB7A8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 308,
    slug: "mega-medicham",
    en: "Mega Medicham",
    ko: "\uBA54\uAC00\uC694\uAC00\uB7A8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 309,
    slug: "electrike",
    en: "Electrike",
    ko: "\uC36C\uB354\uB77C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 310,
    slug: "manectric",
    en: "Manectric",
    ko: "\uC36C\uB354\uBCFC\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 310,
    slug: "mega-manectric",
    en: "Mega Manectric",
    ko: "\uBA54\uAC00\uC36C\uB354\uBCFC\uD2B8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 311,
    slug: "plusle",
    en: "Plusle",
    ko: "\uD50C\uB7EC\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 312,
    slug: "minun",
    en: "Minun",
    ko: "\uB9C8\uC774\uB18D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 313,
    slug: "volbeat",
    en: "Volbeat",
    ko: "\uBCFC\uBE44\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 314,
    slug: "illumise",
    en: "Illumise",
    ko: "\uB124\uC624\uBE44\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 315,
    slug: "roselia",
    en: "Roselia",
    ko: "\uB85C\uC824\uB9AC\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 316,
    slug: "gulpin",
    en: "Gulpin",
    ko: "\uAF34\uAE4D\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 317,
    slug: "swalot",
    en: "Swalot",
    ko: "\uAFC0\uAEBD\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 318,
    slug: "carvanha",
    en: "Carvanha",
    ko: "\uC0E4\uD504\uB2C8\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 319,
    slug: "sharpedo",
    en: "Sharpedo",
    ko: "\uC0E4\uD06C\uB2C8\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 319,
    slug: "mega-sharpedo",
    en: "Mega Sharpedo",
    ko: "\uBA54\uAC00\uC0E4\uD06C\uB2C8\uC544",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 320,
    slug: "wailmer",
    en: "Wailmer",
    ko: "\uACE0\uB798\uC655\uC790",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 321,
    slug: "wailord",
    en: "Wailord",
    ko: "\uACE0\uB798\uC655",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 322,
    slug: "numel",
    en: "Numel",
    ko: "\uB454\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 323,
    slug: "camerupt",
    en: "Camerupt",
    ko: "\uD3ED\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 323,
    slug: "mega-camerupt",
    en: "Mega Camerupt",
    ko: "\uBA54\uAC00\uD3ED\uD0C0",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 324,
    slug: "torkoal",
    en: "Torkoal",
    ko: "\uCF54\uD130\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 325,
    slug: "spoink",
    en: "Spoink",
    ko: "\uD53C\uADF8\uC810\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 326,
    slug: "grumpig",
    en: "Grumpig",
    ko: "\uD53C\uADF8\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 327,
    slug: "spinda",
    en: "Spinda",
    ko: "\uC5BC\uB8E8\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 328,
    slug: "trapinch",
    en: "Trapinch",
    ko: "\uD1B1\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 329,
    slug: "vibrava",
    en: "Vibrava",
    ko: "\uBE44\uBE0C\uB77C\uBC14",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 330,
    slug: "flygon",
    en: "Flygon",
    ko: "\uD50C\uB77C\uC774\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 331,
    slug: "cacnea",
    en: "Cacnea",
    ko: "\uC120\uC778\uC655",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 332,
    slug: "cacturne",
    en: "Cacturne",
    ko: "\uBC24\uC120\uC778",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 333,
    slug: "swablu",
    en: "Swablu",
    ko: "\uD30C\uBE44\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 334,
    slug: "altaria",
    en: "Altaria",
    ko: "\uD30C\uBE44\uCF54\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 334,
    slug: "mega-altaria",
    en: "Mega Altaria",
    ko: "\uBA54\uAC00\uD30C\uBE44\uCF54\uB9AC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 335,
    slug: "zangoose",
    en: "Zangoose",
    ko: "\uC7DD\uACE0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 336,
    slug: "seviper",
    en: "Seviper",
    ko: "\uC138\uBE44\uD37C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 337,
    slug: "lunatone",
    en: "Lunatone",
    ko: "\uB8E8\uB098\uD1A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 338,
    slug: "solrock",
    en: "Solrock",
    ko: "\uC194\uB85D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 339,
    slug: "barboach",
    en: "Barboach",
    ko: "\uBBF8\uAFB8\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 340,
    slug: "whiscash",
    en: "Whiscash",
    ko: "\uBA54\uAE45",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 341,
    slug: "corphish",
    en: "Corphish",
    ko: "\uAC00\uC7AC\uAD70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 342,
    slug: "crawdaunt",
    en: "Crawdaunt",
    ko: "\uAC00\uC7AC\uC7A5\uAD70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 343,
    slug: "baltoy",
    en: "Baltoy",
    ko: "\uC624\uB69D\uAD70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 344,
    slug: "claydol",
    en: "Claydol",
    ko: "\uC810\uD1A0\uB3C4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 345,
    slug: "lileep",
    en: "Lileep",
    ko: "\uB9B4\uB9C1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 346,
    slug: "cradily",
    en: "Cradily",
    ko: "\uB9B4\uB9AC\uC694",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 347,
    slug: "anorith",
    en: "Anorith",
    ko: "\uC544\uB178\uB525\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 348,
    slug: "armaldo",
    en: "Armaldo",
    ko: "\uC544\uB9D0\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 349,
    slug: "feebas",
    en: "Feebas",
    ko: "\uBE48\uD2F0\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 350,
    slug: "milotic",
    en: "Milotic",
    ko: "\uBC00\uB85C\uD2F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 351,
    slug: "castform",
    en: "Castform",
    ko: "\uCE90\uC2A4\uD401",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 352,
    slug: "kecleon",
    en: "Kecleon",
    ko: "\uCF08\uB9AC\uBAAC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 353,
    slug: "shuppet",
    en: "Shuppet",
    ko: "\uC5B4\uB460\uB300\uC2E0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 354,
    slug: "banette",
    en: "Banette",
    ko: "\uB2E4\uD06C\uD3AB",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 354,
    slug: "mega-banette",
    en: "Mega Banette",
    ko: "\uBA54\uAC00\uB2E4\uD06C\uD3AB",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 355,
    slug: "duskull",
    en: "Duskull",
    ko: "\uD574\uACE8\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 356,
    slug: "dusclops",
    en: "Dusclops",
    ko: "\uBBF8\uB77C\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 357,
    slug: "tropius",
    en: "Tropius",
    ko: "\uD2B8\uB85C\uD53C\uC6B0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 358,
    slug: "chimecho",
    en: "Chimecho",
    ko: "\uCE58\uB801",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 358,
    slug: "mega-chimecho",
    en: "Meega Chimecho",
    ko: "\uBA54\uAC00\uCE58\uB801",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 359,
    slug: "absol",
    en: "Absol",
    ko: "\uC571\uC194",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 359,
    slug: "mega-absol",
    en: "Mega Absol",
    ko: "\uBA54\uAC00\uC571\uC194",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 359,
    slug: "mega-absol-z",
    en: "Mega Absol Z",
    ko: "\uBA54\uAC00\uC571\uC194Z",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 360,
    slug: "wynaut",
    en: "Wynaut",
    ko: "\uB9C8\uC790",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 361,
    slug: "snorunt",
    en: "Snorunt",
    ko: "\uB208\uAF2C\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 362,
    slug: "glalie",
    en: "Glalie",
    ko: "\uC5BC\uC74C\uADC0\uC2E0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 362,
    slug: "mega-glalie",
    en: "Mega Glalie",
    ko: "\uBA54\uAC00\uC5BC\uC74C\uADC0\uC2E0",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 363,
    slug: "spheal",
    en: "Spheal",
    ko: "\uB300\uAD74\uB808\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 364,
    slug: "sealeo",
    en: "Sealeo",
    ko: "\uC528\uB808\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 365,
    slug: "walrein",
    en: "Walrein",
    ko: "\uC528\uCE74\uC774\uC800",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 366,
    slug: "clamperl",
    en: "Clamperl",
    ko: "\uC9C4\uC8FC\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 367,
    slug: "huntail",
    en: "Huntail",
    ko: "\uD5CC\uD14C\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 368,
    slug: "gorebyss",
    en: "Gorebyss",
    ko: "\uBD84\uD64D\uC7A5\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 369,
    slug: "relicanth",
    en: "Relicanth",
    ko: "\uC2DC\uB77C\uCE78",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 370,
    slug: "luvdisc",
    en: "Luvdisc",
    ko: "\uC0AC\uB791\uB3D9\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 371,
    slug: "bagon",
    en: "Bagon",
    ko: "\uC544\uACF5\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 372,
    slug: "shelgon",
    en: "Shelgon",
    ko: "\uC258\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 373,
    slug: "salamence",
    en: "Salamence",
    ko: "\uBCF4\uB9CC\uB2E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 373,
    slug: "mega-salamence",
    en: "Mega Salamence",
    ko: "\uBA54\uAC00\uBCF4\uB9CC\uB2E4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 374,
    slug: "beldum",
    en: "Beldum",
    ko: "\uBA54\uD0D5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 375,
    slug: "metang",
    en: "Metang",
    ko: "\uBA54\uD0D5\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 376,
    slug: "metagross",
    en: "Metagross",
    ko: "\uBA54\uD0C0\uADF8\uB85C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 376,
    slug: "mega-metagross",
    en: "Mega Metagross",
    ko: "\uBA54\uAC00\uBA54\uD0C0\uADF8\uB85C\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 377,
    slug: "regirock",
    en: "Regirock",
    ko: "\uB808\uC9C0\uB77D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 378,
    slug: "regice",
    en: "Regice",
    ko: "\uB808\uC9C0\uC544\uC774\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 379,
    slug: "registeel",
    en: "Registeel",
    ko: "\uB808\uC9C0\uC2A4\uD2F8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 380,
    slug: "latias",
    en: "Latias",
    ko: "\uB77C\uD2F0\uC544\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 380,
    slug: "mega-latias",
    en: "Mega Latias",
    ko: "\uBA54\uAC00\uB77C\uD2F0\uC544\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 381,
    slug: "latios",
    en: "Latios",
    ko: "\uB77C\uD2F0\uC624\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 381,
    slug: "mega-latios",
    en: "Mega Latios",
    ko: "\uBA54\uAC00\uB77C\uD2F0\uC624\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 382,
    slug: "kyogre",
    en: "Kyogre",
    ko: "\uAC00\uC774\uC624\uAC00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 382,
    slug: "primal-kyogre",
    en: "Primal Kyogre",
    ko: "\uC6D0\uC2DC\uAC00\uC774\uC624\uAC00",
    category: "primal",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 383,
    slug: "groudon",
    en: "Groudon",
    ko: "\uADF8\uB780\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 383,
    slug: "primal-groudon",
    en: "Primal Groudon",
    ko: "\uC6D0\uC2DC\uADF8\uB780\uB3C8",
    category: "primal",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 384,
    slug: "rayquaza",
    en: "Rayquaza",
    ko: "\uB808\uCFE0\uC7C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 384,
    slug: "mega-rayquaza",
    en: "Mega Rayquaza",
    ko: "\uBA54\uAC00\uB808\uCFE0\uC7C8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 385,
    slug: "jirachi",
    en: "Jirachi",
    ko: "\uC9C0\uB77C\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 386,
    slug: "deoxys",
    en: "Deoxys",
    ko: "\uD14C\uC624\uD0A4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 386,
    slug: "deoxys-attack-forme",
    en: "Deoxys (Attack Forme)",
    ko: "\uD14C\uC624\uD0A4\uC2A4(\uC5B4\uD0DD\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 386,
    slug: "deoxys-defense-forme",
    en: "Deoxys (Defense Forme)",
    ko: "\uD14C\uC624\uD0A4\uC2A4(\uB514\uD39C\uC2A4\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 386,
    slug: "deoxys-speed-forme",
    en: "Deoxys (Speed Forme)",
    ko: "\uD14C\uC624\uD0A4\uC2A4(\uC2A4\uD53C\uB4DC\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 387,
    slug: "turtwig",
    en: "Turtwig",
    ko: "\uBAA8\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 388,
    slug: "grotle",
    en: "Grotle",
    ko: "\uC218\uD480\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 389,
    slug: "torterra",
    en: "Torterra",
    ko: "\uD1A0\uB300\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 390,
    slug: "chimchar",
    en: "Chimchar",
    ko: "\uBD88\uAF43\uC22D\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 391,
    slug: "monferno",
    en: "Monferno",
    ko: "\uD30C\uC774\uC22D\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 392,
    slug: "infernape",
    en: "Infernape",
    ko: "\uCD08\uC5FC\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 393,
    slug: "piplup",
    en: "Piplup",
    ko: "\uD33D\uB3C4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 394,
    slug: "prinplup",
    en: "Prinplup",
    ko: "\uD33D\uD0DC\uC790",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 395,
    slug: "empoleon",
    en: "Empoleon",
    ko: "\uC5E0\uD398\uB974\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 396,
    slug: "starly",
    en: "Starly",
    ko: "\uCC0C\uB974\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 397,
    slug: "staravia",
    en: "Staravia",
    ko: "\uCC0C\uB974\uBC84\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 398,
    slug: "staraptor",
    en: "Staraptor",
    ko: "\uCC0C\uB974\uD638\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 398,
    slug: "mega-staraptor",
    en: "Mega Staraptor",
    ko: "\uBA54\uAC00\uCC0C\uB974\uD638\uD06C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 399,
    slug: "bidoof",
    en: "Bidoof",
    ko: "\uBE44\uBC84\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 400,
    slug: "bibarel",
    en: "Bibarel",
    ko: "\uBE44\uBC84\uD1B5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 401,
    slug: "kricketot",
    en: "Kricketot",
    ko: "\uADC0\uB6A4\uB69C\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 402,
    slug: "kricketune",
    en: "Kricketune",
    ko: "\uADC0\uB6A4\uD1A1\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 403,
    slug: "shinx",
    en: "Shinx",
    ko: "\uAF2C\uB9C1\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 404,
    slug: "luxio",
    en: "Luxio",
    ko: "\uB7ED\uC2DC\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 405,
    slug: "luxray",
    en: "Luxray",
    ko: "\uB80C\uD2B8\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 406,
    slug: "budew",
    en: "Budew",
    ko: "\uAF2C\uBABD\uC6B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 407,
    slug: "roserade",
    en: "Roserade",
    ko: "\uB85C\uC988\uB808\uC774\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 408,
    slug: "cranidos",
    en: "Cranidos",
    ko: "\uB450\uAC1C\uB3C4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 409,
    slug: "rampardos",
    en: "Rampardos",
    ko: "\uB7A8\uD384\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 410,
    slug: "shieldon",
    en: "Shieldon",
    ko: "\uBC29\uD328\uD1B1\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 411,
    slug: "bastiodon",
    en: "Bastiodon",
    ko: "\uBC14\uB9AC\uD1B1\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 412,
    slug: "burmy-plant-cloak",
    en: "Burmy",
    ko: "\uB3C4\uB871\uCDA9\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 413,
    slug: "wormadam-plant-cloak",
    en: "Wormadam",
    ko: "\uB3C4\uB871\uB9C8\uB2F4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 413,
    slug: "wormadam-sandy-cloak",
    en: "Wormadam (Sandy Cloak)",
    ko: "\uB3C4\uB871\uB9C8\uB2F4(\uBAA8\uB798\uB545\uB3C4\uB871)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 413,
    slug: "wormadam-trash-cloak",
    en: "Wormadam (Trash Cloak)",
    ko: "\uB3C4\uB871\uB9C8\uB2F4(\uC288\uB808\uB3C4\uB871)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 414,
    slug: "mothim",
    en: "Mothim",
    ko: "\uB098\uBA54\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 415,
    slug: "combee",
    en: "Combee",
    ko: "\uC138\uAFC0\uBC84\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 416,
    slug: "vespiquen",
    en: "Vespiquen",
    ko: "\uBE44\uD038",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 417,
    slug: "pachirisu",
    en: "Pachirisu",
    ko: "\uD30C\uCE58\uB9AC\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 418,
    slug: "buizel",
    en: "Buizel",
    ko: "\uBE0C\uC774\uC824",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 419,
    slug: "floatzel",
    en: "Floatzel",
    ko: "\uD50C\uB85C\uC824",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 420,
    slug: "cherubi",
    en: "Cherubi",
    ko: "\uCCB4\uB9AC\uBC84",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 421,
    slug: "cherrim",
    en: "Cherrim",
    ko: "\uCCB4\uB9AC\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 422,
    slug: "shellos",
    en: "Shellos",
    ko: "\uAE5D\uC9C8\uBB34",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 423,
    slug: "gastrodon",
    en: "Gastrodon",
    ko: "\uD2B8\uB9AC\uD1A0\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 424,
    slug: "ambipom",
    en: "Ambipom",
    ko: "\uAC9F\uD578\uBCF4\uC22D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 425,
    slug: "drifloon",
    en: "Drifloon",
    ko: "\uD754\uB4E4\uD48D\uC190",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 426,
    slug: "drifblim",
    en: "Drifblim",
    ko: "\uB465\uC2E4\uB77C\uC774\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 427,
    slug: "buneary",
    en: "Buneary",
    ko: "\uC774\uC5B4\uB864",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 428,
    slug: "lopunny",
    en: "Lopunny",
    ko: "\uC774\uC5B4\uB86D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 428,
    slug: "mega-lopunny",
    en: "Mega Lopunny",
    ko: "\uBA54\uAC00\uC774\uC5B4\uB86D",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 429,
    slug: "mismagius",
    en: "Mismagius",
    ko: "\uBB34\uC6B0\uB9C8\uC9C1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 430,
    slug: "honchkrow",
    en: "Honchkrow",
    ko: "\uB3C8\uD06C\uB85C\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 431,
    slug: "glameow",
    en: "Glameow",
    ko: "\uB098\uC639\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 432,
    slug: "purugly",
    en: "Purugly",
    ko: "\uBAAC\uB0E5\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 433,
    slug: "chingling",
    en: "Chingling",
    ko: "\uB791\uB538\uB791",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 434,
    slug: "stunky",
    en: "Stunky",
    ko: "\uC2A4\uCEF9\uBFE1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 435,
    slug: "skuntank",
    en: "Skuntank",
    ko: "\uC2A4\uCEF9\uD0F1\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 436,
    slug: "bronzor",
    en: "Bronzor",
    ko: "\uB3D9\uBBF8\uB7EC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 437,
    slug: "bronzong",
    en: "Bronzong",
    ko: "\uB3D9\uD0C1\uAD70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 438,
    slug: "bonsly",
    en: "Bonsly",
    ko: "\uAF2C\uC9C0\uC9C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 439,
    slug: "mime-jr",
    en: "Mime Jr.",
    ko: "\uD749\uB0B4\uB0B4",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 440,
    slug: "happiny",
    en: "Happiny",
    ko: "\uD551\uBCF5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 441,
    slug: "chatot",
    en: "Chatot",
    ko: "\uD398\uB77C\uD398",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 442,
    slug: "spiritomb",
    en: "Spiritomb",
    ko: "\uD654\uAC15\uB3CC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 443,
    slug: "gible",
    en: "Gible",
    ko: "\uB525\uC0C1\uC5B4\uB3D9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 444,
    slug: "gabite",
    en: "Gabite",
    ko: "\uD55C\uBC14\uC774\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 445,
    slug: "garchomp",
    en: "Garchomp",
    ko: "\uD55C\uCE74\uB9AC\uC544\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 445,
    slug: "mega-garchomp",
    en: "Mega Garchomp",
    ko: "\uBA54\uAC00\uD55C\uCE74\uB9AC\uC544\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 445,
    slug: "mega-garchomp-z",
    en: "Mega Garchomp Z",
    ko: "\uBA54\uAC00\uD55C\uCE74\uB9AC\uC544\uC2A4Z",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 446,
    slug: "munchlax",
    en: "Munchlax",
    ko: "\uBA39\uACE0\uC790",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 447,
    slug: "riolu",
    en: "Riolu",
    ko: "\uB9AC\uC624\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 448,
    slug: "lucario",
    en: "Lucario",
    ko: "\uB8E8\uCE74\uB9AC\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 448,
    slug: "mega-lucario",
    en: "Mega Lucario",
    ko: "\uBA54\uAC00\uB8E8\uCE74\uB9AC\uC624",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 448,
    slug: "mega-lucario-z",
    en: "Mega Lucario Z",
    ko: "\uBA54\uAC00\uB8E8\uCE74\uB9AC\uC624Z",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 449,
    slug: "hippopotas",
    en: "Hippopotas",
    ko: "\uD788\uD3EC\uD3EC\uD0C0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 450,
    slug: "hippowdon",
    en: "Hippowdon",
    ko: "\uD558\uB9C8\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 451,
    slug: "skorupi",
    en: "Skorupi",
    ko: "\uC2A4\uCF5C\uD53C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 452,
    slug: "drapion",
    en: "Drapion",
    ko: "\uB4DC\uB798\uD53C\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 453,
    slug: "croagunk",
    en: "Croagunk",
    ko: "\uC090\uB531\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 454,
    slug: "toxicroak",
    en: "Toxicroak",
    ko: "\uB3C5\uAC1C\uAD74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 455,
    slug: "carnivine",
    en: "Carnivine",
    ko: "\uBB34\uC2A4\uD2C8\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 456,
    slug: "finneon",
    en: "Finneon",
    ko: "\uD615\uAD11\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 457,
    slug: "lumineon",
    en: "Lumineon",
    ko: "\uB124\uC624\uB77C\uC774\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 458,
    slug: "mantyke",
    en: "Mantyke",
    ko: "\uD0C0\uB9CC\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 459,
    slug: "snover",
    en: "Snover",
    ko: "\uB208\uC4F0\uAC1C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 460,
    slug: "abomasnow",
    en: "Abomasnow",
    ko: "\uB208\uC124\uC655",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 460,
    slug: "mega-abomasnow",
    en: "Mega Abomasnow",
    ko: "\uBA54\uAC00\uB208\uC124\uC655",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 461,
    slug: "weavile",
    en: "Weavile",
    ko: "\uD3EC\uD478\uB2C8\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 462,
    slug: "magnezone",
    en: "Magnezone",
    ko: "\uC790\uD3EC\uCF54\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 463,
    slug: "lickilicky",
    en: "Lickilicky",
    ko: "\uB0B4\uB8F8\uBCA8\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 464,
    slug: "rhyperior",
    en: "Rhyperior",
    ko: "\uAC70\uB300\uCF54\uBFCC\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 465,
    slug: "tangrowth",
    en: "Tangrowth",
    ko: "\uB369\uCFE0\uB9BC\uBCF4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 466,
    slug: "electivire",
    en: "Electivire",
    ko: "\uC5D0\uB808\uD0A4\uBE14",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 467,
    slug: "magmortar",
    en: "Magmortar",
    ko: "\uB9C8\uADF8\uB9C8\uBC88",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 468,
    slug: "togekiss",
    en: "Togekiss",
    ko: "\uD1A0\uAC8C\uD0A4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 469,
    slug: "yanmega",
    en: "Yanmega",
    ko: "\uBA54\uAC00\uC790\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 470,
    slug: "leafeon",
    en: "Leafeon",
    ko: "\uB9AC\uD53C\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 471,
    slug: "glaceon",
    en: "Glaceon",
    ko: "\uAE00\uB808\uC774\uC2DC\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 472,
    slug: "gliscor",
    en: "Gliscor",
    ko: "\uAE00\uB77C\uC774\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 473,
    slug: "mamoswine",
    en: "Mamoswine",
    ko: "\uB9D8\uBAA8\uAFB8\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 474,
    slug: "porygon-z",
    en: "Porygon-Z",
    ko: "\uD3F4\uB9AC\uACE4Z",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 475,
    slug: "gallade",
    en: "Gallade",
    ko: "\uC5D8\uB808\uC774\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 475,
    slug: "mega-gallade",
    en: "Mega Gallade",
    ko: "\uBA54\uAC00\uC5D8\uB808\uC774\uB4DC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 476,
    slug: "probopass",
    en: "Probopass",
    ko: "\uB300\uCF54\uD30C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 477,
    slug: "dusknoir",
    en: "Dusknoir",
    ko: "\uC57C\uB290\uC640\uB974\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 478,
    slug: "froslass",
    en: "Froslass",
    ko: "\uB208\uC5EC\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 478,
    slug: "mega-froslass",
    en: "Mega Froslass",
    ko: "\uBA54\uAC00\uB208\uC5EC\uC544",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "rotom",
    en: "Rotom",
    ko: "\uB85C\uD1A0\uBB34",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 479,
    slug: "fan-rotom",
    en: "Fan Rotom",
    ko: "\uC2A4\uD540\uB85C\uD1A0\uBB34",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "frost-rotom",
    en: "Frost Rotom",
    ko: "\uD504\uB85C\uC2A4\uD2B8\uB85C\uD1A0\uBB34",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "heat-rotom",
    en: "Heat Rotom",
    ko: "\uD788\uD2B8\uB85C\uD1A0\uBB34",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "mow-rotom",
    en: "Mow Rotom",
    ko: "\uCEE4\uD2B8\uB85C\uD1A0\uBB34",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 479,
    slug: "wash-rotom",
    en: "Wash Rotom",
    ko: "\uC6CC\uC2DC\uB85C\uD1A0\uBB34",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 480,
    slug: "uxie",
    en: "Uxie",
    ko: "\uC720\uD06C\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 481,
    slug: "mesprit",
    en: "Mesprit",
    ko: "\uC5E0\uB77C\uC774\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 482,
    slug: "azelf",
    en: "Azelf",
    ko: "\uC544\uADF8\uB188",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 483,
    slug: "dialga",
    en: "Dialga",
    ko: "\uB514\uC544\uB8E8\uAC00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 484,
    slug: "palkia",
    en: "Palkia",
    ko: "\uD384\uAE30\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 485,
    slug: "heatran",
    en: "Heatran",
    ko: "\uD788\uB4DC\uB7F0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 485,
    slug: "mega-heatran",
    en: "Mega Heatran",
    ko: "\uBA54\uAC00\uD788\uB4DC\uB7F0",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 486,
    slug: "regigigas",
    en: "Regigigas",
    ko: "\uB808\uC9C0\uAE30\uAC00\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 487,
    slug: "giratina-another-forme",
    en: "Giratina",
    ko: "\uAE30\uB77C\uD2F0\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 487,
    slug: "giratina-origin-forme",
    en: "Giratina (Origin Forme)",
    ko: "\uAE30\uB77C\uD2F0\uB098(\uC624\uB9AC\uC9C4\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 488,
    slug: "cresselia",
    en: "Cresselia",
    ko: "\uD06C\uB808\uC138\uB9AC\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 489,
    slug: "phione",
    en: "Phione",
    ko: "\uD53C\uC624\uB124",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 490,
    slug: "manaphy",
    en: "Manaphy",
    ko: "\uB9C8\uB098\uD53C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 491,
    slug: "darkrai",
    en: "Darkrai",
    ko: "\uB2E4\uD06C\uB77C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 491,
    slug: "mega-darkrai",
    en: "Mega Darkrai",
    ko: "\uBA54\uAC00\uB2E4\uD06C\uB77C\uC774",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 492,
    slug: "shaymin-land-forme",
    en: "Shaymin",
    ko: "\uC250\uC774\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 492,
    slug: "shaymin-sky-forme",
    en: "Shaymin (Sky Forme)",
    ko: "\uC250\uC774\uBBF8(\uC2A4\uCE74\uC774\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 493,
    slug: "arceus",
    en: "Arceus",
    ko: "\uC544\uB974\uC138\uC6B0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 494,
    slug: "victini",
    en: "Victini",
    ko: "\uBE44\uD06C\uD2F0\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 495,
    slug: "snivy",
    en: "Snivy",
    ko: "\uC8FC\uB9AC\uBE44\uC580",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 496,
    slug: "servine",
    en: "Servine",
    ko: "\uC0E4\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 497,
    slug: "serperior",
    en: "Serperior",
    ko: "\uC0E4\uB85C\uB2E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 498,
    slug: "tepig",
    en: "Tepig",
    ko: "\uB69C\uAFB8\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 499,
    slug: "pignite",
    en: "Pignite",
    ko: "\uCC28\uC624\uAFC0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 500,
    slug: "emboar",
    en: "Emboar",
    ko: "\uC5FC\uBB34\uC655",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 500,
    slug: "mega-emboar",
    en: "Mega Emboar",
    ko: "\uBA54\uAC00\uC5FC\uBB34\uC655",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 501,
    slug: "oshawott",
    en: "Oshawott",
    ko: "\uC218\uB315\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 502,
    slug: "dewott",
    en: "Dewott",
    ko: "\uC30D\uAC80\uC790\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 503,
    slug: "samurott",
    en: "Samurott",
    ko: "\uB300\uAC80\uADC0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 503,
    slug: "samurott-hisuian",
    en: "Samurott (Hisuian)",
    ko: "\uB300\uAC80\uADC0 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 504,
    slug: "patrat",
    en: "Patrat",
    ko: "\uBCF4\uB974\uC950",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 505,
    slug: "watchog",
    en: "Watchog",
    ko: "\uBCF4\uB974\uADF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 506,
    slug: "lillipup",
    en: "Lillipup",
    ko: "\uC694\uD14C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 507,
    slug: "herdier",
    en: "Herdier",
    ko: "\uD558\uB370\uB9AC\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 508,
    slug: "stoutland",
    en: "Stoutland",
    ko: "\uBC14\uB79C\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 509,
    slug: "purrloin",
    en: "Purrloin",
    ko: "\uC314\uBE44\uB0E5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 510,
    slug: "liepard",
    en: "Liepard",
    ko: "\uB808\uD30C\uB974\uB2E4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 511,
    slug: "pansage",
    en: "Pansage",
    ko: "\uC57C\uB098\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 512,
    slug: "simisage",
    en: "Simisage",
    ko: "\uC57C\uB098\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 513,
    slug: "pansear",
    en: "Pansear",
    ko: "\uBC14\uC624\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 514,
    slug: "simisear",
    en: "Simisear",
    ko: "\uBC14\uC624\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 515,
    slug: "panpour",
    en: "Panpour",
    ko: "\uC557\uCC28\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 516,
    slug: "simipour",
    en: "Simipour",
    ko: "\uC557\uCC28\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 517,
    slug: "munna",
    en: "Munna",
    ko: "\uBABD\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 518,
    slug: "musharna",
    en: "Musharna",
    ko: "\uBABD\uC58C\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 519,
    slug: "pidove",
    en: "Pidove",
    ko: "\uCF69\uB458\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 520,
    slug: "tranquill",
    en: "Tranquill",
    ko: "\uC720\uD1A0\uBE0C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 521,
    slug: "unfezant",
    en: "Unfezant",
    ko: "\uCF04\uD638\uB85C\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 522,
    slug: "blitzle",
    en: "Blitzle",
    ko: "\uC904\uBBA4\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 523,
    slug: "zebstrika",
    en: "Zebstrika",
    ko: "\uC81C\uBE0C\uB77C\uC774\uCE74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 524,
    slug: "roggenrola",
    en: "Roggenrola",
    ko: "\uB2E8\uAD74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 525,
    slug: "boldore",
    en: "Boldore",
    ko: "\uC554\uD2B8\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 526,
    slug: "gigalith",
    en: "Gigalith",
    ko: "\uAE30\uAC00\uC774\uC5B4\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 527,
    slug: "woobat",
    en: "Woobat",
    ko: "\uB610\uB974\uBC15\uC950",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 528,
    slug: "swoobat",
    en: "Swoobat",
    ko: "\uB9D8\uBC15\uC950",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 529,
    slug: "drilbur",
    en: "Drilbur",
    ko: "\uB450\uB354\uB958",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 530,
    slug: "excadrill",
    en: "Excadrill",
    ko: "\uBAB0\uB4DC\uB958",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 530,
    slug: "mega-excadrill",
    en: "Mega Excadrill",
    ko: "\uBA54\uAC00\uBAB0\uB4DC\uB958",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 531,
    slug: "audino",
    en: "Audino",
    ko: "\uB2E4\uBD80\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 531,
    slug: "mega-audino",
    en: "Mega Audino",
    ko: "\uBA54\uAC00\uB2E4\uBD80\uB2C8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 532,
    slug: "timburr",
    en: "Timburr",
    ko: "\uC73C\uB78F\uCC28",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 533,
    slug: "gurdurr",
    en: "Gurdurr",
    ko: "\uD1A0\uC1E0\uACE8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 534,
    slug: "conkeldurr",
    en: "Conkeldurr",
    ko: "\uB178\uBCF4\uCCAD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 535,
    slug: "tympole",
    en: "Tympole",
    ko: "\uB3D9\uCC59\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 536,
    slug: "palpitoad",
    en: "Palpitoad",
    ko: "\uB450\uAE4C\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 537,
    slug: "seismitoad",
    en: "Seismitoad",
    ko: "\uB450\uBE45\uAD74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 538,
    slug: "throh",
    en: "Throh",
    ko: "\uB358\uC9C0\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 539,
    slug: "sawk",
    en: "Sawk",
    ko: "\uD0C0\uACA9\uADC0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 540,
    slug: "sewaddle",
    en: "Sewaddle",
    ko: "\uB450\uB974\uBCF4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 541,
    slug: "swadloon",
    en: "Swadloon",
    ko: "\uB450\uB974\uCFE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 542,
    slug: "leavanny",
    en: "Leavanny",
    ko: "\uBAA8\uC544\uBA38",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 543,
    slug: "venipede",
    en: "Venipede",
    ko: "\uB9C8\uB514\uB124",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 544,
    slug: "whirlipede",
    en: "Whirlipede",
    ko: "\uD720\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 545,
    slug: "scolipede",
    en: "Scolipede",
    ko: "\uD39C\uB4DC\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 545,
    slug: "mega-scolipede",
    en: "Mega Scolipede",
    ko: "\uBA54\uAC00\uD39C\uB4DC\uB77C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 546,
    slug: "cottonee",
    en: "Cottonee",
    ko: "\uC18C\uBBF8\uC548",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 547,
    slug: "whimsicott",
    en: "Whimsicott",
    ko: "\uC5D8\uD48D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 548,
    slug: "petilil",
    en: "Petilil",
    ko: "\uCE58\uB9B4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 549,
    slug: "lilligant",
    en: "Lilligant",
    ko: "\uB4DC\uB808\uB514\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 549,
    slug: "lilligant-hisuian",
    en: "Lilligant (Hisuian)",
    ko: "\uB4DC\uB808\uB514\uC5B4 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 550,
    slug: "basculin-red-striped",
    en: "Basculin",
    ko: "\uBC30\uC4F0\uB098\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 551,
    slug: "sandile",
    en: "Sandile",
    ko: "\uAE5C\uB208\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 552,
    slug: "krokorok",
    en: "Krokorok",
    ko: "\uC545\uBE44\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 553,
    slug: "krookodile",
    en: "Krookodile",
    ko: "\uC545\uBE44\uC544\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 554,
    slug: "darumaka",
    en: "Darumaka",
    ko: "\uB2EC\uB9C9\uD654",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 554,
    slug: "darumaka-galarian",
    en: "Darumaka (Galarian)",
    ko: "\uB2EC\uB9C9\uD654 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 555,
    slug: "darmanitan",
    en: "Darmanitan",
    ko: "\uBD88\uBE44\uB2EC\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 555,
    slug: "darmanitan-galarian",
    en: "Darmanitan (Galarian)",
    ko: "\uBD88\uBE44\uB2EC\uB9C8 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 556,
    slug: "maractus",
    en: "Maractus",
    ko: "\uB9C8\uB77C\uCE74\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 557,
    slug: "dwebble",
    en: "Dwebble",
    ko: "\uB3CC\uC0B4\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 558,
    slug: "crustle",
    en: "Crustle",
    ko: "\uC554\uD330\uB9AC\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 559,
    slug: "scraggy",
    en: "Scraggy",
    ko: "\uACE4\uC728\uB7AD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 560,
    slug: "scrafty",
    en: "Scrafty",
    ko: "\uACE4\uC728\uAC70\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 560,
    slug: "mega-scrafty",
    en: "Mega Scrafty",
    ko: "\uBA54\uAC00\uACE4\uC728\uAC70\uB2C8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 561,
    slug: "sigilyph",
    en: "Sigilyph",
    ko: "\uC2EC\uBCF4\uB7EC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 562,
    slug: "yamask",
    en: "Yamask",
    ko: "\uB370\uC2A4\uB9C8\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 562,
    slug: "yamask-galarian",
    en: "Yamask (Galarian)",
    ko: "\uB370\uC2A4\uB9C8\uC2A4 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 563,
    slug: "cofagrigus",
    en: "Cofagrigus",
    ko: "\uB370\uC2A4\uB2C8\uCE78",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 564,
    slug: "tirtouga",
    en: "Tirtouga",
    ko: "\uD504\uB85C\uD1A0\uAC00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 565,
    slug: "carracosta",
    en: "Carracosta",
    ko: "\uB291\uACE8\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 566,
    slug: "archen",
    en: "Archen",
    ko: "\uC544\uCF04",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 567,
    slug: "archeops",
    en: "Archeops",
    ko: "\uC544\uCF00\uC624\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 568,
    slug: "trubbish",
    en: "Trubbish",
    ko: "\uAE68\uBD09\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 569,
    slug: "garbodor",
    en: "Garbodor",
    ko: "\uB354\uC2A4\uD2B8\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 569,
    slug: "garbodor-gigantamax",
    en: "Garbodor (G)",
    ko: "\uB354\uC2A4\uD2B8\uB098 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 570,
    slug: "zorua",
    en: "Zorua",
    ko: "\uC870\uB85C\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 570,
    slug: "zorua-hisuian",
    en: "Zorua (Hisuian)",
    ko: "\uC870\uB85C\uC544 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 571,
    slug: "zoroark",
    en: "Zoroark",
    ko: "\uC870\uB85C\uC544\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 571,
    slug: "zoroark-hisuian",
    en: "Zoroark (Hisuian)",
    ko: "\uC870\uB85C\uC544\uD06C (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 572,
    slug: "minccino",
    en: "Minccino",
    ko: "\uCE58\uB77C\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 573,
    slug: "cinccino",
    en: "Cinccino",
    ko: "\uCE58\uB77C\uCE58\uB178",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 574,
    slug: "gothita",
    en: "Gothita",
    ko: "\uACE0\uB514\uD0F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 575,
    slug: "gothorita",
    en: "Gothorita",
    ko: "\uACE0\uB514\uBCF4\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 576,
    slug: "gothitelle",
    en: "Gothitelle",
    ko: "\uACE0\uB514\uBAA8\uC544\uC824",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 577,
    slug: "solosis",
    en: "Solosis",
    ko: "\uC720\uB2C8\uB780",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 578,
    slug: "duosion",
    en: "Duosion",
    ko: "\uB4C0\uB780",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 579,
    slug: "reuniclus",
    en: "Reuniclus",
    ko: "\uB780\uCFE8\uB8E8\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 580,
    slug: "ducklett",
    en: "Ducklett",
    ko: "\uAF2C\uC9C0\uBCF4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 581,
    slug: "swanna",
    en: "Swanna",
    ko: "\uC2A4\uC644\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 582,
    slug: "vanillite",
    en: "Vanillite",
    ko: "\uBC14\uB2D0\uD504\uD2F0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 583,
    slug: "vanillish",
    en: "Vanillish",
    ko: "\uBC14\uB2D0\uB9AC\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 584,
    slug: "vanilluxe",
    en: "Vanilluxe",
    ko: "\uBC30\uBC14\uB2D0\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 585,
    slug: "deerling",
    en: "Deerling",
    ko: "\uC0AC\uCCA0\uB85D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 586,
    slug: "sawsbuck",
    en: "Sawsbuck",
    ko: "\uBC14\uB77C\uCCA0\uB85D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 587,
    slug: "emolga",
    en: "Emolga",
    ko: "\uC5D0\uBABD\uAC00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 588,
    slug: "karrablast",
    en: "Karrablast",
    ko: "\uB531\uC815\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 589,
    slug: "escavalier",
    en: "Escavalier",
    ko: "\uC288\uBC14\uB974\uACE0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 590,
    slug: "foongus",
    en: "Foongus",
    ko: "\uAE5C\uB180\uBC84\uC2AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 591,
    slug: "amoonguss",
    en: "Amoonguss",
    ko: "\uBF40\uB85D\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 592,
    slug: "frillish",
    en: "Frillish",
    ko: "\uD0F1\uADF8\uB9B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 593,
    slug: "jellicent",
    en: "Jellicent",
    ko: "\uD0F1\uD0F1\uAC94",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 594,
    slug: "alomomola",
    en: "Alomomola",
    ko: "\uB9D8\uBCF5\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 595,
    slug: "joltik",
    en: "Joltik",
    ko: "\uD30C\uCABC\uC625",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 596,
    slug: "galvantula",
    en: "Galvantula",
    ko: "\uC804\uD234\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 597,
    slug: "ferroseed",
    en: "Ferroseed",
    ko: "\uCCA0\uC2DC\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 598,
    slug: "ferrothorn",
    en: "Ferrothorn",
    ko: "\uB108\uD2B8\uB839",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 599,
    slug: "klink",
    en: "Klink",
    ko: "\uAE30\uC5B4\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 600,
    slug: "klang",
    en: "Klang",
    ko: "\uAE30\uAE30\uC5B4\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 601,
    slug: "klinklang",
    en: "Klinklang",
    ko: "\uAE30\uAE30\uAE30\uC5B4\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 602,
    slug: "tynamo",
    en: "Tynamo",
    ko: "\uC800\uB9AC\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 603,
    slug: "eelektrik",
    en: "Eelektrik",
    ko: "\uC800\uB9AC\uB9B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 604,
    slug: "eelektross",
    en: "Eelektross",
    ko: "\uC800\uB9AC\uB354\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 604,
    slug: "mega-eelektross",
    en: "Mega Eelektross",
    ko: "\uBA54\uAC00\uC800\uB9AC\uB354\uD504",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 605,
    slug: "elgyem",
    en: "Elgyem",
    ko: "\uB9AC\uADF8\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 606,
    slug: "beheeyem",
    en: "Beheeyem",
    ko: "\uBCB0\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 607,
    slug: "litwick",
    en: "Litwick",
    ko: "\uBD88\uCF1C\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 608,
    slug: "lampent",
    en: "Lampent",
    ko: "\uB7A8\uD504\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 609,
    slug: "chandelure",
    en: "Chandelure",
    ko: "\uC0F9\uB378\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 609,
    slug: "mega-chandelure",
    en: "Mega Chandelure",
    ko: "\uBA54\uAC00\uC0F9\uB378\uB77C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 610,
    slug: "axew",
    en: "Axew",
    ko: "\uD130\uAC80\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 611,
    slug: "fraxure",
    en: "Fraxure",
    ko: "\uC561\uC2A8\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 612,
    slug: "haxorus",
    en: "Haxorus",
    ko: "\uC561\uC2A4\uB77C\uC774\uC988",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 613,
    slug: "cubchoo",
    en: "Cubchoo",
    ko: "\uCF54\uACE0\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 614,
    slug: "beartic",
    en: "Beartic",
    ko: "\uD230\uBCA0\uC5B4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 615,
    slug: "cryogonal",
    en: "Cryogonal",
    ko: "\uD504\uB9AC\uC9C0\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 616,
    slug: "shelmet",
    en: "Shelmet",
    ko: "\uCABC\uB9C8\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 617,
    slug: "accelgor",
    en: "Accelgor",
    ko: "\uC5B4\uC9C0\uB9AC\uB354",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 618,
    slug: "stunfisk",
    en: "Stunfisk",
    ko: "\uBA54\uB354",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 618,
    slug: "stunfisk-galarian",
    en: "Stunfisk (Galarian)",
    ko: "\uBA54\uB354 (\uAC00\uB77C\uB974)",
    category: "galar",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 619,
    slug: "mienfoo",
    en: "Mienfoo",
    ko: "\uBE44\uC870\uD478",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 620,
    slug: "mienshao",
    en: "Mienshao",
    ko: "\uBE44\uC870\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 621,
    slug: "druddigon",
    en: "Druddigon",
    ko: "\uD06C\uB9AC\uB9CC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 622,
    slug: "golett",
    en: "Golett",
    ko: "\uACE8\uBE44\uB78C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 623,
    slug: "golurk",
    en: "Golurk",
    ko: "\uACE8\uB8E8\uADF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 623,
    slug: "mega-golurk",
    en: "Mega Golurk",
    ko: "\uBA54\uAC00\uACE8\uB8E8\uADF8",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 624,
    slug: "pawniard",
    en: "Pawniard",
    ko: "\uC790\uB9DD\uCE7C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 625,
    slug: "bisharp",
    en: "Bisharp",
    ko: "\uC808\uAC01\uCC38",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 626,
    slug: "bouffalant",
    en: "Bouffalant",
    ko: "\uBC84\uD504\uB860",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 627,
    slug: "rufflet",
    en: "Rufflet",
    ko: "\uC218\uB9AC\uB465\uBCF4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 628,
    slug: "braviary",
    en: "Braviary",
    ko: "\uC6CC\uAE00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 628,
    slug: "braviaryhisuian",
    en: "Braviary (Hisuian)",
    ko: "\uC6CC\uAE00 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 629,
    slug: "vullaby",
    en: "Vullaby",
    ko: "\uBC8C\uCC28\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 630,
    slug: "mandibuzz",
    en: "Mandibuzz",
    ko: "\uBC84\uB79C\uC9C0\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 631,
    slug: "heatmor",
    en: "Heatmor",
    ko: "\uC564\uD2F0\uACE8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 632,
    slug: "durant",
    en: "Durant",
    ko: "\uC544\uC774\uC564\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 633,
    slug: "deino",
    en: "Deino",
    ko: "\uBAA8\uB178\uB450",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 634,
    slug: "zweilous",
    en: "Zweilous",
    ko: "\uB514\uD5E4\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 635,
    slug: "hydreigon",
    en: "Hydreigon",
    ko: "\uC0BC\uC0BC\uB4DC\uB798",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 636,
    slug: "larvesta",
    en: "Larvesta",
    ko: "\uD65C\uD654\uB974\uBC14",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 637,
    slug: "volcarona",
    en: "Volcarona",
    ko: "\uBD88\uCE74\uBAA8\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 638,
    slug: "cobalion",
    en: "Cobalion",
    ko: "\uCF54\uBC14\uB974\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 639,
    slug: "terrakion",
    en: "Terrakion",
    ko: "\uD14C\uB77C\uD0A4\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 640,
    slug: "virizion",
    en: "Virizion",
    ko: "\uBE44\uB9AC\uB514\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 641,
    slug: "tornadus-incarnate",
    en: "Tornadus",
    ko: "\uD1A0\uB124\uB85C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 641,
    slug: "tornadus-therian",
    en: "Tornadus (Therian)",
    ko: "\uD1A0\uB124\uB85C\uC2A4(\uC601\uBB3C\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 642,
    slug: "thundurus-incarnate",
    en: "Thundurus",
    ko: "\uBCFC\uD2B8\uB85C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 642,
    slug: "thundurus-therian",
    en: "Thundurus (Therian)",
    ko: "\uBCFC\uD2B8\uB85C\uC2A4(\uC601\uBB3C\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 643,
    slug: "reshiram",
    en: "Reshiram",
    ko: "\uB808\uC2DC\uB77C\uBB34",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 644,
    slug: "zekrom",
    en: "Zekrom",
    ko: "\uC81C\uD06C\uB85C\uBB34",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 645,
    slug: "landorus-incarnate",
    en: "Landorus",
    ko: "\uB79C\uB4DC\uB85C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 645,
    slug: "landorus-therian",
    en: "Landorus (Therian)",
    ko: "\uB79C\uB4DC\uB85C\uC2A4(\uC601\uBB3C\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 646,
    slug: "black-kyurem",
    en: "Black Kyurem",
    ko: "\uBE14\uB799\uD050\uB808\uBB34",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 646,
    slug: "kyurem",
    en: "Kyurem",
    ko: "\uD050\uB808\uBB34",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 646,
    slug: "white-kyurem",
    en: "White Kyurem",
    ko: "\uD654\uC774\uD2B8\uD050\uB808\uBB34",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 647,
    slug: "keldeo",
    en: "Keldeo",
    ko: "\uCF00\uB974\uB514\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 648,
    slug: "meloetta-aria",
    en: "Meloetta",
    ko: "\uBA54\uB85C\uC5E3\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 648,
    slug: "meloetta-pirouette",
    en: "Meloetta (Pirouette)",
    ko: "\uBA54\uB85C\uC5E3\uD0C0(\uC2A4\uD15D\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 649,
    slug: "genesect",
    en: "Genesect",
    ko: "\uAC8C\uB178\uC138\uD06C\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 650,
    slug: "chespin",
    en: "Chespin",
    ko: "\uB3C4\uCE58\uB9C8\uB860",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 651,
    slug: "quilladin",
    en: "Quilladin",
    ko: "\uB3C4\uCE58\uBCF4\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 652,
    slug: "chesnaught",
    en: "Chesnaught",
    ko: "\uBE0C\uB9AC\uAC00\uB860",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 652,
    slug: "mega-chesnaught",
    en: "Mega Chesnaught",
    ko: "\uBA54\uAC00\uBE0C\uB9AC\uAC00\uB860",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 653,
    slug: "fennekin",
    en: "Fennekin",
    ko: "\uD478\uD638\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 654,
    slug: "braixen",
    en: "Braixen",
    ko: "\uD14C\uB974\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 655,
    slug: "delphox",
    en: "Delphox",
    ko: "\uB9C8\uD3ED\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 655,
    slug: "mega-delphox",
    en: "Mega Delphox",
    ko: "\uBA54\uAC00\uB9C8\uD3ED\uC2DC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 656,
    slug: "froakie",
    en: "Froakie",
    ko: "\uAC1C\uAD6C\uB9C8\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 657,
    slug: "frogadier",
    en: "Frogadier",
    ko: "\uAC1C\uAD74\uBC18\uC7A5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 658,
    slug: "ash-greninja",
    en: "Ash-Greninja",
    ko: "\uC9C0\uC6B0\uAC1C\uAD74\uB2CC\uC790",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 658,
    slug: "greninja",
    en: "Greninja",
    ko: "\uAC1C\uAD74\uB2CC\uC790",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 658,
    slug: "mega-greninja",
    en: "Mega Greninja",
    ko: "\uBA54\uAC00\uAC1C\uAD74\uB2CC\uC790",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 659,
    slug: "bunnelby",
    en: "Bunnelby",
    ko: "\uD30C\uB974\uBE57",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 660,
    slug: "diggersby",
    en: "Diggersby",
    ko: "\uD30C\uB974\uD1A0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 661,
    slug: "fletchling",
    en: "Fletchling",
    ko: "\uD654\uC0B4\uAF2C\uBE48",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 662,
    slug: "fletchinder",
    en: "Fletchinder",
    ko: "\uBD88\uD654\uC0B4\uBE48",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 663,
    slug: "talonflame",
    en: "Talonflame",
    ko: "\uD30C\uC774\uC5B4\uB85C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 664,
    slug: "scatterbug",
    en: "Scatterbug",
    ko: "\uBD84\uC774\uBC8C\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 665,
    slug: "spewpa",
    en: "Spewpa",
    ko: "\uBD84\uB5A0\uB3C4\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 666,
    slug: "vivillon",
    en: "Vivillon",
    ko: "\uBE44\uBE44\uC6A9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 667,
    slug: "litleo",
    en: "Litleo",
    ko: "\uB808\uC624\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 668,
    slug: "pyroar",
    en: "Pyroar",
    ko: "\uD654\uC5FC\uB808\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 668,
    slug: "mega-pyroar",
    en: "Mega Pyroar",
    ko: "\uBA54\uAC00\uD654\uC5FC\uB808\uC624",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 669,
    slug: "flabebe",
    en: "Flab\xE9b\xE9",
    ko: "\uD50C\uB77C\uBCA0\uBCA0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 670,
    slug: "floette",
    en: "Floette",
    ko: "\uD50C\uB77C\uC5E3\uD14C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 670,
    slug: "floette-eternal-flower",
    en: "Floette Eternal Flower",
    ko: "\uC601\uC6D0\uC758 \uAF43 \uD50C\uB77C\uC5E3\uD14C",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 670,
    slug: "mega-floette",
    en: "Mega Floette",
    ko: "\uBA54\uAC00\uD50C\uB77C\uC5E3\uD14C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 671,
    slug: "florges",
    en: "Florges",
    ko: "\uD50C\uB77C\uC81C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 672,
    slug: "skiddo",
    en: "Skiddo",
    ko: "\uBA54\uC774\uD074",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 673,
    slug: "gogoat",
    en: "Gogoat",
    ko: "\uACE0\uACE0\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 674,
    slug: "pancham",
    en: "Pancham",
    ko: "\uD310\uC9F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 675,
    slug: "pangoro",
    en: "Pangoro",
    ko: "\uBD80\uB780\uB2E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 676,
    slug: "furfrou",
    en: "Furfrou",
    ko: "\uD2B8\uB9AC\uBBF8\uC559",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 677,
    slug: "espurr",
    en: "Espurr",
    ko: "\uB0D0\uC2A4\uD37C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 678,
    slug: "mega-meowstic",
    en: "Mega Meowstic",
    ko: "\uBA54\uAC00\uB0D0\uC624\uB2C9\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 678,
    slug: "meowstic-f",
    en: "Meowstic (female)",
    ko: "\uB0D0\uC624\uB2C9\uC2A4 (\uC554\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 678,
    slug: "meowstic-m",
    en: "Meowstic (male)",
    ko: "\uB0D0\uC624\uB2C9\uC2A4 (\uC218\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 679,
    slug: "honedge",
    en: "Honedge",
    ko: "\uB2E8\uCE7C\uBE59",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 680,
    slug: "doublade",
    en: "Doublade",
    ko: "\uC30D\uAC80\uD0AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 681,
    slug: "aegislash",
    en: "Aegislash",
    ko: "\uD0AC\uAC00\uB974\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 682,
    slug: "spritzee",
    en: "Spritzee",
    ko: "\uC288\uC058",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 683,
    slug: "aromatisse",
    en: "Aromatisse",
    ko: "\uD504\uB808\uD504\uD2F0\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 684,
    slug: "swirlix",
    en: "Swirlix",
    ko: "\uB098\uB8F8\uD37C\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 685,
    slug: "slurpuff",
    en: "Slurpuff",
    ko: "\uB098\uB8E8\uB9BC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 686,
    slug: "inkay",
    en: "Inkay",
    ko: "\uC624\uCF00\uC774\uC9D5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 687,
    slug: "malamar",
    en: "Malamar",
    ko: "\uCE7C\uB77C\uB9C8\uB124\uB85C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 687,
    slug: "mega-malamar",
    en: "Mega Malamar",
    ko: "\uBA54\uAC00\uCE7C\uB77C\uB9C8\uB124\uB85C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 688,
    slug: "binacle",
    en: "Binacle",
    ko: "\uAC70\uBD81\uC190\uC190",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 689,
    slug: "barbaracle",
    en: "Barbaracle",
    ko: "\uAC70\uBD81\uC190\uB370\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 689,
    slug: "mega-barbaracle",
    en: "Mega Barbaracle",
    ko: "\uBA54\uAC00\uAC70\uBD81\uC190\uB370\uC2A4",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 690,
    slug: "skrelp",
    en: "Skrelp",
    ko: "\uC218\uB808\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 691,
    slug: "dragalge",
    en: "Dragalge",
    ko: "\uB4DC\uB798\uCE84",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 691,
    slug: "mega-dragalge",
    en: "Mega Dragalge",
    ko: "\uBA54\uAC00\uB4DC\uB798\uCE84",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 692,
    slug: "clauncher",
    en: "Clauncher",
    ko: "\uC644\uCCA0\uD3EC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 693,
    slug: "clawitzer",
    en: "Clawitzer",
    ko: "\uBE14\uB85C\uC2A4\uD130",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 694,
    slug: "helioptile",
    en: "Helioptile",
    ko: "\uBAA9\uB3C4\uB9AC\uD0A4\uD154",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 695,
    slug: "heliolisk",
    en: "Heliolisk",
    ko: "\uC77C\uB808\uB3C4\uB9AC\uC790\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 696,
    slug: "tyrunt",
    en: "Tyrunt",
    ko: "\uD2F0\uACE0\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 697,
    slug: "tyrantrum",
    en: "Tyrantrum",
    ko: "\uACAC\uACE0\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 698,
    slug: "amaura",
    en: "Amaura",
    ko: "\uC544\uB9C8\uB8E8\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 699,
    slug: "aurorus",
    en: "Aurorus",
    ko: "\uC544\uB9C8\uB8E8\uB974\uAC00",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 700,
    slug: "sylveon",
    en: "Sylveon",
    ko: "\uB2D8\uD53C\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 701,
    slug: "hawlucha",
    en: "Hawlucha",
    ko: "\uB8E8\uCC28\uBD88",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 701,
    slug: "mega-hawlucha",
    en: "Mega Hawlucha",
    ko: "\uBA54\uAC00\uB8E8\uCC28\uBD88",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 702,
    slug: "dedenne",
    en: "Dedenne",
    ko: "\uB370\uB374\uB124",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 703,
    slug: "carbink",
    en: "Carbink",
    ko: "\uBA5C\uB9AC\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 704,
    slug: "goomy",
    en: "Goomy",
    ko: "\uBBF8\uB044\uBA54\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 705,
    slug: "sliggoo",
    en: "Sliggoo",
    ko: "\uBBF8\uB044\uB124\uC77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 705,
    slug: "sliggoo-hisuian",
    en: "Sliggoo (Hisuian)",
    ko: "\uBBF8\uB044\uB124\uC77C (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 706,
    slug: "goodra",
    en: "Goodra",
    ko: "\uBBF8\uB044\uB798\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 706,
    slug: "goodra-hisuian",
    en: "Goodra (Hisuian)",
    ko: "\uBBF8\uB044\uB798\uACE4 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 707,
    slug: "klefki",
    en: "Klefki",
    ko: "\uD074\uB808\uD53C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 708,
    slug: "phantump",
    en: "Phantump",
    ko: "\uB098\uBAA9\uB839",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 709,
    slug: "trevenant",
    en: "Trevenant",
    ko: "\uB300\uB85C\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 710,
    slug: "pumpkaboo",
    en: "Pumpkaboo",
    ko: "\uD638\uBC14\uADC0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 711,
    slug: "gourgeist",
    en: "Gourgeist",
    ko: "\uD38C\uD0A8\uC778",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 712,
    slug: "bergmite",
    en: "Bergmite",
    ko: "\uAF41\uC5B4\uB984",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 713,
    slug: "avalugg",
    en: "Avalugg",
    ko: "\uD06C\uB808\uBCA0\uC774\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 713,
    slug: "avalugg-hisuian",
    en: "Avalugg (Hisuian)",
    ko: "\uD06C\uB808\uBCA0\uC774\uC2A4 (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 714,
    slug: "noibat",
    en: "Noibat",
    ko: "\uC74C\uBC43",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 715,
    slug: "noivern",
    en: "Noivern",
    ko: "\uC74C\uBC88",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 716,
    slug: "xerneas",
    en: "Xerneas",
    ko: "\uC81C\uB974\uB124\uC544\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 717,
    slug: "yveltal",
    en: "Yveltal",
    ko: "\uC774\uBCA8\uD0C0\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 718,
    slug: "mega-zygarde",
    en: "Mega Zygarde",
    ko: "\uBA54\uAC00\uC9C0\uAC00\uB974\uB370",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 718,
    slug: "zygarde-10-forme",
    en: "Zygarde (10% Forme)",
    ko: "\uC9C0\uAC00\uB974\uB370 (10%\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 718,
    slug: "zygarde-50-forme",
    en: "Zygarde (50% Forme)",
    ko: "\uC9C0\uAC00\uB974\uB370 (50%\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 718,
    slug: "zygarde-complete-forme",
    en: "Zygarde (Complete Forme)",
    ko: "\uC9C0\uAC00\uB974\uB370 (\uD37C\uD399\uD2B8\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 719,
    slug: "diancie",
    en: "Diancie",
    ko: "\uB514\uC548\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 719,
    slug: "mega-diancie",
    en: "Mega Diancie",
    ko: "\uBA54\uAC00\uB514\uC548\uC2DC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 720,
    slug: "hoopa-confined",
    en: "Hoopa (Confined)",
    ko: "\uD6C4\uD30C (\uAD74\uB808\uC5D0\uBE60\uC9C4)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 720,
    slug: "hoopa-unbound",
    en: "Hoopa (Unbound)",
    ko: "\uD6C4\uD30C (\uAD74\uB808\uB97C\uBC97\uC5B4\uB09C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 721,
    slug: "volcanion",
    en: "Volcanion",
    ko: "\uBCFC\uCF00\uB2C8\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 722,
    slug: "rowlet",
    en: "Rowlet",
    ko: "\uB098\uBAB0\uBE7C\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 723,
    slug: "dartrix",
    en: "Dartrix",
    ko: "\uBE7C\uBBF8\uC2A4\uB85C\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 724,
    slug: "decidueye",
    en: "Decidueye",
    ko: "\uBAA8\uD06C\uB098\uC774\uD37C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 724,
    slug: "decidueye-hisuian",
    en: "Decidueye (Hisuian)",
    ko: "\uBAA8\uD06C\uB098\uC774\uD37C (\uD788\uC2A4\uC774)",
    category: "hisui",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 725,
    slug: "litten",
    en: "Litten",
    ko: "\uB0D0\uC624\uBD88",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 726,
    slug: "torracat",
    en: "Torracat",
    ko: "\uB0D0\uC624\uD788\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 727,
    slug: "incineroar",
    en: "Incineroar",
    ko: "\uC5B4\uD765\uC5FC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 728,
    slug: "popplio",
    en: "Popplio",
    ko: "\uB204\uB9AC\uACF5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 729,
    slug: "brionne",
    en: "Brionne",
    ko: "\uD0A4\uC694\uACF5",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 730,
    slug: "primarina",
    en: "Primarina",
    ko: "\uB204\uB9AC\uB808\uB290",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 731,
    slug: "pikipek",
    en: "Pikipek",
    ko: "\uCF55\uCF54\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 732,
    slug: "trumbeak",
    en: "Trumbeak",
    ko: "\uD06C\uB77C\uD30C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 733,
    slug: "toucannon",
    en: "Toucannon",
    ko: "\uC655\uD070\uBD80\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 734,
    slug: "yungoos",
    en: "Yungoos",
    ko: "\uC601\uAD6C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 735,
    slug: "gumshoos",
    en: "Gumshoos",
    ko: "\uD615\uC0AC\uAD6C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 736,
    slug: "grubbin",
    en: "Grubbin",
    ko: "\uD131\uC9C0\uCDA9\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 737,
    slug: "charjabug",
    en: "Charjabug",
    ko: "\uC804\uC9C0\uCDA9\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 738,
    slug: "vikavolt",
    en: "Vikavolt",
    ko: "\uD22C\uAD6C\uBFCC\uB17C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 739,
    slug: "crabrawler",
    en: "Crabrawler",
    ko: "\uC624\uAE30\uC9C0\uAC8C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 740,
    slug: "crabominable",
    en: "Crabominable",
    ko: "\uBAA8\uB2E8\uB2E8\uAC8C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 740,
    slug: "mega-crabominable",
    en: "Mega Crabominable",
    ko: "\uBA54\uAC00\uBAA8\uB2E8\uB2E8\uAC8C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-baile",
    en: "Oricorio (Baile)",
    ko: "\uCDA4\uCD94\uC0C8(\uC774\uAE00\uC774\uAE00\uC2A4\uD0C0\uC77C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-pau",
    en: "Oricorio (Pa'u)",
    ko: "\uCDA4\uCD94\uC0C8(\uD6CC\uB77C\uD6CC\uB77C\uC2A4\uD0C0\uC77C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-pom-pom",
    en: "Oricorio (Pom-Pom)",
    ko: "\uCDA4\uCD94\uC0C8(\uD30C\uCE59\uD30C\uCE59\uC2A4\uD0C0\uC77C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 741,
    slug: "oricorio-sensu",
    en: "Oricorio (Sensu)",
    ko: "\uCDA4\uCD94\uC0C8(\uD558\uB298\uD558\uB298\uC2A4\uD0C0\uC77C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 742,
    slug: "cutiefly",
    en: "Cutiefly",
    ko: "\uC5D0\uBE14\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 743,
    slug: "ribombee",
    en: "Ribombee",
    ko: "\uC5D0\uB9AC\uBCF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 744,
    slug: "rockruff",
    en: "Rockruff",
    ko: "\uC554\uBA4D\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 745,
    slug: "lycanroc-dusk",
    en: "Lycanroc (Dusk)",
    ko: "\uB8E8\uAC00\uB8E8\uC554 (\uD669\uD63C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 745,
    slug: "lycanroc-midday",
    en: "Lycanroc (Midday)",
    ko: "\uB8E8\uAC00\uB8E8\uC554 (\uD55C\uB0AE)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 745,
    slug: "lycanroc-midnight",
    en: "Lycanroc (Midnight)",
    ko: "\uB8E8\uAC00\uB8E8\uC554 (\uD55C\uBC24)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 746,
    slug: "wishiwashi-school",
    en: "Wishiwashi (School)",
    ko: "\uC57D\uC5B4\uB9AC (\uAD70\uC758\uBAA8\uC2B5)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 747,
    slug: "mareanie",
    en: "Mareanie",
    ko: "\uC2DC\uB9C8\uC0AC\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 748,
    slug: "toxapex",
    en: "Toxapex",
    ko: "\uB354\uC2DC\uB9C8\uC0AC\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 749,
    slug: "mudbray",
    en: "Mudbray",
    ko: "\uBA38\uB4DC\uB098\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 750,
    slug: "mudsdale",
    en: "Mudsdale",
    ko: "\uB9CC\uB9C8\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 751,
    slug: "dewpider",
    en: "Dewpider",
    ko: "\uBB3C\uAC70\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 752,
    slug: "araquanid",
    en: "Araquanid",
    ko: "\uAE68\uBE44\uBB3C\uAC70\uBBF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 753,
    slug: "fomantis",
    en: "Fomantis",
    ko: "\uC9DC\uB791\uB791",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 754,
    slug: "lurantis",
    en: "Lurantis",
    ko: "\uB77C\uB780\uD2F0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 755,
    slug: "morelull",
    en: "Morelull",
    ko: "\uC790\uB9C8\uC288",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 756,
    slug: "shiinotic",
    en: "Shiinotic",
    ko: "\uB9C8\uC170\uC774\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 757,
    slug: "salandit",
    en: "Salandit",
    ko: "\uC57C\uB3C4\uB1FD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 758,
    slug: "salazzle",
    en: "Salazzle",
    ko: "\uC5FC\uB274\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 759,
    slug: "stufful",
    en: "Stufful",
    ko: "\uD3EC\uACF0\uACF0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 760,
    slug: "bewear",
    en: "Bewear",
    ko: "\uC774\uBE10\uACF0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 761,
    slug: "bounsweet",
    en: "Bounsweet",
    ko: "\uB2EC\uCF64\uC544",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 762,
    slug: "steenee",
    en: "Steenee",
    ko: "\uB2EC\uBB34\uB9AC\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 763,
    slug: "tsareena",
    en: "Tsareena",
    ko: "\uB2EC\uCF54\uD038",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 764,
    slug: "comfey",
    en: "Comfey",
    ko: "\uD050\uC544\uB9C1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 765,
    slug: "oranguru",
    en: "Oranguru",
    ko: "\uD558\uB791\uC6B0\uD0C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 766,
    slug: "passimian",
    en: "Passimian",
    ko: "\uB0B4\uB358\uC22D\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 767,
    slug: "wimpod",
    en: "Wimpod",
    ko: "\uAF2C\uC2DC\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 768,
    slug: "golisopod",
    en: "Golisopod",
    ko: "\uAC11\uC8FC\uBB34\uC0AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 768,
    slug: "mega-golisopod",
    en: "Mega Golisopod",
    ko: "\uBA54\uAC00\uAC11\uC8FC\uBB34\uC0AC",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 769,
    slug: "sandygast",
    en: "Sandygast",
    ko: "\uBAA8\uB798\uAFCD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 770,
    slug: "palossand",
    en: "Palossand",
    ko: "\uBAA8\uB798\uC131\uC774\uB2F9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 771,
    slug: "pyukumuku",
    en: "Pyukumuku",
    ko: "\uD574\uBB34\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 772,
    slug: "type-null",
    en: "Type: Null",
    ko: "\uD0C0\uC785:\uB110",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 773,
    slug: "silvally",
    en: "Silvally",
    ko: "\uC2E4\uBC84\uB514",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 774,
    slug: "minior-core",
    en: "Minior (Core)",
    ko: "\uBA54\uD14C\uB178(\uCF54\uC5B4)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 775,
    slug: "komala",
    en: "Komala",
    ko: "\uC790\uB9D0\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 776,
    slug: "turtonator",
    en: "Turtonator",
    ko: "\uD3ED\uAC70\uBD81\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 777,
    slug: "togedemaru",
    en: "Togedemaru",
    ko: "\uD1A0\uAC8C\uB370\uB9C8\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 778,
    slug: "mimikyu",
    en: "Mimikyu",
    ko: "\uB530\uB77C\uD050",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 779,
    slug: "bruxish",
    en: "Bruxish",
    ko: "\uCE58\uAC08\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 780,
    slug: "drampa",
    en: "Drampa",
    ko: "\uD560\uBE44\uB871",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 780,
    slug: "mega-drampa",
    en: "Mega Drampa",
    ko: "\uBA54\uAC00\uD560\uBE44\uB871",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 781,
    slug: "dhelmise",
    en: "Dhelmise",
    ko: "\uD0C0\uD0C0\uB95C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 782,
    slug: "jangmo-o",
    en: "Jangmo-o",
    ko: "\uC9DC\uB791\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 783,
    slug: "hakamo-o",
    en: "Hakamo-o",
    ko: "\uC9DC\uB791\uACE0\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 784,
    slug: "kommo-o",
    en: "Kommo-o",
    ko: "\uC9DC\uB791\uACE0\uC6B0\uAC70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 785,
    slug: "tapu-koko",
    en: "Tapu Koko",
    ko: "\uCE74\uD478\uAF2C\uAF2C\uAF2D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 786,
    slug: "tapu-lele",
    en: "Tapu Lele",
    ko: "\uCE74\uD478\uB098\uBE44\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 787,
    slug: "tapu-bulu",
    en: "Tapu Bulu",
    ko: "\uCE74\uD478\uBE0C\uB8E8\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 788,
    slug: "tapu-fini",
    en: "Tapu Fini",
    ko: "\uCE74\uD478\uB290\uC9C0\uB290",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 789,
    slug: "cosmog",
    en: "Cosmog",
    ko: "\uCF54\uC2A4\uBAA8\uADF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 790,
    slug: "cosmoem",
    en: "Cosmoem",
    ko: "\uCF54\uC2A4\uBAA8\uC6C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 791,
    slug: "solgaleo",
    en: "Solgaleo",
    ko: "\uC194\uAC00\uB808\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 792,
    slug: "lunala",
    en: "Lunala",
    ko: "\uB8E8\uB098\uC544\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 793,
    slug: "nihilego",
    en: "Nihilego",
    ko: "\uD145\uBE44\uB4DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 794,
    slug: "buzzwole",
    en: "Buzzwole",
    ko: "\uB9E4\uC2DC\uBD95",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 795,
    slug: "pheromosa",
    en: "Pheromosa",
    ko: "\uD398\uB85C\uCF54\uCCB4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 796,
    slug: "xurkitree",
    en: "Xurkitree",
    ko: "\uC804\uC218\uBAA9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 797,
    slug: "celesteela",
    en: "Celesteela",
    ko: "\uCCA0\uD654\uAD6C\uC57C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 798,
    slug: "kartana",
    en: "Kartana",
    ko: "\uC885\uC774\uC2E0\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 799,
    slug: "guzzlord",
    en: "Guzzlord",
    ko: "\uC545\uC2DD\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 800,
    slug: "necrozma",
    en: "Necrozma",
    ko: "\uB124\uD06C\uB85C\uC988\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 800,
    slug: "necrozma-dawn-wings",
    en: "Necrozma (Dawn Wings)",
    ko: "\uB124\uD06C\uB85C\uC988\uB9C8(\uC0C8\uBCBD\uC758\uB0A0\uAC1C)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 800,
    slug: "necrozma-dusk-mane",
    en: "Necrozma (Dusk Mane)",
    ko: "\uB124\uD06C\uB85C\uC988\uB9C8(\uD669\uD63C\uC758\uAC08\uAE30)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 800,
    slug: "ultra-necrozma",
    en: "Ultra Necrozma",
    ko: "\uC6B8\uD2B8\uB77C\uB124\uD06C\uB85C\uC988\uB9C8",
    category: "ultra",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 801,
    slug: "magearna",
    en: "Magearna",
    ko: "\uB9C8\uAE30\uC544\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 801,
    slug: "mega-magearna",
    en: "Mega Magearna",
    ko: "\uBA54\uAC00\uB9C8\uAE30\uC544\uB098",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 802,
    slug: "marshadow",
    en: "Marshadow",
    ko: "\uB9C8\uC0E4\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 803,
    slug: "poipole",
    en: "Poipole",
    ko: "\uBCA0\uBCA0\uB188",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 804,
    slug: "naganadel",
    en: "Naganadel",
    ko: "\uC544\uACE0\uC6A9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 805,
    slug: "stakataka",
    en: "Stakataka",
    ko: "\uCC28\uACE1\uCC28\uACE1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 806,
    slug: "blacephalon",
    en: "Blacephalon",
    ko: "\uB450\uD30C\uD321",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 807,
    slug: "zeraora",
    en: "Zeraora",
    ko: "\uC81C\uB77C\uC624\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 807,
    slug: "mega-zeraora",
    en: "Mega Zeraora",
    ko: "\uBA54\uAC00\uC81C\uB77C\uC624\uB77C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 808,
    slug: "meltan",
    en: "Meltan",
    ko: "\uBA5C\uD0C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 809,
    slug: "melmetal",
    en: "Melmetal",
    ko: "\uBA5C\uBA54\uD0C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 809,
    slug: "melmetal-gigantamax",
    en: "Melmetal (G)",
    ko: "\uBA5C\uBA54\uD0C8 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 810,
    slug: "grookey",
    en: "Grookey",
    ko: "\uD765\uB098\uC22D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 811,
    slug: "thwackey",
    en: "Thwackey",
    ko: "\uCC44\uD0A4\uBABD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 812,
    slug: "rillaboom",
    en: "Rillaboom",
    ko: "\uACE0\uB9B4\uD0C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 812,
    slug: "rillaboom-gigantamax",
    en: "Rillaboom (G)",
    ko: "\uACE0\uB9B4\uD0C0 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 813,
    slug: "scorbunny",
    en: "Scorbunny",
    ko: "\uC5FC\uBC84\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 814,
    slug: "raboot",
    en: "Raboot",
    ko: "\uB798\uBE44\uD48B",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 815,
    slug: "cinderace",
    en: "Cinderace",
    ko: "\uC5D0\uC774\uC2A4\uBC88",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 815,
    slug: "cinderace-gigantamax",
    en: "Cinderace (G)",
    ko: "\uC5D0\uC774\uC2A4\uBC88 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 816,
    slug: "sobble",
    en: "Sobble",
    ko: "\uC6B8\uBA38\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 817,
    slug: "drizzile",
    en: "Drizzile",
    ko: "\uB204\uAC94\uB808\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 818,
    slug: "inteleon",
    en: "Inteleon",
    ko: "\uC778\uD154\uB9AC\uB808\uC628",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 818,
    slug: "inteleon-gigantamax",
    en: "Inteleon (G)",
    ko: "\uC778\uD154\uB9AC\uB808\uC628 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 819,
    slug: "skwovet",
    en: "Skwovet",
    ko: "\uD0D0\uB9AC\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 820,
    slug: "greedent",
    en: "Greedent",
    ko: "\uC694\uC53D\uB9AC\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 821,
    slug: "rookidee",
    en: "Rookidee",
    ko: "\uD30C\uB77C\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 822,
    slug: "corvisquire",
    en: "Corvisquire",
    ko: "\uD30C\uD06C\uB85C\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 823,
    slug: "corviknight",
    en: "Corviknight",
    ko: "\uC544\uBA38\uAE4C\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 823,
    slug: "corviknight-gigantamax",
    en: "Corviknight (G)",
    ko: "\uC544\uBA38\uAE4C\uC624 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 824,
    slug: "blipbug",
    en: "Blipbug",
    ko: "\uB450\uB8E8\uC9C0\uBC8C\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 825,
    slug: "dottler",
    en: "Dottler",
    ko: "\uB808\uB3D4\uBC8C\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 826,
    slug: "orbeetle",
    en: "Orbeetle",
    ko: "\uC774\uC62C\uBE0C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 826,
    slug: "orbeetle-gigantamax",
    en: "Orbeetle (G)",
    ko: "\uC774\uC62C\uBE0C (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 827,
    slug: "nickit",
    en: "Nickit",
    ko: "\uD6D4\uCC98\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 828,
    slug: "thievul",
    en: "Thievul",
    ko: "\uD3ED\uC2AC\uB77C\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 829,
    slug: "gossifleur",
    en: "Gossifleur",
    ko: "\uAF2C\uBAA8\uCE74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 830,
    slug: "eldegoss",
    en: "Eldegoss",
    ko: "\uBC31\uC19C\uBAA8\uCE74",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 831,
    slug: "wooloo",
    en: "Wooloo",
    ko: "\uC6B0\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 832,
    slug: "dubwool",
    en: "Dubwool",
    ko: "\uBC30\uC6B0\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 833,
    slug: "chewtle",
    en: "Chewtle",
    ko: "\uAE68\uBB3C\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 834,
    slug: "drednaw",
    en: "Drednaw",
    ko: "\uAC08\uAC00\uBD80\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 834,
    slug: "drednaw-gigantamax",
    en: "Drednaw (G)",
    ko: "\uAC08\uAC00\uBD80\uAE30 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 835,
    slug: "yamper",
    en: "Yamper",
    ko: "\uBA4D\uD30C\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 836,
    slug: "boltund",
    en: "Boltund",
    ko: "\uD384\uC2A4\uBA4D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 837,
    slug: "rolycoly",
    en: "Rolycoly",
    ko: "\uD0C4\uB3D9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 838,
    slug: "carkol",
    en: "Carkol",
    ko: "\uD0C4\uCC28\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 839,
    slug: "coalossal",
    en: "Coalossal",
    ko: "\uC11D\uD0C4\uC0B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 839,
    slug: "coalossal-gigantamax",
    en: "Coalossal (G)",
    ko: "\uC11D\uD0C4\uC0B0 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 840,
    slug: "applin",
    en: "Applin",
    ko: "\uACFC\uC0AC\uC0AD\uBC8C\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 841,
    slug: "flapple",
    en: "Flapple",
    ko: "\uC560\uD504\uB8E1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 841,
    slug: "flapple-gigantamax",
    en: "Flapple (G)",
    ko: "\uC560\uD504\uB8E1 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 842,
    slug: "appletun",
    en: "Appletun",
    ko: "\uB2E8\uC9C0\uB798\uD50C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 842,
    slug: "appletun-gigantamax",
    en: "Appletun (G)",
    ko: "\uB2E8\uC9C0\uB798\uD50C (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 843,
    slug: "silicobra",
    en: "Silicobra",
    ko: "\uBAA8\uB798\uBC40",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 844,
    slug: "sandaconda",
    en: "Sandaconda",
    ko: "\uC0AC\uB2E4\uC774\uC0AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 844,
    slug: "sandaconda-gigantamax",
    en: "Sandaconda (G)",
    ko: "\uC0AC\uB2E4\uC774\uC0AC (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 845,
    slug: "cramorant",
    en: "Cramorant",
    ko: "\uC73D\uC6B0\uC9C0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 846,
    slug: "arrokuda",
    en: "Arrokuda",
    ko: "\uCC0C\uB85C\uAF2C\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 847,
    slug: "barraskewda",
    en: "Barraskewda",
    ko: "\uAF2C\uCE58\uC870",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 848,
    slug: "toxel",
    en: "Toxel",
    ko: "\uC77C\uB808\uC98C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 849,
    slug: "toxtricity-gigantamax",
    en: "Toxtricity (G)",
    ko: "\uC2A4\uD2B8\uB9B0\uB354 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 849,
    slug: "toxtricity-high",
    en: "Toxtricity High",
    ko: "\uC2A4\uD2B8\uB9B0\uB354 \uD558\uC774",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 849,
    slug: "toxtricity-low",
    en: "Toxtricity Low",
    ko: "\uC2A4\uD2B8\uB9B0\uB354 \uB85C\uC6B0",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 850,
    slug: "sizzlipede",
    en: "Sizzlipede",
    ko: "\uD0DC\uC6B0\uC9C0\uB124",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 851,
    slug: "centiskorch",
    en: "Centiskorch",
    ko: "\uB2E4\uD0DC\uC6B0\uC9C0\uB124",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 851,
    slug: "centiskorch-gigantamax",
    en: "Centiskorch (G)",
    ko: "\uB2E4\uD0DC\uC6B0\uC9C0\uB124 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 852,
    slug: "clobbopus",
    en: "Clobbopus",
    ko: "\uB54C\uB54C\uBB34\uB178",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 853,
    slug: "grapploct",
    en: "Grapploct",
    ko: "\uCF00\uC624\uD37C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 854,
    slug: "sinistea",
    en: "Sinistea",
    ko: "\uB370\uC778\uCC28",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 855,
    slug: "polteageist",
    en: "Polteageist",
    ko: "\uD3EC\uD2B8\uB370\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 856,
    slug: "hatenna",
    en: "Hatenna",
    ko: "\uBAB8\uC9C0\uBE0C\uB9BC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 857,
    slug: "hattrem",
    en: "Hattrem",
    ko: "\uC190\uC9C0\uBE0C\uB9BC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 858,
    slug: "hatterene",
    en: "Hatterene",
    ko: "\uBE0C\uB9AC\uBB34\uC74C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 858,
    slug: "hatterene-gigantamax",
    en: "Hatterene (G)",
    ko: "\uBE0C\uB9AC\uBB34\uC74C (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 859,
    slug: "impidimp",
    en: "Impidimp",
    ko: "\uBA54\uB871\uAFCD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 860,
    slug: "morgrem",
    en: "Morgrem",
    ko: "\uC3D8\uACA8\uBAA8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 861,
    slug: "grimmsnarl",
    en: "Grimmsnarl",
    ko: "\uC624\uB871\uD138",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 861,
    slug: "grimmsnarl-gigantamax",
    en: "Grimmsnarl (G)",
    ko: "\uC624\uB871\uD138 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 862,
    slug: "obstagoon",
    en: "Obstagoon",
    ko: "\uAC00\uB85C\uB9C9\uAD6C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 863,
    slug: "perrserker",
    en: "Perrserker",
    ko: "\uB098\uC774\uD0B9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 864,
    slug: "cursola",
    en: "Cursola",
    ko: "\uC0B0\uD638\uB974\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 865,
    slug: "sirfetchd",
    en: "Sirfetch'd",
    ko: "\uCC3D\uD30C\uB098\uC774\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 866,
    slug: "mr-rime",
    en: "Mr. Rime",
    ko: "\uB9C8\uC784\uAF41\uAF41",
    category: "base",
    is_form: false,
    source: "pokemonData.json"
  },
  {
    dexId: 867,
    slug: "runerigus",
    en: "Runerigus",
    ko: "\uB370\uC2A4\uD310",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 868,
    slug: "milcery",
    en: "Milcery",
    ko: "\uB9C8\uBE4C\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 869,
    slug: "alcremie",
    en: "Alcremie",
    ko: "\uB9C8\uD718\uD551",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 869,
    slug: "alcremie-gigantamax",
    en: "Alcremie (G)",
    ko: "\uB9C8\uD718\uD551 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 870,
    slug: "falinks",
    en: "Falinks",
    ko: "\uB300\uC5EC\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 870,
    slug: "mega-falinks",
    en: "Mega Falinks",
    ko: "\uBA54\uAC00\uB300\uC5EC\uB974",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 871,
    slug: "pincurchin",
    en: "Pincurchin",
    ko: "\uCC0C\uB974\uC131\uAC8C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 872,
    slug: "snom",
    en: "Snom",
    ko: "\uB204\uB2C8\uBA38\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 873,
    slug: "frosmoth",
    en: "Frosmoth",
    ko: "\uBAA8\uC2A4\uB178\uC6B0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 874,
    slug: "stonjourner",
    en: "Stonjourner",
    ko: "\uB3CC\uD5E8\uC9C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 875,
    slug: "eiscue",
    en: "Eiscue",
    ko: "\uBE59\uD050\uBCF4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 876,
    slug: "indeedee-f",
    en: "Indeedee (Female)",
    ko: "\uC5D0\uC368\uB974(\uC554\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 876,
    slug: "indeedee-m",
    en: "Indeedee (Male)",
    ko: "\uC5D0\uC368\uB974(\uC218\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 877,
    slug: "morpeko",
    en: "Morpeko",
    ko: "\uBAA8\uB974\uD398\uCF54",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 878,
    slug: "cufant",
    en: "Cufant",
    ko: "\uB07C\uB9AC\uB3D9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 879,
    slug: "copperajah",
    en: "Copperajah",
    ko: "\uB300\uC655\uB07C\uB9AC\uB3D9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 879,
    slug: "copperajah-gigantamax",
    en: "Copperajah (G)",
    ko: "\uB300\uC655\uB07C\uB9AC\uB3D9 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 880,
    slug: "dracozolt",
    en: "Dracozolt",
    ko: "\uD30C\uCE58\uB798\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 881,
    slug: "arctozolt",
    en: "Arctozolt",
    ko: "\uD30C\uCE58\uB974\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 882,
    slug: "dracovish",
    en: "Dracovish",
    ko: "\uC5B4\uB798\uACE4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 883,
    slug: "arctovish",
    en: "Arctovish",
    ko: "\uC5B4\uCE58\uB974\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 884,
    slug: "duraludon",
    en: "Duraludon",
    ko: "\uB450\uB784\uB8E8\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 884,
    slug: "duraludon-gigantamax",
    en: "Duraludon (G)",
    ko: "\uB450\uB784\uB8E8\uB3C8 (G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 885,
    slug: "dreepy",
    en: "Dreepy",
    ko: "\uB4DC\uB77C\uAF30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 886,
    slug: "drakloak",
    en: "Drakloak",
    ko: "\uB4DC\uB798\uB7F0\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 887,
    slug: "dragapult",
    en: "Dragapult",
    ko: "\uB4DC\uB798\uD384\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 888,
    slug: "zacian-crowned-sword",
    en: "Zacian (Crowned Sword)",
    ko: "\uC790\uC2DC\uC548 (\uAC80\uC655)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 888,
    slug: "zacian-hero-of-many-battles",
    en: "Zacian (Hero of Many Battles)",
    ko: "\uC790\uC2DC\uC548(\uC5ED\uC804\uC758\uC6A9\uC0AC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 889,
    slug: "zamazenta-crowned-shield",
    en: "Zamazenta (Crowned Shield)",
    ko: "\uC790\uB9C8\uC820\uD0C0(\uBC29\uD328\uC655)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 889,
    slug: "zamazenta-hero-of-many-battles",
    en: "Zamazenta (Hero of Many Battles)",
    ko: "\uC790\uB9C8\uC820\uD0C0 (\uC5ED\uC804\uC758\uC6A9\uC0AC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 890,
    slug: "eternatus",
    en: "Eternatus",
    ko: "\uBB34\uD55C\uB2E4\uC774\uB178",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 891,
    slug: "kubfu",
    en: "Kubfu",
    ko: "\uCE58\uACE0\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 892,
    slug: "urshifu-rapid-strike",
    en: "Urshifu (Rapid Strike)",
    ko: "\uC6B0\uB77C\uC624\uC2A4 (\uC5F0\uACA9\uC758\uD0DC\uC138)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 892,
    slug: "urshifu-rapid-strike-gigantamax",
    en: "Urshifu (Rapid Strike G)",
    ko: "\uC6B0\uB77C\uC624\uC2A4 (\uC5F0\uACA9\uC758\uD0DC\uC138 G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 892,
    slug: "urshifu-single-strike",
    en: "Urshifu (Single Strike)",
    ko: "\uC6B0\uB77C\uC624\uC2A4 (\uC77C\uACA9\uC758\uD0DC\uC138)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 892,
    slug: "urshifu-single-strike-gigantamax",
    en: "Urshifu (Single Strike G)",
    ko: "\uC6B0\uB77C\uC624\uC2A4 (\uC77C\uACA9\uC758\uD0DC\uC138 G)",
    category: "gigantamax",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 893,
    slug: "zarude",
    en: "Zarude",
    ko: "\uC790\uB8E8\uB3C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 894,
    slug: "regieleki",
    en: "Regieleki",
    ko: "\uB808\uC9C0\uC5D0\uB808\uD0A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 895,
    slug: "regidrago",
    en: "Regidrago",
    ko: "\uB808\uC9C0\uB4DC\uB798\uACE0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 896,
    slug: "glastrier",
    en: "Glastrier",
    ko: "\uBE14\uB9AC\uC790\uD3EC\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 897,
    slug: "spectrier",
    en: "Spectrier",
    ko: "\uB808\uC774\uC2A4\uD3EC\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 898,
    slug: "calyrex",
    en: "Calyrex",
    ko: "\uBC84\uB4DC\uB809\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 898,
    slug: "calyrex-ice-rider",
    en: "Calyrex (Ice Rider)",
    ko: "\uBC84\uB4DC\uB809\uC2A4(\uBC31\uB9C8\uD0C4\uBAA8\uC2B5)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 898,
    slug: "calyrex-shadow-rider",
    en: "Calyrex (Shadow Rider)",
    ko: "\uBC84\uB4DC\uB809\uC2A4(\uD751\uB9C8\uD0C4\uBAA8\uC2B5)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 899,
    slug: "wyrdeer",
    en: "Wyrdeer",
    ko: "\uC2E0\uBE44\uB85D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 900,
    slug: "kleavor",
    en: "Kleavor",
    ko: "\uC0AC\uB9C8\uC790\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 901,
    slug: "ursaluna",
    en: "Ursaluna",
    ko: "\uB2E4\uD22C\uACF0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 902,
    slug: "basculegion-f",
    en: "Basculegion (Female)",
    ko: "\uB300\uC4F0\uC5EC\uB108(\uC554\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 902,
    slug: "basculegion-m",
    en: "Basculegion (Male)",
    ko: "\uB300\uC4F0\uC5EC\uB108(\uC218\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 903,
    slug: "sneasler",
    en: "Sneasler",
    ko: "\uD3EC\uD478\uB2C8\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 904,
    slug: "overqwil",
    en: "Overqwil",
    ko: "\uC7A5\uCE68\uBC14\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 905,
    slug: "enamorus-incarnate",
    en: "Enamorus (Incarnate)",
    ko: "\uB7EC\uBE0C\uB85C\uC2A4(\uD654\uC2E0\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 905,
    slug: "enamorus-therian",
    en: "Enamorus (Therian)",
    ko: "\uB7EC\uBE0C\uB85C\uC2A4(\uC601\uBB3C\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 906,
    slug: "sprigatito",
    en: "Sprigatito",
    ko: "\uB098\uC624\uD558",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 907,
    slug: "floragato",
    en: "Floragato",
    ko: "\uB098\uB85C\uD14C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 908,
    slug: "meowscarada",
    en: "Meowscarada",
    ko: "\uB9C8\uC2A4\uCE74\uB098",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 909,
    slug: "fuecoco",
    en: "Fuecoco",
    ko: "\uB728\uC544\uAC70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 910,
    slug: "crocalor",
    en: "Crocalor",
    ko: "\uC545\uB728\uAC70",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 911,
    slug: "skeledirge",
    en: "Skeledirge",
    ko: "\uB77C\uC6B0\uB4DC\uBCF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 912,
    slug: "quaxly",
    en: "Quaxly",
    ko: "\uAFB8\uC641\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 913,
    slug: "quaxwell",
    en: "Quaxwell",
    ko: "\uC544\uAFB8\uC641",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 914,
    slug: "quaquaval",
    en: "Quaquaval",
    ko: "\uC6E8\uC774\uB2C8\uBC1C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 915,
    slug: "lechonk",
    en: "Lechonk",
    ko: "\uB9DB\uBCF4\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 916,
    slug: "oinkologne-f",
    en: "Oinkologne (Female)",
    ko: "\uD37C\uD4E8\uB3C8 (\uC554\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 916,
    slug: "oinkologne-m",
    en: "Oinkologne (Male)",
    ko: "\uD37C\uD4E8\uB3C8 (\uC218\uCEF7)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 917,
    slug: "tarountula",
    en: "Tarountula",
    ko: "\uD0C0\uB79C\uD234\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 918,
    slug: "spidops",
    en: "Spidops",
    ko: "\uD2B8\uB798\uD53C\uB354",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 919,
    slug: "nymble",
    en: "Nymble",
    ko: "\uCF69\uC54C\uB69C\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 920,
    slug: "lokix",
    en: "Lokix",
    ko: "\uC5D1\uC2A4\uB808\uADF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 921,
    slug: "pawmi",
    en: "Pawmi",
    ko: "\uBE60\uBAA8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 922,
    slug: "pawmo",
    en: "Pawmo",
    ko: "\uBE60\uBAA8\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 923,
    slug: "pawmot",
    en: "Pawmot",
    ko: "\uBE60\uB974\uBAA8\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 924,
    slug: "tandemaus",
    en: "Tandemaus",
    ko: "\uB450\uB9AC\uC950",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 925,
    slug: "maushold",
    en: "Maushold",
    ko: "\uD30C\uBC00\uB9AC\uC950",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 926,
    slug: "fidough",
    en: "Fidough",
    ko: "\uCAC0\uB3C4\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 927,
    slug: "dachsbun",
    en: "Dachsbun",
    ko: "\uBC14\uC6B0\uCCBC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 928,
    slug: "smoliv",
    en: "Smoliv",
    ko: "\uBBF8\uB2C8\uBE0C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 929,
    slug: "dolliv",
    en: "Dolliv",
    ko: "\uC62C\uB9AC\uB1E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 930,
    slug: "arboliva",
    en: "Arboliva",
    ko: "\uC62C\uB9AC\uB974\uBC14",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 931,
    slug: "squawkabilly",
    en: "Squawkabilly",
    ko: "\uC2DC\uBE44\uAF2C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 932,
    slug: "nacli",
    en: "Nacli",
    ko: "\uBCA0\uBCA0\uC194\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 933,
    slug: "naclstack",
    en: "Naclstack",
    ko: "\uC2A4\uD0DC\uC194\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 934,
    slug: "garganacl",
    en: "Garganacl",
    ko: "\uCF5C\uB85C\uC194\uD2B8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 935,
    slug: "charcadet",
    en: "Charcadet",
    ko: "\uCE74\uB974\uBCF8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 936,
    slug: "armarouge",
    en: "Armarouge",
    ko: "\uCE74\uB514\uB098\uB974\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 937,
    slug: "ceruledge",
    en: "Ceruledge",
    ko: "\uD30C\uB77C\uBE14\uB808\uC774\uC988",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 938,
    slug: "tadbulb",
    en: "Tadbulb",
    ko: "\uBE48\uB098\uB450",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 939,
    slug: "bellibolt",
    en: "Bellibolt",
    ko: "\uCC0C\uB9AC\uBC30\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 940,
    slug: "wattrel",
    en: "Wattrel",
    ko: "\uCC0C\uB9AC\uBE44",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 941,
    slug: "kilowattrel",
    en: "Kilowattrel",
    ko: "\uCC0C\uB9AC\uBE44\uD06C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 942,
    slug: "maschiff",
    en: "Maschiff",
    ko: "\uC624\uB77C\uD2F0\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 943,
    slug: "mabosstiff",
    en: "Mabosstiff",
    ko: "\uB9C8\uD53C\uD2F0\uD504",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 944,
    slug: "shroodle",
    en: "Shroodle",
    ko: "\uB543\uCB48\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 945,
    slug: "grafaiai",
    en: "Grafaiai",
    ko: "\uD0DC\uAE45\uAD6C\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 946,
    slug: "bramblin",
    en: "Bramblin",
    ko: "\uADF8\uD478\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 947,
    slug: "brambleghast",
    en: "Brambleghast",
    ko: "\uACF5\uD478\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 948,
    slug: "toedscool",
    en: "Toedscool",
    ko: "\uB4E4\uB208\uD574",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 949,
    slug: "toedscruel",
    en: "Toedscruel",
    ko: "\uC721\uD30C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 950,
    slug: "klawf",
    en: "Klawf",
    ko: "\uC808\uBCBC\uAC8C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 951,
    slug: "capsakid",
    en: "Capsakid",
    ko: "\uCEA1\uC2F8\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 952,
    slug: "scovillain",
    en: "Scovillain",
    ko: "\uC2A4\uCF54\uBE4C\uB7F0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 952,
    slug: "mega-scovillain",
    en: "Mega Scovillain",
    ko: "\uBA54\uAC00\uC2A4\uCF54\uBE4C\uB7F0",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 953,
    slug: "rellor",
    en: "Rellor",
    ko: "\uAD6C\uB974\uB370",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 954,
    slug: "rabsca",
    en: "Rabsca",
    ko: "\uBCA0\uB77C\uCE74\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 955,
    slug: "flittle",
    en: "Flittle",
    ko: "\uD558\uB290\uB77C\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 956,
    slug: "espathra",
    en: "Espathra",
    ko: "\uD074\uB808\uC2A4\uD37C\uD2B8\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 957,
    slug: "tinkatink",
    en: "Tinkatink",
    ko: "\uC5B4\uB9AC\uC9F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 958,
    slug: "tinkatuff",
    en: "Tinkatuff",
    ko: "\uBCBC\uB9AC\uC9F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 959,
    slug: "tinkaton",
    en: "Tinkaton",
    ko: "\uB450\uB4DC\uB9AC\uC9F1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 960,
    slug: "wiglett",
    en: "Wiglett",
    ko: "\uBC14\uB2E4\uADF8\uB2E4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 961,
    slug: "wugtrio",
    en: "Wugtrio",
    ko: "\uBC14\uB2E5\uD2B8\uB9AC\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 962,
    slug: "bombirdier",
    en: "Bombirdier",
    ko: "\uB5A8\uAD6C\uC0C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 963,
    slug: "finizen",
    en: "Finizen",
    ko: "\uB9E8\uB3CC\uD540",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 964,
    slug: "palafin",
    en: "Palafin",
    ko: "\uB3CC\uD540\uB9E8(\uB098\uC774\uBE0C\uD3FC)",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 965,
    slug: "varoom",
    en: "Varoom",
    ko: "\uBD80\uB974\uB871",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 966,
    slug: "revavroom",
    en: "Revavroom",
    ko: "\uBD80\uB974\uB974\uB8F8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 967,
    slug: "cyclizar",
    en: "Cyclizar",
    ko: "\uBAA8\uD1A0\uB9C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 968,
    slug: "orthworm",
    en: "Orthworm",
    ko: "\uAFC8\uD2B8\uB801",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 969,
    slug: "glimmet",
    en: "Glimmet",
    ko: "\uCD08\uB871\uC21C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 970,
    slug: "glimmora",
    en: "Glimmora",
    ko: "\uD0AC\uB77C\uD50C\uB85C\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 970,
    slug: "mega-glimmora",
    en: "Mega Glimmora",
    ko: "\uBA54\uAC00\uD0AC\uB77C\uD50C\uB85C\uB974",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 971,
    slug: "greavard",
    en: "Greavard",
    ko: "\uB9DD\uB9DD\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 972,
    slug: "houndstone",
    en: "Houndstone",
    ko: "\uBB18\uB450\uAE30",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 973,
    slug: "flamigo",
    en: "Flamigo",
    ko: "\uAF2C\uC774\uBC0D\uACE0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 974,
    slug: "cetoddle",
    en: "Cetoddle",
    ko: "\uD130\uBC85\uACE0\uB798",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 975,
    slug: "cetitan",
    en: "Cetitan",
    ko: "\uC6B0\uB77D\uACE0\uB798",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 976,
    slug: "veluza",
    en: "Veluza",
    ko: "\uAC00\uBE44\uB8E8\uC0AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 977,
    slug: "dondozo",
    en: "Dondozo",
    ko: "\uC5B4\uC368\uB7EC\uC154",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 978,
    slug: "tatsugiri",
    en: "Tatsugiri",
    ko: "\uC2F8\uB9AC\uC6A9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 978,
    slug: "mega-tatsugiri",
    en: "Mega Tatsugiri",
    ko: "\uBA54\uAC00\uC2F8\uB9AC\uC6A9",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 979,
    slug: "annihilape",
    en: "Annihilape",
    ko: "\uC800\uC2B9\uAC13\uC22D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 980,
    slug: "clodsire",
    en: "Clodsire",
    ko: "\uD1A0\uC624",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 981,
    slug: "farigiraf",
    en: "Farigiraf",
    ko: "\uD0A4\uD0A4\uB9C1",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 982,
    slug: "dudunsparce",
    en: "Dudunsparce",
    ko: "\uB178\uACE0\uACE0\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 983,
    slug: "kingambit",
    en: "Kingambit",
    ko: "\uB300\uB3C4\uAC01\uCC38",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 984,
    slug: "great-tusk",
    en: "Great Tusk",
    ko: "\uC704\uB300\uD55C\uC5C4\uB2C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 985,
    slug: "scream-tail",
    en: "Scream Tail",
    ko: "\uC6B0\uB801\uCC2C\uAF2C\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 986,
    slug: "brute-bonnet",
    en: "Brute Bonnet",
    ko: "\uC0AC\uB098\uC6B4\uBC84\uC12F",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 987,
    slug: "flutter-mane",
    en: "Flutter Mane",
    ko: "\uB0A0\uAC1C\uCE58\uB294\uBA38\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 988,
    slug: "slither-wing",
    en: "Slither Wing",
    ko: "\uB545\uC744\uAE30\uB294\uB0A0\uAC1C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 989,
    slug: "sandy-shocks",
    en: "Sandy Shocks",
    ko: "\uBAA8\uB798\uD138\uAC00\uC8FD",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 990,
    slug: "iron-treads",
    en: "Iron Treads",
    ko: "\uBB34\uC1E0\uBC14\uD034",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 991,
    slug: "iron-bundle",
    en: "Iron Bundle",
    ko: "\uBB34\uC1E0\uBCF4\uB530\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 992,
    slug: "iron-hands",
    en: "Iron Hands",
    ko: "\uBB34\uC1E0\uC190",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 993,
    slug: "iron-jugulis",
    en: "Iron Jugulis",
    ko: "\uBB34\uC1E0\uBA38\uB9AC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 994,
    slug: "iron-moth",
    en: "Iron Moth",
    ko: "\uBB34\uC1E0\uB3C5\uB098\uBC29",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 995,
    slug: "iron-thorns",
    en: "Iron Thorns",
    ko: "\uBB34\uC1E0\uAC00\uC2DC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 996,
    slug: "frigibax",
    en: "Frigibax",
    ko: "\uB4DC\uB2C8\uCC28",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 997,
    slug: "arctibax",
    en: "Arctibax",
    ko: "\uB4DC\uB2C8\uAF41",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 998,
    slug: "baxcalibur",
    en: "Baxcalibur",
    ko: "\uB4DC\uB2D0\uB808\uC774\uBE0C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 998,
    slug: "mega-baxcalibur",
    en: "Mega Baxcalibur",
    ko: "\uBA54\uAC00\uB4DC\uB2D0\uB808\uC774\uBE0C",
    category: "mega",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 999,
    slug: "gimmighoul",
    en: "Gimmighoul",
    ko: "\uBAA8\uC73C\uB839",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1e3,
    slug: "gholdengo",
    en: "Gholdengo",
    ko: "\uD0C0\uBD80\uC790\uACE0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1001,
    slug: "wo-chien",
    en: "Wo-Chien",
    ko: "\uCD1D\uC9C0\uC5D4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1002,
    slug: "chien-pao",
    en: "Chien-Pao",
    ko: "\uD30C\uC624\uC820",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1003,
    slug: "ting-lu",
    en: "Ting-Lu",
    ko: "\uB529\uB8E8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1004,
    slug: "chi-yu",
    en: "Chi-Yu",
    ko: "\uC704\uC720\uC774",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1005,
    slug: "roaring-moon",
    en: "Roaring Moon",
    ko: "\uACE0\uB3D9\uCE58\uB294\uB2EC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1006,
    slug: "iron-valiant",
    en: "Iron Valiant",
    ko: "\uBB34\uC1E0\uBB34\uC778",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1007,
    slug: "koraidon",
    en: "Koraidon",
    ko: "\uCF54\uB77C\uC774\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1008,
    slug: "miraidon",
    en: "Miraidon",
    ko: "\uBBF8\uB77C\uC774\uB3C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1009,
    slug: "walking-wake",
    en: "Walking Wake",
    ko: "\uAD7D\uC774\uCE58\uB294\uBB3C\uACB0",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1010,
    slug: "iron-leaves",
    en: "Iron Leaves",
    ko: "\uBB34\uC1E0\uC78E\uC0C8",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1011,
    slug: "dipplin",
    en: "Dipplin",
    ko: "\uACFC\uBBF8\uB974",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1012,
    slug: "poltchageist",
    en: "Poltchageist",
    ko: "\uCC28\uB370\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1013,
    slug: "sinistcha",
    en: "Sinistcha",
    ko: "\uADF8\uC6B0\uB9B0\uCC28",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1014,
    slug: "okidogi",
    en: "Okidogi",
    ko: "\uC870\uD0C0\uAD6C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1015,
    slug: "munkidori",
    en: "Munkidori",
    ko: "\uC774\uC57C\uD6C4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1016,
    slug: "fezandipiti",
    en: "Fezandipiti",
    ko: "\uAE30\uB85C\uCE58",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1017,
    slug: "ogerpon-cornerstone-mask",
    en: "Ogerpon (Cornerstone Mask)",
    ko: "\uC624\uAC70\uD3F0 (\uC8FC\uCDA7\uB3CC\uAC00\uBA74)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1017,
    slug: "ogerpon-hearthflame-mask",
    en: "Ogerpon (Hearthflame Mask)",
    ko: "\uC624\uAC70\uD3F0 (\uD654\uB355\uC758\uAC00\uBA74)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1017,
    slug: "ogerpon-teal-mask",
    en: "Ogerpon (Teal Mask)",
    ko: "\uC624\uAC70\uD3F0 (\uBCBD\uB85D\uC758\uAC00\uBA74)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1017,
    slug: "ogerpon-wellspring-mask",
    en: "Ogerpon (Wellspring Mask)",
    ko: "\uC624\uAC70\uD3F0 (\uC6B0\uBB3C\uAC00\uBA74)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1018,
    slug: "archaludon",
    en: "Archaludon",
    ko: "\uBE0C\uB9AC\uB450\uB77C\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1019,
    slug: "hydrapple",
    en: "Hydrapple",
    ko: "\uACFC\uBBF8\uB4DC\uB77C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1020,
    slug: "gouging-fire",
    en: "Gouging Fire",
    ko: "\uAFF0\uB6AB\uB294\uD654\uC5FC",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1021,
    slug: "raging-bolt",
    en: "Raging Bolt",
    ko: "\uB0A0\uB6F0\uB294\uC6B0\uB808",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1022,
    slug: "iron-boulder",
    en: "Iron Boulder",
    ko: "\uBB34\uC1E0\uC554\uC11D",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1023,
    slug: "iron-crown",
    en: "Iron Crown",
    ko: "\uBB34\uC1E0\uAC10\uD22C",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1024,
    slug: "terapagos",
    en: "Terapagos",
    ko: "\uD14C\uB77C\uD30C\uACE0\uC2A4",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 1024,
    slug: "terapagos-terastal",
    en: "Terapagos (Terastal Form)",
    ko: "\uD14C\uB77C\uD30C\uACE0\uC2A4 (\uD14C\uB77C\uC2A4\uD0C8\uD3FC)",
    category: "form",
    is_form: true,
    source: "pokemonData.json"
  },
  {
    dexId: 1025,
    slug: "pecharunt",
    en: "Pecharunt",
    ko: "\uBCF5\uC22D\uC545\uB3D9",
    category: "base",
    is_form: false,
    source: "pokemon-ko-en.csv"
  },
  {
    dexId: 901,
    slug: "ursaluna-blood-moon",
    en: "Ursaluna (Bloodmoon)",
    ko: "\uB2E4\uD22C\uACF0(\uBD89\uC740 \uB2EC)",
    category: "form",
    is_form: true,
    source: "images/normal/ursaluna-blood-moon.webp"
  }
];

// data/pokemon-background-types.json
var pokemon_background_types_default = {
  bySlug: {
    bulbasaur: [
      "grass",
      "poison"
    ],
    ivysaur: [
      "grass",
      "poison"
    ],
    venusaur: [
      "grass",
      "poison"
    ],
    "mega-venusaur": [
      "grass",
      "poison"
    ],
    "venusaur-gigantamax": [
      "grass",
      "poison"
    ],
    charmander: [
      "fire"
    ],
    charmeleon: [
      "fire"
    ],
    charizard: [
      "fire",
      "flying"
    ],
    "charizard-gigantamax": [
      "fire",
      "flying"
    ],
    "mega-charizard-x": [
      "fire",
      "dragon"
    ],
    "mega-charizard-y": [
      "fire",
      "flying"
    ],
    squirtle: [
      "water"
    ],
    wartortle: [
      "water"
    ],
    blastoise: [
      "water"
    ],
    "blastoise-gigantamax": [
      "water"
    ],
    "mega-blastoise": [
      "water"
    ],
    caterpie: [
      "bug"
    ],
    metapod: [
      "bug"
    ],
    butterfree: [
      "bug",
      "flying"
    ],
    "butterfree-gigantamax": [
      "bug",
      "flying"
    ],
    weedle: [
      "bug",
      "poison"
    ],
    kakuna: [
      "bug",
      "poison"
    ],
    beedrill: [
      "bug",
      "poison"
    ],
    "mega-beedrill": [
      "bug",
      "poison"
    ],
    pidgey: [
      "normal",
      "flying"
    ],
    pidgeotto: [
      "normal",
      "flying"
    ],
    pidgeot: [
      "normal",
      "flying"
    ],
    "mega-pidgeot": [
      "normal",
      "flying"
    ],
    rattata: [
      "normal"
    ],
    "rattata-alolan": [
      "dark",
      "normal"
    ],
    raticate: [
      "normal"
    ],
    "raticate-alolan": [
      "dark",
      "normal"
    ],
    spearow: [
      "normal",
      "flying"
    ],
    fearow: [
      "normal",
      "flying"
    ],
    ekans: [
      "poison"
    ],
    arbok: [
      "poison"
    ],
    pikachu: [
      "electric"
    ],
    "pikachu-gigantamax": [
      "electric"
    ],
    raichu: [
      "electric"
    ],
    "mega-raichu-x": [
      "electric"
    ],
    "mega-raichu-y": [
      "electric"
    ],
    "raichu-alolan": [
      "electric",
      "psychic"
    ],
    sandshrew: [
      "ground"
    ],
    "sandshrew-alolan": [
      "ice",
      "steel"
    ],
    sandslash: [
      "ground"
    ],
    "sandslash-alolan": [
      "ice",
      "steel"
    ],
    "nidoran-f": [
      "poison"
    ],
    "nidoran\u2640": [
      "poison"
    ],
    nidorina: [
      "poison"
    ],
    nidoqueen: [
      "poison",
      "ground"
    ],
    "nidoran-m": [
      "poison"
    ],
    "nidoran\u2642": [
      "poison"
    ],
    nidorino: [
      "poison"
    ],
    nidoking: [
      "poison",
      "ground"
    ],
    clefairy: [
      "fairy"
    ],
    clefable: [
      "fairy"
    ],
    "mega-clefable": [
      "fairy",
      "flying"
    ],
    vulpix: [
      "fire"
    ],
    "vulpix-alolan": [
      "ice"
    ],
    ninetales: [
      "fire"
    ],
    "ninetales-alolan": [
      "ice",
      "fairy"
    ],
    jigglypuff: [
      "normal",
      "fairy"
    ],
    wigglytuff: [
      "normal",
      "fairy"
    ],
    zubat: [
      "poison",
      "flying"
    ],
    golbat: [
      "poison",
      "flying"
    ],
    oddish: [
      "grass",
      "poison"
    ],
    gloom: [
      "grass",
      "poison"
    ],
    vileplume: [
      "grass",
      "poison"
    ],
    paras: [
      "bug",
      "grass"
    ],
    parasect: [
      "bug",
      "grass"
    ],
    venonat: [
      "bug",
      "poison"
    ],
    venomoth: [
      "bug",
      "poison"
    ],
    diglett: [
      "ground"
    ],
    "diglett-alolan": [
      "ground",
      "steel"
    ],
    dugtrio: [
      "ground"
    ],
    "dugtrio-alolan": [
      "ground",
      "steel"
    ],
    meowth: [
      "normal"
    ],
    "meowth-alolan": [
      "dark"
    ],
    "meowth-galarian": [
      "steel"
    ],
    "meowth-gigantamax": [
      "normal"
    ],
    persian: [
      "normal"
    ],
    "persian-alolan": [
      "dark"
    ],
    psyduck: [
      "water"
    ],
    golduck: [
      "water"
    ],
    mankey: [
      "fighting"
    ],
    primeape: [
      "fighting"
    ],
    growlithe: [
      "fire"
    ],
    "growlithe-hisuian": [
      "fire",
      "rock"
    ],
    arcanine: [
      "fire"
    ],
    "arcanine-hisuian": [
      "fire",
      "rock"
    ],
    poliwag: [
      "water"
    ],
    poliwhirl: [
      "water"
    ],
    poliwrath: [
      "water",
      "fighting"
    ],
    abra: [
      "psychic"
    ],
    kadabra: [
      "psychic"
    ],
    alakazam: [
      "psychic"
    ],
    "mega-alakazam": [
      "psychic"
    ],
    machop: [
      "fighting"
    ],
    machoke: [
      "fighting"
    ],
    machamp: [
      "fighting"
    ],
    "machamp-gigantamax": [
      "fighting"
    ],
    bellsprout: [
      "grass",
      "poison"
    ],
    weepinbell: [
      "grass",
      "poison"
    ],
    victreebel: [
      "grass",
      "poison"
    ],
    "mega-victreebel": [
      "grass",
      "poison"
    ],
    tentacool: [
      "water",
      "poison"
    ],
    tentacruel: [
      "water",
      "poison"
    ],
    geodude: [
      "rock",
      "ground"
    ],
    "geodude-alolan": [
      "rock",
      "electric"
    ],
    graveler: [
      "rock",
      "ground"
    ],
    "graveler-alolan": [
      "rock",
      "electric"
    ],
    golem: [
      "rock",
      "ground"
    ],
    "golem-alolan": [
      "rock",
      "electric"
    ],
    ponyta: [
      "fire"
    ],
    "ponyta-galarian": [
      "psychic"
    ],
    rapidash: [
      "fire"
    ],
    "rapidash-galarian": [
      "psychic",
      "fairy"
    ],
    slowpoke: [
      "water",
      "psychic"
    ],
    "slowpoke-galarian": [
      "psychic"
    ],
    slowbro: [
      "water",
      "psychic"
    ],
    "mega-slowbro": [
      "water",
      "psychic"
    ],
    "slowbro-galarian": [
      "poison",
      "psychic"
    ],
    magnemite: [
      "electric",
      "steel"
    ],
    magneton: [
      "electric",
      "steel"
    ],
    farfetchd: [
      "normal",
      "flying"
    ],
    "farfetch\u2019d": [
      "normal",
      "flying"
    ],
    "farfetchd-galarian": [
      "fighting"
    ],
    doduo: [
      "normal",
      "flying"
    ],
    dodrio: [
      "normal",
      "flying"
    ],
    seel: [
      "water"
    ],
    dewgong: [
      "water",
      "ice"
    ],
    grimer: [
      "poison"
    ],
    "grimer-alolan": [
      "poison",
      "dark"
    ],
    muk: [
      "poison"
    ],
    "muk-alolan": [
      "poison",
      "dark"
    ],
    shellder: [
      "water"
    ],
    cloyster: [
      "water",
      "ice"
    ],
    gastly: [
      "ghost",
      "poison"
    ],
    haunter: [
      "ghost",
      "poison"
    ],
    gengar: [
      "ghost",
      "poison"
    ],
    "gengar-gigantamax": [
      "ghost",
      "poison"
    ],
    "mega-gengar": [
      "ghost",
      "poison"
    ],
    onix: [
      "rock",
      "ground"
    ],
    drowzee: [
      "psychic"
    ],
    hypno: [
      "psychic"
    ],
    krabby: [
      "water"
    ],
    kingler: [
      "water"
    ],
    "kingler-gigantamax": [
      "water"
    ],
    voltorb: [
      "electric"
    ],
    "voltorb-hisuian": [
      "electric",
      "grass"
    ],
    electrode: [
      "electric"
    ],
    "electrode-hisuian": [
      "electric",
      "grass"
    ],
    exeggcute: [
      "grass",
      "psychic"
    ],
    exeggutor: [
      "grass",
      "psychic"
    ],
    "exeggutor-alolan": [
      "grass",
      "dragon"
    ],
    cubone: [
      "ground"
    ],
    marowak: [
      "ground"
    ],
    "marowak-alolan": [
      "fire",
      "ghost"
    ],
    hitmonlee: [
      "fighting"
    ],
    hitmonchan: [
      "fighting"
    ],
    lickitung: [
      "normal"
    ],
    koffing: [
      "poison"
    ],
    weezing: [
      "poison"
    ],
    "weezing-galarian": [
      "poison",
      "fairy"
    ],
    rhyhorn: [
      "ground",
      "rock"
    ],
    rhydon: [
      "ground",
      "rock"
    ],
    chansey: [
      "normal"
    ],
    tangela: [
      "grass"
    ],
    kangaskhan: [
      "normal"
    ],
    "mega-kangaskhan": [
      "normal"
    ],
    horsea: [
      "water"
    ],
    seadra: [
      "water"
    ],
    goldeen: [
      "water"
    ],
    seaking: [
      "water"
    ],
    staryu: [
      "water"
    ],
    starmie: [
      "water",
      "psychic"
    ],
    "mega-starmie": [
      "water",
      "psychic"
    ],
    "mr.-mime": [
      "psychic",
      "fairy"
    ],
    "mr-mime": [
      "psychic",
      "fairy"
    ],
    "mr-mime-galarian": [
      "ice",
      "psychic"
    ],
    scyther: [
      "bug",
      "flying"
    ],
    jynx: [
      "ice",
      "psychic"
    ],
    electabuzz: [
      "electric"
    ],
    magmar: [
      "fire"
    ],
    pinsir: [
      "bug"
    ],
    "mega-pinsir": [
      "bug",
      "flying"
    ],
    tauros: [
      "normal"
    ],
    "tauros-aqua-breed": [
      "fighting",
      "water"
    ],
    "tauros-blaze-breed": [
      "fighting",
      "fire"
    ],
    "tauros-combat-breed": [
      "fighting"
    ],
    magikarp: [
      "water"
    ],
    gyarados: [
      "water",
      "flying"
    ],
    "mega-gyarados": [
      "water",
      "dark"
    ],
    lapras: [
      "water",
      "ice"
    ],
    "lapras-gigantamax": [
      "water",
      "ice"
    ],
    ditto: [
      "normal"
    ],
    eevee: [
      "normal"
    ],
    "eevee-gigantamax": [
      "normal"
    ],
    vaporeon: [
      "water"
    ],
    jolteon: [
      "electric"
    ],
    flareon: [
      "fire"
    ],
    porygon: [
      "normal"
    ],
    omanyte: [
      "rock",
      "water"
    ],
    omastar: [
      "rock",
      "water"
    ],
    kabuto: [
      "rock",
      "water"
    ],
    kabutops: [
      "rock",
      "water"
    ],
    aerodactyl: [
      "rock",
      "flying"
    ],
    "mega-aerodactyl": [
      "rock",
      "flying"
    ],
    snorlax: [
      "normal"
    ],
    "snorlax-gigantamax": [
      "normal"
    ],
    articuno: [
      "ice",
      "flying"
    ],
    "articuno-galarian": [
      "psychic",
      "flying"
    ],
    zapdos: [
      "electric",
      "flying"
    ],
    "zapdos-galarian": [
      "fighting",
      "flying"
    ],
    moltres: [
      "fire",
      "flying"
    ],
    "moltres-galarian": [
      "dark",
      "flying"
    ],
    dratini: [
      "dragon"
    ],
    dragonair: [
      "dragon"
    ],
    dragonite: [
      "dragon",
      "flying"
    ],
    "mega-dragonite": [
      "dragon",
      "flying"
    ],
    mewtwo: [
      "psychic"
    ],
    "mega-mewtwo-x": [
      "psychic",
      "fighting"
    ],
    "mega-mewtwo-y": [
      "psychic"
    ],
    mew: [
      "psychic"
    ],
    chikorita: [
      "grass"
    ],
    bayleef: [
      "grass"
    ],
    meganium: [
      "grass"
    ],
    "mega-meganium": [
      "grass",
      "fairy"
    ],
    cyndaquil: [
      "fire"
    ],
    quilava: [
      "fire"
    ],
    typhlosion: [
      "fire"
    ],
    "typhlosion-hisuian": [
      "fire",
      "ghost"
    ],
    totodile: [
      "water"
    ],
    croconaw: [
      "water"
    ],
    feraligatr: [
      "water"
    ],
    "mega-feraligatr": [
      "water",
      "dragon"
    ],
    sentret: [
      "normal"
    ],
    furret: [
      "normal"
    ],
    hoothoot: [
      "normal",
      "flying"
    ],
    noctowl: [
      "normal",
      "flying"
    ],
    ledyba: [
      "bug",
      "flying"
    ],
    ledian: [
      "bug",
      "flying"
    ],
    spinarak: [
      "bug",
      "poison"
    ],
    ariados: [
      "bug",
      "poison"
    ],
    crobat: [
      "poison",
      "flying"
    ],
    chinchou: [
      "water",
      "electric"
    ],
    lanturn: [
      "water",
      "electric"
    ],
    pichu: [
      "electric"
    ],
    cleffa: [
      "fairy"
    ],
    igglybuff: [
      "normal",
      "fairy"
    ],
    togepi: [
      "fairy"
    ],
    togetic: [
      "fairy",
      "flying"
    ],
    natu: [
      "psychic",
      "flying"
    ],
    xatu: [
      "psychic",
      "flying"
    ],
    mareep: [
      "electric"
    ],
    flaaffy: [
      "electric"
    ],
    ampharos: [
      "electric"
    ],
    "mega-ampharos": [
      "electric",
      "dragon"
    ],
    bellossom: [
      "grass"
    ],
    marill: [
      "water",
      "fairy"
    ],
    azumarill: [
      "water",
      "fairy"
    ],
    sudowoodo: [
      "rock"
    ],
    politoed: [
      "water"
    ],
    hoppip: [
      "grass",
      "flying"
    ],
    skiploom: [
      "grass",
      "flying"
    ],
    jumpluff: [
      "grass",
      "flying"
    ],
    aipom: [
      "normal"
    ],
    sunkern: [
      "grass"
    ],
    sunflora: [
      "grass"
    ],
    yanma: [
      "bug",
      "flying"
    ],
    wooper: [
      "water",
      "ground"
    ],
    "wooper-paldean": [
      "poison",
      "ground"
    ],
    quagsire: [
      "water",
      "ground"
    ],
    espeon: [
      "psychic"
    ],
    umbreon: [
      "dark"
    ],
    murkrow: [
      "dark",
      "flying"
    ],
    slowking: [
      "water",
      "psychic"
    ],
    "slowking-galarian": [
      "poison",
      "psychic"
    ],
    misdreavus: [
      "ghost"
    ],
    unown: [
      "psychic"
    ],
    wobbuffet: [
      "psychic"
    ],
    girafarig: [
      "normal",
      "psychic"
    ],
    pineco: [
      "bug"
    ],
    forretress: [
      "bug",
      "steel"
    ],
    dunsparce: [
      "normal"
    ],
    gligar: [
      "ground",
      "flying"
    ],
    steelix: [
      "steel",
      "ground"
    ],
    "mega-steelix": [
      "steel",
      "ground"
    ],
    snubbull: [
      "fairy"
    ],
    granbull: [
      "fairy"
    ],
    qwilfish: [
      "water",
      "poison"
    ],
    "qwilfish-hisuian": [
      "dark",
      "poison"
    ],
    scizor: [
      "bug",
      "steel"
    ],
    "mega-scizor": [
      "bug",
      "steel"
    ],
    shuckle: [
      "bug",
      "rock"
    ],
    heracross: [
      "bug",
      "fighting"
    ],
    "mega-heracross": [
      "bug",
      "fighting"
    ],
    sneasel: [
      "dark",
      "ice"
    ],
    "sneasel-hisuian": [
      "fighting",
      "poison"
    ],
    teddiursa: [
      "normal"
    ],
    ursaring: [
      "normal"
    ],
    slugma: [
      "fire"
    ],
    magcargo: [
      "fire",
      "rock"
    ],
    swinub: [
      "ice",
      "ground"
    ],
    piloswine: [
      "ice",
      "ground"
    ],
    corsola: [
      "water",
      "rock"
    ],
    "corsola-galarian": [
      "ghost"
    ],
    remoraid: [
      "water"
    ],
    octillery: [
      "water"
    ],
    delibird: [
      "ice",
      "flying"
    ],
    mantine: [
      "water",
      "flying"
    ],
    skarmory: [
      "steel",
      "flying"
    ],
    "mega-skarmory": [
      "steel",
      "flying"
    ],
    houndour: [
      "dark",
      "fire"
    ],
    houndoom: [
      "dark",
      "fire"
    ],
    "mega-houndoom": [
      "dark",
      "fire"
    ],
    kingdra: [
      "water",
      "dragon"
    ],
    phanpy: [
      "ground"
    ],
    donphan: [
      "ground"
    ],
    porygon2: [
      "normal"
    ],
    stantler: [
      "normal"
    ],
    smeargle: [
      "normal"
    ],
    tyrogue: [
      "fighting"
    ],
    hitmontop: [
      "fighting"
    ],
    smoochum: [
      "ice",
      "psychic"
    ],
    elekid: [
      "electric"
    ],
    magby: [
      "fire"
    ],
    miltank: [
      "normal"
    ],
    blissey: [
      "normal"
    ],
    raikou: [
      "electric"
    ],
    entei: [
      "fire"
    ],
    suicune: [
      "water"
    ],
    larvitar: [
      "rock",
      "ground"
    ],
    pupitar: [
      "rock",
      "ground"
    ],
    tyranitar: [
      "rock",
      "dark"
    ],
    "mega-tyranitar": [
      "rock",
      "dark"
    ],
    lugia: [
      "psychic",
      "flying"
    ],
    "ho-oh": [
      "fire",
      "flying"
    ],
    celebi: [
      "psychic",
      "grass"
    ],
    treecko: [
      "grass"
    ],
    grovyle: [
      "grass"
    ],
    sceptile: [
      "grass"
    ],
    "mega-sceptile": [
      "grass",
      "dragon"
    ],
    torchic: [
      "fire"
    ],
    combusken: [
      "fire",
      "fighting"
    ],
    blaziken: [
      "fire",
      "fighting"
    ],
    "mega-blaziken": [
      "fire",
      "fighting"
    ],
    mudkip: [
      "water"
    ],
    marshtomp: [
      "water",
      "ground"
    ],
    swampert: [
      "water",
      "ground"
    ],
    "mega-swampert": [
      "water",
      "ground"
    ],
    poochyena: [
      "dark"
    ],
    mightyena: [
      "dark"
    ],
    zigzagoon: [
      "normal"
    ],
    "zigzagoon-galarian": [
      "dark",
      "normal"
    ],
    linoone: [
      "normal"
    ],
    "linoone-galarian": [
      "dark",
      "normal"
    ],
    wurmple: [
      "bug"
    ],
    silcoon: [
      "bug"
    ],
    beautifly: [
      "bug",
      "flying"
    ],
    cascoon: [
      "bug"
    ],
    dustox: [
      "bug",
      "poison"
    ],
    lotad: [
      "water",
      "grass"
    ],
    lombre: [
      "water",
      "grass"
    ],
    ludicolo: [
      "water",
      "grass"
    ],
    seedot: [
      "grass"
    ],
    nuzleaf: [
      "grass",
      "dark"
    ],
    shiftry: [
      "grass",
      "dark"
    ],
    taillow: [
      "normal",
      "flying"
    ],
    swellow: [
      "normal",
      "flying"
    ],
    wingull: [
      "water",
      "flying"
    ],
    pelipper: [
      "water",
      "flying"
    ],
    ralts: [
      "psychic",
      "fairy"
    ],
    kirlia: [
      "psychic",
      "fairy"
    ],
    gardevoir: [
      "psychic",
      "fairy"
    ],
    "mega-gardevoir": [
      "psychic",
      "fairy"
    ],
    surskit: [
      "bug",
      "water"
    ],
    masquerain: [
      "bug",
      "flying"
    ],
    shroomish: [
      "grass"
    ],
    breloom: [
      "grass",
      "fighting"
    ],
    slakoth: [
      "normal"
    ],
    vigoroth: [
      "normal"
    ],
    slaking: [
      "normal"
    ],
    nincada: [
      "bug",
      "ground"
    ],
    ninjask: [
      "bug",
      "flying"
    ],
    shedinja: [
      "bug",
      "ghost"
    ],
    whismur: [
      "normal"
    ],
    loudred: [
      "normal"
    ],
    exploud: [
      "normal"
    ],
    makuhita: [
      "fighting"
    ],
    hariyama: [
      "fighting"
    ],
    azurill: [
      "normal",
      "fairy"
    ],
    nosepass: [
      "rock"
    ],
    skitty: [
      "normal"
    ],
    delcatty: [
      "normal"
    ],
    sableye: [
      "dark",
      "ghost"
    ],
    "mega-sableye": [
      "dark",
      "ghost"
    ],
    mawile: [
      "steel",
      "fairy"
    ],
    "mega-mawile": [
      "steel",
      "fairy"
    ],
    aron: [
      "steel",
      "rock"
    ],
    lairon: [
      "steel",
      "rock"
    ],
    aggron: [
      "steel",
      "rock"
    ],
    "mega-aggron": [
      "steel"
    ],
    meditite: [
      "fighting",
      "psychic"
    ],
    medicham: [
      "fighting",
      "psychic"
    ],
    "mega-medicham": [
      "fighting",
      "psychic"
    ],
    electrike: [
      "electric"
    ],
    manectric: [
      "electric"
    ],
    "mega-manectric": [
      "electric"
    ],
    plusle: [
      "electric"
    ],
    minun: [
      "electric"
    ],
    volbeat: [
      "bug"
    ],
    illumise: [
      "bug"
    ],
    roselia: [
      "grass",
      "poison"
    ],
    gulpin: [
      "poison"
    ],
    swalot: [
      "poison"
    ],
    carvanha: [
      "water",
      "dark"
    ],
    sharpedo: [
      "water",
      "dark"
    ],
    "mega-sharpedo": [
      "water",
      "dark"
    ],
    wailmer: [
      "water"
    ],
    wailord: [
      "water"
    ],
    numel: [
      "fire",
      "ground"
    ],
    camerupt: [
      "fire",
      "ground"
    ],
    "mega-camerupt": [
      "fire",
      "ground"
    ],
    torkoal: [
      "fire"
    ],
    spoink: [
      "psychic"
    ],
    grumpig: [
      "psychic"
    ],
    spinda: [
      "normal"
    ],
    trapinch: [
      "ground"
    ],
    vibrava: [
      "ground",
      "dragon"
    ],
    flygon: [
      "ground",
      "dragon"
    ],
    cacnea: [
      "grass"
    ],
    cacturne: [
      "grass",
      "dark"
    ],
    swablu: [
      "normal",
      "flying"
    ],
    altaria: [
      "dragon",
      "flying"
    ],
    "mega-altaria": [
      "dragon",
      "fairy"
    ],
    zangoose: [
      "normal"
    ],
    seviper: [
      "poison"
    ],
    lunatone: [
      "rock",
      "psychic"
    ],
    solrock: [
      "rock",
      "psychic"
    ],
    barboach: [
      "water",
      "ground"
    ],
    whiscash: [
      "water",
      "ground"
    ],
    corphish: [
      "water"
    ],
    crawdaunt: [
      "water",
      "dark"
    ],
    baltoy: [
      "ground",
      "psychic"
    ],
    claydol: [
      "ground",
      "psychic"
    ],
    lileep: [
      "rock",
      "grass"
    ],
    cradily: [
      "rock",
      "grass"
    ],
    anorith: [
      "rock",
      "bug"
    ],
    armaldo: [
      "rock",
      "bug"
    ],
    feebas: [
      "water"
    ],
    milotic: [
      "water"
    ],
    castform: [
      "normal"
    ],
    kecleon: [
      "normal"
    ],
    shuppet: [
      "ghost"
    ],
    banette: [
      "ghost"
    ],
    "mega-banette": [
      "ghost"
    ],
    duskull: [
      "ghost"
    ],
    dusclops: [
      "ghost"
    ],
    tropius: [
      "grass",
      "flying"
    ],
    chimecho: [
      "psychic"
    ],
    "mega-chimecho": [
      "psychic",
      "steel"
    ],
    absol: [
      "dark"
    ],
    "mega-absol": [
      "dark"
    ],
    "mega-absol-z": [
      "dark",
      "ghost"
    ],
    wynaut: [
      "psychic"
    ],
    snorunt: [
      "ice"
    ],
    glalie: [
      "ice"
    ],
    "mega-glalie": [
      "ice"
    ],
    spheal: [
      "ice",
      "water"
    ],
    sealeo: [
      "ice",
      "water"
    ],
    walrein: [
      "ice",
      "water"
    ],
    clamperl: [
      "water"
    ],
    huntail: [
      "water"
    ],
    gorebyss: [
      "water"
    ],
    relicanth: [
      "water",
      "rock"
    ],
    luvdisc: [
      "water"
    ],
    bagon: [
      "dragon"
    ],
    shelgon: [
      "dragon"
    ],
    salamence: [
      "dragon",
      "flying"
    ],
    "mega-salamence": [
      "dragon",
      "flying"
    ],
    beldum: [
      "steel",
      "psychic"
    ],
    metang: [
      "steel",
      "psychic"
    ],
    metagross: [
      "steel",
      "psychic"
    ],
    "mega-metagross": [
      "steel",
      "psychic"
    ],
    regirock: [
      "rock"
    ],
    regice: [
      "ice"
    ],
    registeel: [
      "steel"
    ],
    latias: [
      "dragon",
      "psychic"
    ],
    "mega-latias": [
      "dragon",
      "psychic"
    ],
    latios: [
      "dragon",
      "psychic"
    ],
    "mega-latios": [
      "dragon",
      "psychic"
    ],
    kyogre: [
      "water"
    ],
    "primal-kyogre": [
      "water"
    ],
    groudon: [
      "ground"
    ],
    "primal-groudon": [
      "ground",
      "fire"
    ],
    rayquaza: [
      "dragon",
      "flying"
    ],
    "mega-rayquaza": [
      "dragon",
      "flying"
    ],
    jirachi: [
      "steel",
      "psychic"
    ],
    deoxys: [
      "psychic"
    ],
    "deoxys-attack-forme": [
      "psychic"
    ],
    "deoxys-defense-forme": [
      "psychic"
    ],
    "deoxys-speed-forme": [
      "psychic"
    ],
    turtwig: [
      "grass"
    ],
    grotle: [
      "grass"
    ],
    torterra: [
      "grass",
      "ground"
    ],
    chimchar: [
      "fire"
    ],
    monferno: [
      "fire",
      "fighting"
    ],
    infernape: [
      "fire",
      "fighting"
    ],
    piplup: [
      "water"
    ],
    prinplup: [
      "water"
    ],
    empoleon: [
      "water",
      "steel"
    ],
    starly: [
      "normal",
      "flying"
    ],
    staravia: [
      "normal",
      "flying"
    ],
    staraptor: [
      "normal",
      "flying"
    ],
    "mega-staraptor": [
      "fighting",
      "flying"
    ],
    bidoof: [
      "normal"
    ],
    bibarel: [
      "normal",
      "water"
    ],
    kricketot: [
      "bug"
    ],
    kricketune: [
      "bug"
    ],
    shinx: [
      "electric"
    ],
    luxio: [
      "electric"
    ],
    luxray: [
      "electric"
    ],
    budew: [
      "grass",
      "poison"
    ],
    roserade: [
      "grass",
      "poison"
    ],
    cranidos: [
      "rock"
    ],
    rampardos: [
      "rock"
    ],
    shieldon: [
      "rock",
      "steel"
    ],
    bastiodon: [
      "rock",
      "steel"
    ],
    "burmy-plant-cloak": [
      "bug"
    ],
    "wormadam-plant-cloak": [
      "bug",
      "grass"
    ],
    "wormadam-sandy-cloak": [
      "bug",
      "ground"
    ],
    "wormadam-trash-cloak": [
      "bug",
      "steel"
    ],
    mothim: [
      "bug",
      "flying"
    ],
    combee: [
      "bug",
      "flying"
    ],
    vespiquen: [
      "bug",
      "flying"
    ],
    pachirisu: [
      "electric"
    ],
    buizel: [
      "water"
    ],
    floatzel: [
      "water"
    ],
    cherubi: [
      "grass"
    ],
    cherrim: [
      "grass"
    ],
    shellos: [
      "water"
    ],
    gastrodon: [
      "water",
      "ground"
    ],
    ambipom: [
      "normal"
    ],
    drifloon: [
      "ghost",
      "flying"
    ],
    drifblim: [
      "ghost",
      "flying"
    ],
    buneary: [
      "normal"
    ],
    lopunny: [
      "normal"
    ],
    "mega-lopunny": [
      "normal",
      "fighting"
    ],
    mismagius: [
      "ghost"
    ],
    honchkrow: [
      "dark",
      "flying"
    ],
    glameow: [
      "normal"
    ],
    purugly: [
      "normal"
    ],
    chingling: [
      "psychic"
    ],
    stunky: [
      "poison",
      "dark"
    ],
    skuntank: [
      "poison",
      "dark"
    ],
    bronzor: [
      "steel",
      "psychic"
    ],
    bronzong: [
      "steel",
      "psychic"
    ],
    bonsly: [
      "rock"
    ],
    "mime-jr": [
      "psychic",
      "fairy"
    ],
    happiny: [
      "normal"
    ],
    chatot: [
      "normal",
      "flying"
    ],
    spiritomb: [
      "ghost",
      "dark"
    ],
    gible: [
      "dragon",
      "ground"
    ],
    gabite: [
      "dragon",
      "ground"
    ],
    garchomp: [
      "dragon",
      "ground"
    ],
    "mega-garchomp": [
      "dragon",
      "ground"
    ],
    "mega-garchomp-z": [
      "dragon"
    ],
    munchlax: [
      "normal"
    ],
    riolu: [
      "fighting"
    ],
    lucario: [
      "fighting",
      "steel"
    ],
    "mega-lucario": [
      "fighting",
      "steel"
    ],
    "mega-lucario-z": [
      "fighting",
      "steel"
    ],
    hippopotas: [
      "ground"
    ],
    hippowdon: [
      "ground"
    ],
    skorupi: [
      "poison",
      "bug"
    ],
    drapion: [
      "poison",
      "dark"
    ],
    croagunk: [
      "poison",
      "fighting"
    ],
    toxicroak: [
      "poison",
      "fighting"
    ],
    carnivine: [
      "grass"
    ],
    finneon: [
      "water"
    ],
    lumineon: [
      "water"
    ],
    mantyke: [
      "water",
      "flying"
    ],
    snover: [
      "grass",
      "ice"
    ],
    abomasnow: [
      "grass",
      "ice"
    ],
    "mega-abomasnow": [
      "grass",
      "ice"
    ],
    weavile: [
      "dark",
      "ice"
    ],
    magnezone: [
      "electric",
      "steel"
    ],
    lickilicky: [
      "normal"
    ],
    rhyperior: [
      "ground",
      "rock"
    ],
    tangrowth: [
      "grass"
    ],
    electivire: [
      "electric"
    ],
    magmortar: [
      "fire"
    ],
    togekiss: [
      "fairy",
      "flying"
    ],
    yanmega: [
      "bug",
      "flying"
    ],
    leafeon: [
      "grass"
    ],
    glaceon: [
      "ice"
    ],
    gliscor: [
      "ground",
      "flying"
    ],
    mamoswine: [
      "ice",
      "ground"
    ],
    "porygon-z": [
      "normal"
    ],
    gallade: [
      "psychic",
      "fighting"
    ],
    "mega-gallade": [
      "psychic",
      "fighting"
    ],
    probopass: [
      "rock",
      "steel"
    ],
    dusknoir: [
      "ghost"
    ],
    froslass: [
      "ice",
      "ghost"
    ],
    "mega-froslass": [
      "ice",
      "ghost"
    ],
    rotom: [
      "electric",
      "ghost"
    ],
    "fan-rotom": [
      "electric",
      "flying"
    ],
    "frost-rotom": [
      "electric",
      "ice"
    ],
    "heat-rotom": [
      "electric",
      "fire"
    ],
    "mow-rotom": [
      "electric",
      "grass"
    ],
    "wash-rotom": [
      "electric",
      "water"
    ],
    uxie: [
      "psychic"
    ],
    mesprit: [
      "psychic"
    ],
    azelf: [
      "psychic"
    ],
    dialga: [
      "steel",
      "dragon"
    ],
    palkia: [
      "water",
      "dragon"
    ],
    heatran: [
      "fire",
      "steel"
    ],
    "mega-heatran": [
      "fire",
      "steel"
    ],
    regigigas: [
      "normal"
    ],
    "giratina-another-forme": [
      "ghost",
      "dragon"
    ],
    "giratina-origin-forme": [
      "ghost",
      "dragon"
    ],
    cresselia: [
      "psychic"
    ],
    phione: [
      "water"
    ],
    manaphy: [
      "water"
    ],
    darkrai: [
      "dark"
    ],
    "mega-darkrai": [
      "dark"
    ],
    "shaymin-land-forme": [
      "grass"
    ],
    "shaymin-sky-forme": [
      "grass",
      "flying"
    ],
    arceus: [
      "normal"
    ],
    victini: [
      "psychic",
      "fire"
    ],
    snivy: [
      "grass"
    ],
    servine: [
      "grass"
    ],
    serperior: [
      "grass"
    ],
    tepig: [
      "fire"
    ],
    pignite: [
      "fire",
      "fighting"
    ],
    emboar: [
      "fire",
      "fighting"
    ],
    "mega-emboar": [
      "fire",
      "fighting"
    ],
    oshawott: [
      "water"
    ],
    dewott: [
      "water"
    ],
    samurott: [
      "water"
    ],
    "samurott-hisuian": [
      "water",
      "dark"
    ],
    patrat: [
      "normal"
    ],
    watchog: [
      "normal"
    ],
    lillipup: [
      "normal"
    ],
    herdier: [
      "normal"
    ],
    stoutland: [
      "normal"
    ],
    purrloin: [
      "dark"
    ],
    liepard: [
      "dark"
    ],
    pansage: [
      "grass"
    ],
    simisage: [
      "grass"
    ],
    pansear: [
      "fire"
    ],
    simisear: [
      "fire"
    ],
    panpour: [
      "water"
    ],
    simipour: [
      "water"
    ],
    munna: [
      "psychic"
    ],
    musharna: [
      "psychic"
    ],
    pidove: [
      "normal",
      "flying"
    ],
    tranquill: [
      "normal",
      "flying"
    ],
    unfezant: [
      "normal",
      "flying"
    ],
    blitzle: [
      "electric"
    ],
    zebstrika: [
      "electric"
    ],
    roggenrola: [
      "rock"
    ],
    boldore: [
      "rock"
    ],
    gigalith: [
      "rock"
    ],
    woobat: [
      "psychic",
      "flying"
    ],
    swoobat: [
      "psychic",
      "flying"
    ],
    drilbur: [
      "ground"
    ],
    excadrill: [
      "ground",
      "steel"
    ],
    "mega-excadrill": [
      "ground",
      "steel"
    ],
    audino: [
      "normal"
    ],
    "mega-audino": [
      "normal",
      "fairy"
    ],
    timburr: [
      "fighting"
    ],
    gurdurr: [
      "fighting"
    ],
    conkeldurr: [
      "fighting"
    ],
    tympole: [
      "water"
    ],
    palpitoad: [
      "water",
      "ground"
    ],
    seismitoad: [
      "water",
      "ground"
    ],
    throh: [
      "fighting"
    ],
    sawk: [
      "fighting"
    ],
    sewaddle: [
      "bug",
      "grass"
    ],
    swadloon: [
      "bug",
      "grass"
    ],
    leavanny: [
      "bug",
      "grass"
    ],
    venipede: [
      "bug",
      "poison"
    ],
    whirlipede: [
      "bug",
      "poison"
    ],
    scolipede: [
      "bug",
      "poison"
    ],
    "mega-scolipede": [
      "bug",
      "poison"
    ],
    cottonee: [
      "grass",
      "fairy"
    ],
    whimsicott: [
      "grass",
      "fairy"
    ],
    petilil: [
      "grass"
    ],
    lilligant: [
      "grass"
    ],
    "lilligant-hisuian": [
      "grass",
      "fighting"
    ],
    "basculin-red-striped": [
      "water"
    ],
    sandile: [
      "ground",
      "dark"
    ],
    krokorok: [
      "ground",
      "dark"
    ],
    krookodile: [
      "ground",
      "dark"
    ],
    darumaka: [
      "fire"
    ],
    "darumaka-galarian": [
      "ice"
    ],
    darmanitan: [
      "fire"
    ],
    "darmanitan-galarian": [
      "ice"
    ],
    maractus: [
      "grass"
    ],
    dwebble: [
      "bug",
      "rock"
    ],
    crustle: [
      "bug",
      "rock"
    ],
    scraggy: [
      "dark",
      "fighting"
    ],
    scrafty: [
      "dark",
      "fighting"
    ],
    "mega-scrafty": [
      "dark",
      "fighting"
    ],
    sigilyph: [
      "psychic",
      "flying"
    ],
    yamask: [
      "ghost"
    ],
    "yamask-galarian": [
      "ground",
      "ghost"
    ],
    cofagrigus: [
      "ghost"
    ],
    tirtouga: [
      "water",
      "rock"
    ],
    carracosta: [
      "water",
      "rock"
    ],
    archen: [
      "rock",
      "flying"
    ],
    archeops: [
      "rock",
      "flying"
    ],
    trubbish: [
      "poison"
    ],
    garbodor: [
      "poison"
    ],
    "garbodor-gigantamax": [
      "poison"
    ],
    zorua: [
      "dark"
    ],
    "zorua-hisuian": [
      "normal",
      "ghost"
    ],
    zoroark: [
      "dark"
    ],
    "zoroark-hisuian": [
      "normal",
      "ghost"
    ],
    minccino: [
      "normal"
    ],
    cinccino: [
      "normal"
    ],
    gothita: [
      "psychic"
    ],
    gothorita: [
      "psychic"
    ],
    gothitelle: [
      "psychic"
    ],
    solosis: [
      "psychic"
    ],
    duosion: [
      "psychic"
    ],
    reuniclus: [
      "psychic"
    ],
    ducklett: [
      "water",
      "flying"
    ],
    swanna: [
      "water",
      "flying"
    ],
    vanillite: [
      "ice"
    ],
    vanillish: [
      "ice"
    ],
    vanilluxe: [
      "ice"
    ],
    deerling: [
      "normal",
      "grass"
    ],
    sawsbuck: [
      "normal",
      "grass"
    ],
    emolga: [
      "electric",
      "flying"
    ],
    karrablast: [
      "bug"
    ],
    escavalier: [
      "bug",
      "steel"
    ],
    foongus: [
      "grass",
      "poison"
    ],
    amoonguss: [
      "grass",
      "poison"
    ],
    frillish: [
      "water",
      "ghost"
    ],
    jellicent: [
      "water",
      "ghost"
    ],
    alomomola: [
      "water"
    ],
    joltik: [
      "bug",
      "electric"
    ],
    galvantula: [
      "bug",
      "electric"
    ],
    ferroseed: [
      "grass",
      "steel"
    ],
    ferrothorn: [
      "grass",
      "steel"
    ],
    klink: [
      "steel"
    ],
    klang: [
      "steel"
    ],
    klinklang: [
      "steel"
    ],
    tynamo: [
      "electric"
    ],
    eelektrik: [
      "electric"
    ],
    eelektross: [
      "electric"
    ],
    "mega-eelektross": [
      "electric"
    ],
    elgyem: [
      "psychic"
    ],
    beheeyem: [
      "psychic"
    ],
    litwick: [
      "ghost",
      "fire"
    ],
    lampent: [
      "ghost",
      "fire"
    ],
    chandelure: [
      "ghost",
      "fire"
    ],
    "mega-chandelure": [
      "ghost",
      "fire"
    ],
    axew: [
      "dragon"
    ],
    fraxure: [
      "dragon"
    ],
    haxorus: [
      "dragon"
    ],
    cubchoo: [
      "ice"
    ],
    beartic: [
      "ice"
    ],
    cryogonal: [
      "ice"
    ],
    shelmet: [
      "bug"
    ],
    accelgor: [
      "bug"
    ],
    stunfisk: [
      "ground",
      "electric"
    ],
    "stunfisk-galarian": [
      "ground",
      "steel"
    ],
    mienfoo: [
      "fighting"
    ],
    mienshao: [
      "fighting"
    ],
    druddigon: [
      "dragon"
    ],
    golett: [
      "ground",
      "ghost"
    ],
    golurk: [
      "ground",
      "ghost"
    ],
    "mega-golurk": [
      "ground",
      "ghost"
    ],
    pawniard: [
      "dark",
      "steel"
    ],
    bisharp: [
      "dark",
      "steel"
    ],
    bouffalant: [
      "normal"
    ],
    rufflet: [
      "normal",
      "flying"
    ],
    braviary: [
      "normal",
      "flying"
    ],
    braviaryhisuian: [
      "psychic",
      "flying"
    ],
    vullaby: [
      "dark",
      "flying"
    ],
    mandibuzz: [
      "dark",
      "flying"
    ],
    heatmor: [
      "fire"
    ],
    durant: [
      "bug",
      "steel"
    ],
    deino: [
      "dark",
      "dragon"
    ],
    zweilous: [
      "dark",
      "dragon"
    ],
    hydreigon: [
      "dark",
      "dragon"
    ],
    larvesta: [
      "bug",
      "fire"
    ],
    volcarona: [
      "bug",
      "fire"
    ],
    cobalion: [
      "steel",
      "fighting"
    ],
    terrakion: [
      "rock",
      "fighting"
    ],
    virizion: [
      "grass",
      "fighting"
    ],
    "tornadus-incarnate": [
      "flying"
    ],
    "tornadus-therian": [
      "flying"
    ],
    "thundurus-incarnate": [
      "electric",
      "flying"
    ],
    "thundurus-therian": [
      "electric",
      "flying"
    ],
    reshiram: [
      "dragon",
      "fire"
    ],
    zekrom: [
      "dragon",
      "electric"
    ],
    "landorus-incarnate": [
      "ground",
      "flying"
    ],
    "landorus-therian": [
      "ground",
      "flying"
    ],
    "black-kyurem": [
      "dragon",
      "ice"
    ],
    kyurem: [
      "dragon",
      "ice"
    ],
    "white-kyurem": [
      "dragon",
      "ice"
    ],
    keldeo: [
      "water",
      "fighting"
    ],
    "meloetta-aria": [
      "normal",
      "psychic"
    ],
    "meloetta-pirouette": [
      "normal",
      "fighting"
    ],
    genesect: [
      "bug",
      "steel"
    ],
    chespin: [
      "grass"
    ],
    quilladin: [
      "grass"
    ],
    chesnaught: [
      "grass",
      "fighting"
    ],
    "mega-chesnaught": [
      "grass",
      "fighting"
    ],
    fennekin: [
      "fire"
    ],
    braixen: [
      "fire"
    ],
    delphox: [
      "fire",
      "psychic"
    ],
    "mega-delphox": [
      "fire",
      "psychic"
    ],
    froakie: [
      "water"
    ],
    frogadier: [
      "water"
    ],
    "ash-greninja": [
      "water",
      "dark"
    ],
    greninja: [
      "water",
      "dark"
    ],
    "mega-greninja": [
      "water",
      "dark"
    ],
    bunnelby: [
      "normal"
    ],
    diggersby: [
      "normal",
      "ground"
    ],
    fletchling: [
      "normal",
      "flying"
    ],
    fletchinder: [
      "fire",
      "flying"
    ],
    talonflame: [
      "fire",
      "flying"
    ],
    scatterbug: [
      "bug"
    ],
    spewpa: [
      "bug"
    ],
    vivillon: [
      "bug",
      "flying"
    ],
    litleo: [
      "fire",
      "normal"
    ],
    pyroar: [
      "fire",
      "normal"
    ],
    "mega-pyroar": [
      "fire",
      "normal"
    ],
    flabebe: [
      "fairy"
    ],
    floette: [
      "fairy"
    ],
    "floette-eternal-flower": [
      "fairy"
    ],
    "mega-floette": [
      "fairy"
    ],
    florges: [
      "fairy"
    ],
    skiddo: [
      "grass"
    ],
    gogoat: [
      "grass"
    ],
    pancham: [
      "fighting"
    ],
    pangoro: [
      "fighting",
      "dark"
    ],
    furfrou: [
      "normal"
    ],
    espurr: [
      "psychic"
    ],
    "mega-meowstic": [
      "psychic"
    ],
    "meowstic-f": [
      "psychic"
    ],
    "meowstic-m": [
      "psychic"
    ],
    honedge: [
      "steel",
      "ghost"
    ],
    doublade: [
      "steel",
      "ghost"
    ],
    aegislash: [
      "steel",
      "ghost"
    ],
    spritzee: [
      "fairy"
    ],
    aromatisse: [
      "fairy"
    ],
    swirlix: [
      "fairy"
    ],
    slurpuff: [
      "fairy"
    ],
    inkay: [
      "dark",
      "psychic"
    ],
    malamar: [
      "dark",
      "psychic"
    ],
    "mega-malamar": [
      "dark",
      "psychic"
    ],
    binacle: [
      "rock",
      "water"
    ],
    barbaracle: [
      "rock",
      "water"
    ],
    "mega-barbaracle": [
      "rock",
      "fighting"
    ],
    skrelp: [
      "poison",
      "water"
    ],
    dragalge: [
      "poison",
      "dragon"
    ],
    "mega-dragalge": [
      "poison",
      "dragon"
    ],
    clauncher: [
      "water"
    ],
    clawitzer: [
      "water"
    ],
    helioptile: [
      "electric",
      "normal"
    ],
    heliolisk: [
      "electric",
      "normal"
    ],
    tyrunt: [
      "rock",
      "dragon"
    ],
    tyrantrum: [
      "rock",
      "dragon"
    ],
    amaura: [
      "rock",
      "ice"
    ],
    aurorus: [
      "rock",
      "ice"
    ],
    sylveon: [
      "fairy"
    ],
    hawlucha: [
      "fighting",
      "flying"
    ],
    "mega-hawlucha": [
      "fighting",
      "flying"
    ],
    dedenne: [
      "electric",
      "fairy"
    ],
    carbink: [
      "rock",
      "fairy"
    ],
    goomy: [
      "dragon"
    ],
    sliggoo: [
      "dragon"
    ],
    "sliggoo-hisuian": [
      "steel",
      "dragon"
    ],
    goodra: [
      "dragon"
    ],
    "goodra-hisuian": [
      "steel",
      "dragon"
    ],
    klefki: [
      "steel",
      "fairy"
    ],
    phantump: [
      "ghost",
      "grass"
    ],
    trevenant: [
      "ghost",
      "grass"
    ],
    pumpkaboo: [
      "ghost",
      "grass"
    ],
    gourgeist: [
      "ghost",
      "grass"
    ],
    bergmite: [
      "ice"
    ],
    avalugg: [
      "ice"
    ],
    "avalugg-hisuian": [
      "ice",
      "rock"
    ],
    noibat: [
      "flying",
      "dragon"
    ],
    noivern: [
      "flying",
      "dragon"
    ],
    xerneas: [
      "fairy"
    ],
    yveltal: [
      "dark",
      "flying"
    ],
    "mega-zygarde": [
      "dragon",
      "ground"
    ],
    "zygarde-10-forme": [
      "dragon",
      "ground"
    ],
    "zygarde-50-forme": [
      "dragon",
      "ground"
    ],
    "zygarde-complete-forme": [
      "dragon",
      "ground"
    ],
    diancie: [
      "rock",
      "fairy"
    ],
    "mega-diancie": [
      "rock",
      "fairy"
    ],
    "hoopa-confined": [
      "psychic",
      "ghost"
    ],
    "hoopa-unbound": [
      "psychic",
      "dark"
    ],
    volcanion: [
      "fire",
      "water"
    ],
    rowlet: [
      "grass",
      "flying"
    ],
    dartrix: [
      "grass",
      "flying"
    ],
    decidueye: [
      "grass",
      "ghost"
    ],
    "decidueye-hisuian": [
      "grass",
      "fighting"
    ],
    litten: [
      "fire"
    ],
    torracat: [
      "fire"
    ],
    incineroar: [
      "fire",
      "dark"
    ],
    popplio: [
      "water"
    ],
    brionne: [
      "water"
    ],
    primarina: [
      "water",
      "fairy"
    ],
    pikipek: [
      "normal",
      "flying"
    ],
    trumbeak: [
      "normal",
      "flying"
    ],
    toucannon: [
      "normal",
      "flying"
    ],
    yungoos: [
      "normal"
    ],
    gumshoos: [
      "normal"
    ],
    grubbin: [
      "bug"
    ],
    charjabug: [
      "bug",
      "electric"
    ],
    vikavolt: [
      "bug",
      "electric"
    ],
    crabrawler: [
      "fighting"
    ],
    crabominable: [
      "fighting",
      "ice"
    ],
    "mega-crabominable": [
      "fighting",
      "ice"
    ],
    "oricorio-baile": [
      "fire",
      "flying"
    ],
    "oricorio-pau": [
      "psychic",
      "flying"
    ],
    "oricorio-pom-pom": [
      "electric",
      "flying"
    ],
    "oricorio-sensu": [
      "ghost",
      "flying"
    ],
    cutiefly: [
      "bug",
      "fairy"
    ],
    ribombee: [
      "bug",
      "fairy"
    ],
    rockruff: [
      "rock"
    ],
    "lycanroc-dusk": [
      "rock"
    ],
    "lycanroc-midday": [
      "rock"
    ],
    "lycanroc-midnight": [
      "rock"
    ],
    "wishiwashi-school": [
      "water"
    ],
    mareanie: [
      "poison",
      "water"
    ],
    toxapex: [
      "poison",
      "water"
    ],
    mudbray: [
      "ground"
    ],
    mudsdale: [
      "ground"
    ],
    dewpider: [
      "water",
      "bug"
    ],
    araquanid: [
      "water",
      "bug"
    ],
    fomantis: [
      "grass"
    ],
    lurantis: [
      "grass"
    ],
    morelull: [
      "grass",
      "fairy"
    ],
    shiinotic: [
      "grass",
      "fairy"
    ],
    salandit: [
      "poison",
      "fire"
    ],
    salazzle: [
      "poison",
      "fire"
    ],
    stufful: [
      "normal",
      "fighting"
    ],
    bewear: [
      "normal",
      "fighting"
    ],
    bounsweet: [
      "grass"
    ],
    steenee: [
      "grass"
    ],
    tsareena: [
      "grass"
    ],
    comfey: [
      "fairy"
    ],
    oranguru: [
      "normal",
      "psychic"
    ],
    passimian: [
      "fighting"
    ],
    wimpod: [
      "bug",
      "water"
    ],
    golisopod: [
      "bug",
      "water"
    ],
    "mega-golisopod": [
      "bug",
      "steel"
    ],
    sandygast: [
      "ghost",
      "ground"
    ],
    palossand: [
      "ghost",
      "ground"
    ],
    pyukumuku: [
      "water"
    ],
    "type-null": [
      "normal"
    ],
    silvally: [
      "normal"
    ],
    "minior-core": [
      "rock",
      "flying"
    ],
    komala: [
      "normal"
    ],
    turtonator: [
      "fire",
      "dragon"
    ],
    togedemaru: [
      "electric",
      "steel"
    ],
    mimikyu: [
      "ghost",
      "fairy"
    ],
    bruxish: [
      "water",
      "psychic"
    ],
    drampa: [
      "normal",
      "dragon"
    ],
    "mega-drampa": [
      "normal",
      "dragon"
    ],
    dhelmise: [
      "ghost",
      "grass"
    ],
    "jangmo-o": [
      "dragon"
    ],
    "hakamo-o": [
      "dragon",
      "fighting"
    ],
    "kommo-o": [
      "dragon",
      "fighting"
    ],
    "tapu-koko": [
      "electric",
      "fairy"
    ],
    "tapu-lele": [
      "psychic",
      "fairy"
    ],
    "tapu-bulu": [
      "grass",
      "fairy"
    ],
    "tapu-fini": [
      "water",
      "fairy"
    ],
    cosmog: [
      "psychic"
    ],
    cosmoem: [
      "psychic"
    ],
    solgaleo: [
      "psychic",
      "steel"
    ],
    lunala: [
      "psychic",
      "ghost"
    ],
    nihilego: [
      "rock",
      "poison"
    ],
    buzzwole: [
      "bug",
      "fighting"
    ],
    pheromosa: [
      "bug",
      "fighting"
    ],
    xurkitree: [
      "electric"
    ],
    celesteela: [
      "steel",
      "flying"
    ],
    kartana: [
      "grass",
      "steel"
    ],
    guzzlord: [
      "dark",
      "dragon"
    ],
    necrozma: [
      "psychic"
    ],
    "necrozma-dawn-wings": [
      "psychic",
      "ghost"
    ],
    "necrozma-dusk-mane": [
      "psychic",
      "steel"
    ],
    "ultra-necrozma": [
      "psychic",
      "dragon"
    ],
    magearna: [
      "steel",
      "fairy"
    ],
    "mega-magearna": [
      "steel",
      "fairy"
    ],
    marshadow: [
      "fighting",
      "ghost"
    ],
    poipole: [
      "poison"
    ],
    naganadel: [
      "poison",
      "dragon"
    ],
    stakataka: [
      "rock",
      "steel"
    ],
    blacephalon: [
      "fire",
      "ghost"
    ],
    zeraora: [
      "electric"
    ],
    "mega-zeraora": [
      "electric"
    ],
    meltan: [
      "steel"
    ],
    melmetal: [
      "steel"
    ],
    "melmetal-gigantamax": [
      "steel"
    ],
    grookey: [
      "grass"
    ],
    thwackey: [
      "grass"
    ],
    rillaboom: [
      "grass"
    ],
    "rillaboom-gigantamax": [
      "grass"
    ],
    scorbunny: [
      "fire"
    ],
    raboot: [
      "fire"
    ],
    cinderace: [
      "fire"
    ],
    "cinderace-gigantamax": [
      "fire"
    ],
    sobble: [
      "water"
    ],
    drizzile: [
      "water"
    ],
    inteleon: [
      "water"
    ],
    "inteleon-gigantamax": [
      "water"
    ],
    skwovet: [
      "normal"
    ],
    greedent: [
      "normal"
    ],
    rookidee: [
      "flying"
    ],
    corvisquire: [
      "flying"
    ],
    corviknight: [
      "flying",
      "steel"
    ],
    "corviknight-gigantamax": [
      "flying",
      "steel"
    ],
    blipbug: [
      "bug"
    ],
    dottler: [
      "bug",
      "psychic"
    ],
    orbeetle: [
      "bug",
      "psychic"
    ],
    "orbeetle-gigantamax": [
      "bug",
      "psychic"
    ],
    nickit: [
      "dark"
    ],
    thievul: [
      "dark"
    ],
    gossifleur: [
      "grass"
    ],
    eldegoss: [
      "grass"
    ],
    wooloo: [
      "normal"
    ],
    dubwool: [
      "normal"
    ],
    chewtle: [
      "water"
    ],
    drednaw: [
      "water",
      "rock"
    ],
    "drednaw-gigantamax": [
      "water",
      "rock"
    ],
    yamper: [
      "electric"
    ],
    boltund: [
      "electric"
    ],
    rolycoly: [
      "rock"
    ],
    carkol: [
      "rock",
      "fire"
    ],
    coalossal: [
      "rock",
      "fire"
    ],
    "coalossal-gigantamax": [
      "rock",
      "fire"
    ],
    applin: [
      "grass",
      "dragon"
    ],
    flapple: [
      "grass",
      "dragon"
    ],
    "flapple-gigantamax": [
      "grass",
      "dragon"
    ],
    appletun: [
      "grass",
      "dragon"
    ],
    "appletun-gigantamax": [
      "grass",
      "dragon"
    ],
    silicobra: [
      "ground"
    ],
    sandaconda: [
      "ground"
    ],
    "sandaconda-gigantamax": [
      "ground"
    ],
    cramorant: [
      "flying",
      "water"
    ],
    arrokuda: [
      "water"
    ],
    barraskewda: [
      "water"
    ],
    toxel: [
      "electric",
      "poison"
    ],
    "toxtricity-gigantamax": [
      "electric",
      "poison"
    ],
    "toxtricity-high": [
      "electric",
      "poison"
    ],
    "toxtricity-low": [
      "electric",
      "poison"
    ],
    sizzlipede: [
      "fire",
      "bug"
    ],
    centiskorch: [
      "fire",
      "bug"
    ],
    "centiskorch-gigantamax": [
      "fire",
      "bug"
    ],
    clobbopus: [
      "fighting"
    ],
    grapploct: [
      "fighting"
    ],
    sinistea: [
      "ghost"
    ],
    polteageist: [
      "ghost"
    ],
    hatenna: [
      "psychic"
    ],
    hattrem: [
      "psychic"
    ],
    hatterene: [
      "psychic",
      "fairy"
    ],
    "hatterene-gigantamax": [
      "psychic",
      "fairy"
    ],
    impidimp: [
      "dark",
      "fairy"
    ],
    morgrem: [
      "dark",
      "fairy"
    ],
    grimmsnarl: [
      "dark",
      "fairy"
    ],
    "grimmsnarl-gigantamax": [
      "dark",
      "fairy"
    ],
    obstagoon: [
      "dark",
      "normal"
    ],
    perrserker: [
      "steel"
    ],
    cursola: [
      "ghost"
    ],
    sirfetchd: [
      "fighting"
    ],
    "mr-rime": [
      "ice",
      "psychic"
    ],
    runerigus: [
      "ground",
      "ghost"
    ],
    milcery: [
      "fairy"
    ],
    alcremie: [
      "fairy"
    ],
    "alcremie-gigantamax": [
      "fairy"
    ],
    falinks: [
      "fighting"
    ],
    "mega-falinks": [
      "fighting"
    ],
    pincurchin: [
      "electric"
    ],
    snom: [
      "ice",
      "bug"
    ],
    frosmoth: [
      "ice",
      "bug"
    ],
    stonjourner: [
      "rock"
    ],
    eiscue: [
      "ice"
    ],
    "indeedee-f": [
      "psychic",
      "normal"
    ],
    "indeedee-m": [
      "psychic",
      "normal"
    ],
    morpeko: [
      "electric",
      "dark"
    ],
    cufant: [
      "steel"
    ],
    copperajah: [
      "steel"
    ],
    "copperajah-gigantamax": [
      "steel"
    ],
    dracozolt: [
      "electric",
      "dragon"
    ],
    arctozolt: [
      "electric",
      "ice"
    ],
    dracovish: [
      "water",
      "dragon"
    ],
    arctovish: [
      "water",
      "ice"
    ],
    duraludon: [
      "steel",
      "dragon"
    ],
    "duraludon-gigantamax": [
      "steel",
      "dragon"
    ],
    dreepy: [
      "dragon",
      "ghost"
    ],
    drakloak: [
      "dragon",
      "ghost"
    ],
    dragapult: [
      "dragon",
      "ghost"
    ],
    "zacian-crowned-sword": [
      "fairy",
      "steel"
    ],
    "zacian-hero-of-many-battles": [
      "fairy"
    ],
    "zamazenta-crowned-shield": [
      "fighting",
      "steel"
    ],
    "zamazenta-hero-of-many-battles": [
      "fighting"
    ],
    eternatus: [
      "poison",
      "dragon"
    ],
    kubfu: [
      "fighting"
    ],
    "urshifu-rapid-strike": [
      "fighting",
      "water"
    ],
    "urshifu-rapid-strike-gigantamax": [
      "fighting",
      "water"
    ],
    "urshifu-single-strike": [
      "fighting",
      "dark"
    ],
    "urshifu-single-strike-gigantamax": [
      "fighting",
      "dark"
    ],
    zarude: [
      "dark",
      "grass"
    ],
    regieleki: [
      "electric"
    ],
    regidrago: [
      "dragon"
    ],
    glastrier: [
      "ice"
    ],
    spectrier: [
      "ghost"
    ],
    calyrex: [
      "psychic",
      "grass"
    ],
    "calyrex-ice-rider": [
      "psychic",
      "ice"
    ],
    "calyrex-shadow-rider": [
      "psychic",
      "ghost"
    ],
    wyrdeer: [
      "normal",
      "psychic"
    ],
    kleavor: [
      "bug",
      "rock"
    ],
    ursaluna: [
      "ground",
      "normal"
    ],
    "basculegion-f": [
      "water",
      "ghost"
    ],
    "basculegion-m": [
      "water",
      "ghost"
    ],
    sneasler: [
      "fighting",
      "poison"
    ],
    overqwil: [
      "dark",
      "poison"
    ],
    "enamorus-incarnate": [
      "fairy",
      "flying"
    ],
    "enamorus-therian": [
      "fairy",
      "flying"
    ],
    sprigatito: [
      "grass"
    ],
    floragato: [
      "grass"
    ],
    meowscarada: [
      "grass",
      "dark"
    ],
    fuecoco: [
      "fire"
    ],
    crocalor: [
      "fire"
    ],
    skeledirge: [
      "fire",
      "ghost"
    ],
    quaxly: [
      "water"
    ],
    quaxwell: [
      "water"
    ],
    quaquaval: [
      "water",
      "fighting"
    ],
    lechonk: [
      "normal"
    ],
    "oinkologne-f": [
      "normal"
    ],
    "oinkologne-m": [
      "normal"
    ],
    tarountula: [
      "bug"
    ],
    spidops: [
      "bug"
    ],
    nymble: [
      "bug"
    ],
    lokix: [
      "bug",
      "dark"
    ],
    pawmi: [
      "electric"
    ],
    pawmo: [
      "electric",
      "fighting"
    ],
    pawmot: [
      "electric",
      "fighting"
    ],
    tandemaus: [
      "normal"
    ],
    maushold: [
      "normal"
    ],
    fidough: [
      "fairy"
    ],
    dachsbun: [
      "fairy"
    ],
    smoliv: [
      "grass",
      "normal"
    ],
    dolliv: [
      "grass",
      "normal"
    ],
    arboliva: [
      "grass",
      "normal"
    ],
    squawkabilly: [
      "normal",
      "flying"
    ],
    nacli: [
      "rock"
    ],
    naclstack: [
      "rock"
    ],
    garganacl: [
      "rock"
    ],
    charcadet: [
      "fire"
    ],
    armarouge: [
      "fire",
      "psychic"
    ],
    ceruledge: [
      "fire",
      "ghost"
    ],
    tadbulb: [
      "electric"
    ],
    bellibolt: [
      "electric"
    ],
    wattrel: [
      "electric",
      "flying"
    ],
    kilowattrel: [
      "electric",
      "flying"
    ],
    maschiff: [
      "dark"
    ],
    mabosstiff: [
      "dark"
    ],
    shroodle: [
      "poison",
      "normal"
    ],
    grafaiai: [
      "poison",
      "normal"
    ],
    bramblin: [
      "grass",
      "ghost"
    ],
    brambleghast: [
      "grass",
      "ghost"
    ],
    toedscool: [
      "ground",
      "grass"
    ],
    toedscruel: [
      "ground",
      "grass"
    ],
    klawf: [
      "rock"
    ],
    capsakid: [
      "grass"
    ],
    scovillain: [
      "grass",
      "fire"
    ],
    "mega-scovillain": [
      "grass",
      "fire"
    ],
    rellor: [
      "bug"
    ],
    rabsca: [
      "bug",
      "psychic"
    ],
    flittle: [
      "psychic"
    ],
    espathra: [
      "psychic"
    ],
    tinkatink: [
      "fairy",
      "steel"
    ],
    tinkatuff: [
      "fairy",
      "steel"
    ],
    tinkaton: [
      "fairy",
      "steel"
    ],
    wiglett: [
      "water"
    ],
    wugtrio: [
      "water"
    ],
    bombirdier: [
      "flying",
      "dark"
    ],
    finizen: [
      "water"
    ],
    palafin: [
      "water"
    ],
    varoom: [
      "steel",
      "poison"
    ],
    revavroom: [
      "steel",
      "poison"
    ],
    cyclizar: [
      "dragon",
      "normal"
    ],
    orthworm: [
      "steel"
    ],
    glimmet: [
      "rock",
      "poison"
    ],
    glimmora: [
      "rock",
      "poison"
    ],
    "mega-glimmora": [
      "rock",
      "poison"
    ],
    greavard: [
      "ghost"
    ],
    houndstone: [
      "ghost"
    ],
    flamigo: [
      "flying",
      "fighting"
    ],
    cetoddle: [
      "ice"
    ],
    cetitan: [
      "ice"
    ],
    veluza: [
      "water",
      "psychic"
    ],
    dondozo: [
      "water"
    ],
    tatsugiri: [
      "dragon",
      "water"
    ],
    "mega-tatsugiri": [
      "dragon",
      "water"
    ],
    annihilape: [
      "fighting",
      "ghost"
    ],
    clodsire: [
      "poison",
      "ground"
    ],
    farigiraf: [
      "normal",
      "psychic"
    ],
    dudunsparce: [
      "normal"
    ],
    kingambit: [
      "dark",
      "steel"
    ],
    "great-tusk": [
      "ground",
      "fighting"
    ],
    "scream-tail": [
      "fairy",
      "psychic"
    ],
    "brute-bonnet": [
      "grass",
      "dark"
    ],
    "flutter-mane": [
      "ghost",
      "fairy"
    ],
    "slither-wing": [
      "bug",
      "fighting"
    ],
    "sandy-shocks": [
      "electric",
      "ground"
    ],
    "iron-treads": [
      "ground",
      "steel"
    ],
    "iron-bundle": [
      "ice",
      "water"
    ],
    "iron-hands": [
      "fighting",
      "electric"
    ],
    "iron-jugulis": [
      "dark",
      "flying"
    ],
    "iron-moth": [
      "fire",
      "poison"
    ],
    "iron-thorns": [
      "rock",
      "electric"
    ],
    frigibax: [
      "dragon",
      "ice"
    ],
    arctibax: [
      "dragon",
      "ice"
    ],
    baxcalibur: [
      "dragon",
      "ice"
    ],
    "mega-baxcalibur": [
      "dragon",
      "ice"
    ],
    gimmighoul: [
      "ghost"
    ],
    gholdengo: [
      "steel",
      "ghost"
    ],
    "wo-chien": [
      "dark",
      "grass"
    ],
    "chien-pao": [
      "dark",
      "ice"
    ],
    "ting-lu": [
      "dark",
      "ground"
    ],
    "chi-yu": [
      "dark",
      "fire"
    ],
    "roaring-moon": [
      "dragon",
      "dark"
    ],
    "iron-valiant": [
      "fairy",
      "fighting"
    ],
    koraidon: [
      "fighting",
      "dragon"
    ],
    miraidon: [
      "electric",
      "dragon"
    ],
    "walking-wake": [
      "water",
      "dragon"
    ],
    "iron-leaves": [
      "grass",
      "psychic"
    ],
    dipplin: [
      "grass",
      "dragon"
    ],
    poltchageist: [
      "grass",
      "ghost"
    ],
    sinistcha: [
      "grass",
      "ghost"
    ],
    okidogi: [
      "poison",
      "fighting"
    ],
    munkidori: [
      "poison",
      "psychic"
    ],
    fezandipiti: [
      "poison",
      "fairy"
    ],
    "ogerpon-cornerstone-mask": [
      "grass",
      "rock"
    ],
    "ogerpon-hearthflame-mask": [
      "grass",
      "fire"
    ],
    "ogerpon-teal-mask": [
      "grass"
    ],
    "ogerpon-wellspring-mask": [
      "grass",
      "water"
    ],
    archaludon: [
      "steel",
      "dragon"
    ],
    hydrapple: [
      "grass",
      "dragon"
    ],
    "gouging-fire": [
      "fire",
      "dragon"
    ],
    "raging-bolt": [
      "electric",
      "dragon"
    ],
    "iron-boulder": [
      "rock",
      "psychic"
    ],
    "iron-crown": [
      "steel",
      "psychic"
    ],
    terapagos: [
      "normal"
    ],
    "terapagos-terastal": [
      "normal"
    ],
    pecharunt: [
      "poison",
      "ghost"
    ],
    "ursaluna-blood-moon": [
      "ground",
      "normal"
    ]
  },
  byDex: {
    "1": [
      "grass",
      "poison"
    ],
    "2": [
      "grass",
      "poison"
    ],
    "3": [
      "grass",
      "poison"
    ],
    "4": [
      "fire"
    ],
    "5": [
      "fire"
    ],
    "6": [
      "fire",
      "flying"
    ],
    "7": [
      "water"
    ],
    "8": [
      "water"
    ],
    "9": [
      "water"
    ],
    "10": [
      "bug"
    ],
    "11": [
      "bug"
    ],
    "12": [
      "bug",
      "flying"
    ],
    "13": [
      "bug",
      "poison"
    ],
    "14": [
      "bug",
      "poison"
    ],
    "15": [
      "bug",
      "poison"
    ],
    "16": [
      "normal",
      "flying"
    ],
    "17": [
      "normal",
      "flying"
    ],
    "18": [
      "normal",
      "flying"
    ],
    "19": [
      "normal"
    ],
    "20": [
      "normal"
    ],
    "21": [
      "normal",
      "flying"
    ],
    "22": [
      "normal",
      "flying"
    ],
    "23": [
      "poison"
    ],
    "24": [
      "poison"
    ],
    "25": [
      "electric"
    ],
    "26": [
      "electric"
    ],
    "27": [
      "ground"
    ],
    "28": [
      "ground"
    ],
    "29": [
      "poison"
    ],
    "30": [
      "poison"
    ],
    "31": [
      "poison",
      "ground"
    ],
    "32": [
      "poison"
    ],
    "33": [
      "poison"
    ],
    "34": [
      "poison",
      "ground"
    ],
    "35": [
      "fairy"
    ],
    "36": [
      "fairy"
    ],
    "37": [
      "fire"
    ],
    "38": [
      "fire"
    ],
    "39": [
      "normal",
      "fairy"
    ],
    "40": [
      "normal",
      "fairy"
    ],
    "41": [
      "poison",
      "flying"
    ],
    "42": [
      "poison",
      "flying"
    ],
    "43": [
      "grass",
      "poison"
    ],
    "44": [
      "grass",
      "poison"
    ],
    "45": [
      "grass",
      "poison"
    ],
    "46": [
      "bug",
      "grass"
    ],
    "47": [
      "bug",
      "grass"
    ],
    "48": [
      "bug",
      "poison"
    ],
    "49": [
      "bug",
      "poison"
    ],
    "50": [
      "ground"
    ],
    "51": [
      "ground"
    ],
    "52": [
      "normal"
    ],
    "53": [
      "normal"
    ],
    "54": [
      "water"
    ],
    "55": [
      "water"
    ],
    "56": [
      "fighting"
    ],
    "57": [
      "fighting"
    ],
    "58": [
      "fire"
    ],
    "59": [
      "fire"
    ],
    "60": [
      "water"
    ],
    "61": [
      "water"
    ],
    "62": [
      "water",
      "fighting"
    ],
    "63": [
      "psychic"
    ],
    "64": [
      "psychic"
    ],
    "65": [
      "psychic"
    ],
    "66": [
      "fighting"
    ],
    "67": [
      "fighting"
    ],
    "68": [
      "fighting"
    ],
    "69": [
      "grass",
      "poison"
    ],
    "70": [
      "grass",
      "poison"
    ],
    "71": [
      "grass",
      "poison"
    ],
    "72": [
      "water",
      "poison"
    ],
    "73": [
      "water",
      "poison"
    ],
    "74": [
      "rock",
      "ground"
    ],
    "75": [
      "rock",
      "ground"
    ],
    "76": [
      "rock",
      "ground"
    ],
    "77": [
      "fire"
    ],
    "78": [
      "fire"
    ],
    "79": [
      "water",
      "psychic"
    ],
    "80": [
      "water",
      "psychic"
    ],
    "81": [
      "electric",
      "steel"
    ],
    "82": [
      "electric",
      "steel"
    ],
    "83": [
      "normal",
      "flying"
    ],
    "84": [
      "normal",
      "flying"
    ],
    "85": [
      "normal",
      "flying"
    ],
    "86": [
      "water"
    ],
    "87": [
      "water",
      "ice"
    ],
    "88": [
      "poison"
    ],
    "89": [
      "poison"
    ],
    "90": [
      "water"
    ],
    "91": [
      "water",
      "ice"
    ],
    "92": [
      "ghost",
      "poison"
    ],
    "93": [
      "ghost",
      "poison"
    ],
    "94": [
      "ghost",
      "poison"
    ],
    "95": [
      "rock",
      "ground"
    ],
    "96": [
      "psychic"
    ],
    "97": [
      "psychic"
    ],
    "98": [
      "water"
    ],
    "99": [
      "water"
    ],
    "100": [
      "electric"
    ],
    "101": [
      "electric"
    ],
    "102": [
      "grass",
      "psychic"
    ],
    "103": [
      "grass",
      "psychic"
    ],
    "104": [
      "ground"
    ],
    "105": [
      "ground"
    ],
    "106": [
      "fighting"
    ],
    "107": [
      "fighting"
    ],
    "108": [
      "normal"
    ],
    "109": [
      "poison"
    ],
    "110": [
      "poison"
    ],
    "111": [
      "ground",
      "rock"
    ],
    "112": [
      "ground",
      "rock"
    ],
    "113": [
      "normal"
    ],
    "114": [
      "grass"
    ],
    "115": [
      "normal"
    ],
    "116": [
      "water"
    ],
    "117": [
      "water"
    ],
    "118": [
      "water"
    ],
    "119": [
      "water"
    ],
    "120": [
      "water"
    ],
    "121": [
      "water",
      "psychic"
    ],
    "122": [
      "psychic",
      "fairy"
    ],
    "123": [
      "bug",
      "flying"
    ],
    "124": [
      "ice",
      "psychic"
    ],
    "125": [
      "electric"
    ],
    "126": [
      "fire"
    ],
    "127": [
      "bug"
    ],
    "128": [
      "normal"
    ],
    "129": [
      "water"
    ],
    "130": [
      "water",
      "flying"
    ],
    "131": [
      "water",
      "ice"
    ],
    "132": [
      "normal"
    ],
    "133": [
      "normal"
    ],
    "134": [
      "water"
    ],
    "135": [
      "electric"
    ],
    "136": [
      "fire"
    ],
    "137": [
      "normal"
    ],
    "138": [
      "rock",
      "water"
    ],
    "139": [
      "rock",
      "water"
    ],
    "140": [
      "rock",
      "water"
    ],
    "141": [
      "rock",
      "water"
    ],
    "142": [
      "rock",
      "flying"
    ],
    "143": [
      "normal"
    ],
    "144": [
      "ice",
      "flying"
    ],
    "145": [
      "electric",
      "flying"
    ],
    "146": [
      "fire",
      "flying"
    ],
    "147": [
      "dragon"
    ],
    "148": [
      "dragon"
    ],
    "149": [
      "dragon",
      "flying"
    ],
    "150": [
      "psychic"
    ],
    "151": [
      "psychic"
    ],
    "152": [
      "grass"
    ],
    "153": [
      "grass"
    ],
    "154": [
      "grass"
    ],
    "155": [
      "fire"
    ],
    "156": [
      "fire"
    ],
    "157": [
      "fire"
    ],
    "158": [
      "water"
    ],
    "159": [
      "water"
    ],
    "160": [
      "water"
    ],
    "161": [
      "normal"
    ],
    "162": [
      "normal"
    ],
    "163": [
      "normal",
      "flying"
    ],
    "164": [
      "normal",
      "flying"
    ],
    "165": [
      "bug",
      "flying"
    ],
    "166": [
      "bug",
      "flying"
    ],
    "167": [
      "bug",
      "poison"
    ],
    "168": [
      "bug",
      "poison"
    ],
    "169": [
      "poison",
      "flying"
    ],
    "170": [
      "water",
      "electric"
    ],
    "171": [
      "water",
      "electric"
    ],
    "172": [
      "electric"
    ],
    "173": [
      "fairy"
    ],
    "174": [
      "normal",
      "fairy"
    ],
    "175": [
      "fairy"
    ],
    "176": [
      "fairy",
      "flying"
    ],
    "177": [
      "psychic",
      "flying"
    ],
    "178": [
      "psychic",
      "flying"
    ],
    "179": [
      "electric"
    ],
    "180": [
      "electric"
    ],
    "181": [
      "electric"
    ],
    "182": [
      "grass"
    ],
    "183": [
      "water",
      "fairy"
    ],
    "184": [
      "water",
      "fairy"
    ],
    "185": [
      "rock"
    ],
    "186": [
      "water"
    ],
    "187": [
      "grass",
      "flying"
    ],
    "188": [
      "grass",
      "flying"
    ],
    "189": [
      "grass",
      "flying"
    ],
    "190": [
      "normal"
    ],
    "191": [
      "grass"
    ],
    "192": [
      "grass"
    ],
    "193": [
      "bug",
      "flying"
    ],
    "194": [
      "water",
      "ground"
    ],
    "195": [
      "water",
      "ground"
    ],
    "196": [
      "psychic"
    ],
    "197": [
      "dark"
    ],
    "198": [
      "dark",
      "flying"
    ],
    "199": [
      "water",
      "psychic"
    ],
    "200": [
      "ghost"
    ],
    "201": [
      "psychic"
    ],
    "202": [
      "psychic"
    ],
    "203": [
      "normal",
      "psychic"
    ],
    "204": [
      "bug"
    ],
    "205": [
      "bug",
      "steel"
    ],
    "206": [
      "normal"
    ],
    "207": [
      "ground",
      "flying"
    ],
    "208": [
      "steel",
      "ground"
    ],
    "209": [
      "fairy"
    ],
    "210": [
      "fairy"
    ],
    "211": [
      "water",
      "poison"
    ],
    "212": [
      "bug",
      "steel"
    ],
    "213": [
      "bug",
      "rock"
    ],
    "214": [
      "bug",
      "fighting"
    ],
    "215": [
      "dark",
      "ice"
    ],
    "216": [
      "normal"
    ],
    "217": [
      "normal"
    ],
    "218": [
      "fire"
    ],
    "219": [
      "fire",
      "rock"
    ],
    "220": [
      "ice",
      "ground"
    ],
    "221": [
      "ice",
      "ground"
    ],
    "222": [
      "water",
      "rock"
    ],
    "223": [
      "water"
    ],
    "224": [
      "water"
    ],
    "225": [
      "ice",
      "flying"
    ],
    "226": [
      "water",
      "flying"
    ],
    "227": [
      "steel",
      "flying"
    ],
    "228": [
      "dark",
      "fire"
    ],
    "229": [
      "dark",
      "fire"
    ],
    "230": [
      "water",
      "dragon"
    ],
    "231": [
      "ground"
    ],
    "232": [
      "ground"
    ],
    "233": [
      "normal"
    ],
    "234": [
      "normal"
    ],
    "235": [
      "normal"
    ],
    "236": [
      "fighting"
    ],
    "237": [
      "fighting"
    ],
    "238": [
      "ice",
      "psychic"
    ],
    "239": [
      "electric"
    ],
    "240": [
      "fire"
    ],
    "241": [
      "normal"
    ],
    "242": [
      "normal"
    ],
    "243": [
      "electric"
    ],
    "244": [
      "fire"
    ],
    "245": [
      "water"
    ],
    "246": [
      "rock",
      "ground"
    ],
    "247": [
      "rock",
      "ground"
    ],
    "248": [
      "rock",
      "dark"
    ],
    "249": [
      "psychic",
      "flying"
    ],
    "250": [
      "fire",
      "flying"
    ],
    "251": [
      "psychic",
      "grass"
    ],
    "252": [
      "grass"
    ],
    "253": [
      "grass"
    ],
    "254": [
      "grass"
    ],
    "255": [
      "fire"
    ],
    "256": [
      "fire",
      "fighting"
    ],
    "257": [
      "fire",
      "fighting"
    ],
    "258": [
      "water"
    ],
    "259": [
      "water",
      "ground"
    ],
    "260": [
      "water",
      "ground"
    ],
    "261": [
      "dark"
    ],
    "262": [
      "dark"
    ],
    "263": [
      "normal"
    ],
    "264": [
      "normal"
    ],
    "265": [
      "bug"
    ],
    "266": [
      "bug"
    ],
    "267": [
      "bug",
      "flying"
    ],
    "268": [
      "bug"
    ],
    "269": [
      "bug",
      "poison"
    ],
    "270": [
      "water",
      "grass"
    ],
    "271": [
      "water",
      "grass"
    ],
    "272": [
      "water",
      "grass"
    ],
    "273": [
      "grass"
    ],
    "274": [
      "grass",
      "dark"
    ],
    "275": [
      "grass",
      "dark"
    ],
    "276": [
      "normal",
      "flying"
    ],
    "277": [
      "normal",
      "flying"
    ],
    "278": [
      "water",
      "flying"
    ],
    "279": [
      "water",
      "flying"
    ],
    "280": [
      "psychic",
      "fairy"
    ],
    "281": [
      "psychic",
      "fairy"
    ],
    "282": [
      "psychic",
      "fairy"
    ],
    "283": [
      "bug",
      "water"
    ],
    "284": [
      "bug",
      "flying"
    ],
    "285": [
      "grass"
    ],
    "286": [
      "grass",
      "fighting"
    ],
    "287": [
      "normal"
    ],
    "288": [
      "normal"
    ],
    "289": [
      "normal"
    ],
    "290": [
      "bug",
      "ground"
    ],
    "291": [
      "bug",
      "flying"
    ],
    "292": [
      "bug",
      "ghost"
    ],
    "293": [
      "normal"
    ],
    "294": [
      "normal"
    ],
    "295": [
      "normal"
    ],
    "296": [
      "fighting"
    ],
    "297": [
      "fighting"
    ],
    "298": [
      "normal",
      "fairy"
    ],
    "299": [
      "rock"
    ],
    "300": [
      "normal"
    ],
    "301": [
      "normal"
    ],
    "302": [
      "dark",
      "ghost"
    ],
    "303": [
      "steel",
      "fairy"
    ],
    "304": [
      "steel",
      "rock"
    ],
    "305": [
      "steel",
      "rock"
    ],
    "306": [
      "steel",
      "rock"
    ],
    "307": [
      "fighting",
      "psychic"
    ],
    "308": [
      "fighting",
      "psychic"
    ],
    "309": [
      "electric"
    ],
    "310": [
      "electric"
    ],
    "311": [
      "electric"
    ],
    "312": [
      "electric"
    ],
    "313": [
      "bug"
    ],
    "314": [
      "bug"
    ],
    "315": [
      "grass",
      "poison"
    ],
    "316": [
      "poison"
    ],
    "317": [
      "poison"
    ],
    "318": [
      "water",
      "dark"
    ],
    "319": [
      "water",
      "dark"
    ],
    "320": [
      "water"
    ],
    "321": [
      "water"
    ],
    "322": [
      "fire",
      "ground"
    ],
    "323": [
      "fire",
      "ground"
    ],
    "324": [
      "fire"
    ],
    "325": [
      "psychic"
    ],
    "326": [
      "psychic"
    ],
    "327": [
      "normal"
    ],
    "328": [
      "ground"
    ],
    "329": [
      "ground",
      "dragon"
    ],
    "330": [
      "ground",
      "dragon"
    ],
    "331": [
      "grass"
    ],
    "332": [
      "grass",
      "dark"
    ],
    "333": [
      "normal",
      "flying"
    ],
    "334": [
      "dragon",
      "flying"
    ],
    "335": [
      "normal"
    ],
    "336": [
      "poison"
    ],
    "337": [
      "rock",
      "psychic"
    ],
    "338": [
      "rock",
      "psychic"
    ],
    "339": [
      "water",
      "ground"
    ],
    "340": [
      "water",
      "ground"
    ],
    "341": [
      "water"
    ],
    "342": [
      "water",
      "dark"
    ],
    "343": [
      "ground",
      "psychic"
    ],
    "344": [
      "ground",
      "psychic"
    ],
    "345": [
      "rock",
      "grass"
    ],
    "346": [
      "rock",
      "grass"
    ],
    "347": [
      "rock",
      "bug"
    ],
    "348": [
      "rock",
      "bug"
    ],
    "349": [
      "water"
    ],
    "350": [
      "water"
    ],
    "351": [
      "normal"
    ],
    "352": [
      "normal"
    ],
    "353": [
      "ghost"
    ],
    "354": [
      "ghost"
    ],
    "355": [
      "ghost"
    ],
    "356": [
      "ghost"
    ],
    "357": [
      "grass",
      "flying"
    ],
    "358": [
      "psychic"
    ],
    "359": [
      "dark"
    ],
    "360": [
      "psychic"
    ],
    "361": [
      "ice"
    ],
    "362": [
      "ice"
    ],
    "363": [
      "ice",
      "water"
    ],
    "364": [
      "ice",
      "water"
    ],
    "365": [
      "ice",
      "water"
    ],
    "366": [
      "water"
    ],
    "367": [
      "water"
    ],
    "368": [
      "water"
    ],
    "369": [
      "water",
      "rock"
    ],
    "370": [
      "water"
    ],
    "371": [
      "dragon"
    ],
    "372": [
      "dragon"
    ],
    "373": [
      "dragon",
      "flying"
    ],
    "374": [
      "steel",
      "psychic"
    ],
    "375": [
      "steel",
      "psychic"
    ],
    "376": [
      "steel",
      "psychic"
    ],
    "377": [
      "rock"
    ],
    "378": [
      "ice"
    ],
    "379": [
      "steel"
    ],
    "380": [
      "dragon",
      "psychic"
    ],
    "381": [
      "dragon",
      "psychic"
    ],
    "382": [
      "water"
    ],
    "383": [
      "ground"
    ],
    "384": [
      "dragon",
      "flying"
    ],
    "385": [
      "steel",
      "psychic"
    ],
    "386": [
      "psychic"
    ],
    "387": [
      "grass"
    ],
    "388": [
      "grass"
    ],
    "389": [
      "grass",
      "ground"
    ],
    "390": [
      "fire"
    ],
    "391": [
      "fire",
      "fighting"
    ],
    "392": [
      "fire",
      "fighting"
    ],
    "393": [
      "water"
    ],
    "394": [
      "water"
    ],
    "395": [
      "water",
      "steel"
    ],
    "396": [
      "normal",
      "flying"
    ],
    "397": [
      "normal",
      "flying"
    ],
    "398": [
      "normal",
      "flying"
    ],
    "399": [
      "normal"
    ],
    "400": [
      "normal",
      "water"
    ],
    "401": [
      "bug"
    ],
    "402": [
      "bug"
    ],
    "403": [
      "electric"
    ],
    "404": [
      "electric"
    ],
    "405": [
      "electric"
    ],
    "406": [
      "grass",
      "poison"
    ],
    "407": [
      "grass",
      "poison"
    ],
    "408": [
      "rock"
    ],
    "409": [
      "rock"
    ],
    "410": [
      "rock",
      "steel"
    ],
    "411": [
      "rock",
      "steel"
    ],
    "412": [
      "bug"
    ],
    "413": [
      "bug",
      "grass"
    ],
    "414": [
      "bug",
      "flying"
    ],
    "415": [
      "bug",
      "flying"
    ],
    "416": [
      "bug",
      "flying"
    ],
    "417": [
      "electric"
    ],
    "418": [
      "water"
    ],
    "419": [
      "water"
    ],
    "420": [
      "grass"
    ],
    "421": [
      "grass"
    ],
    "422": [
      "water"
    ],
    "423": [
      "water",
      "ground"
    ],
    "424": [
      "normal"
    ],
    "425": [
      "ghost",
      "flying"
    ],
    "426": [
      "ghost",
      "flying"
    ],
    "427": [
      "normal"
    ],
    "428": [
      "normal"
    ],
    "429": [
      "ghost"
    ],
    "430": [
      "dark",
      "flying"
    ],
    "431": [
      "normal"
    ],
    "432": [
      "normal"
    ],
    "433": [
      "psychic"
    ],
    "434": [
      "poison",
      "dark"
    ],
    "435": [
      "poison",
      "dark"
    ],
    "436": [
      "steel",
      "psychic"
    ],
    "437": [
      "steel",
      "psychic"
    ],
    "438": [
      "rock"
    ],
    "439": [
      "psychic",
      "fairy"
    ],
    "440": [
      "normal"
    ],
    "441": [
      "normal",
      "flying"
    ],
    "442": [
      "ghost",
      "dark"
    ],
    "443": [
      "dragon",
      "ground"
    ],
    "444": [
      "dragon",
      "ground"
    ],
    "445": [
      "dragon",
      "ground"
    ],
    "446": [
      "normal"
    ],
    "447": [
      "fighting"
    ],
    "448": [
      "fighting",
      "steel"
    ],
    "449": [
      "ground"
    ],
    "450": [
      "ground"
    ],
    "451": [
      "poison",
      "bug"
    ],
    "452": [
      "poison",
      "dark"
    ],
    "453": [
      "poison",
      "fighting"
    ],
    "454": [
      "poison",
      "fighting"
    ],
    "455": [
      "grass"
    ],
    "456": [
      "water"
    ],
    "457": [
      "water"
    ],
    "458": [
      "water",
      "flying"
    ],
    "459": [
      "grass",
      "ice"
    ],
    "460": [
      "grass",
      "ice"
    ],
    "461": [
      "dark",
      "ice"
    ],
    "462": [
      "electric",
      "steel"
    ],
    "463": [
      "normal"
    ],
    "464": [
      "ground",
      "rock"
    ],
    "465": [
      "grass"
    ],
    "466": [
      "electric"
    ],
    "467": [
      "fire"
    ],
    "468": [
      "fairy",
      "flying"
    ],
    "469": [
      "bug",
      "flying"
    ],
    "470": [
      "grass"
    ],
    "471": [
      "ice"
    ],
    "472": [
      "ground",
      "flying"
    ],
    "473": [
      "ice",
      "ground"
    ],
    "474": [
      "normal"
    ],
    "475": [
      "psychic",
      "fighting"
    ],
    "476": [
      "rock",
      "steel"
    ],
    "477": [
      "ghost"
    ],
    "478": [
      "ice",
      "ghost"
    ],
    "479": [
      "electric",
      "ghost"
    ],
    "480": [
      "psychic"
    ],
    "481": [
      "psychic"
    ],
    "482": [
      "psychic"
    ],
    "483": [
      "steel",
      "dragon"
    ],
    "484": [
      "water",
      "dragon"
    ],
    "485": [
      "fire",
      "steel"
    ],
    "486": [
      "normal"
    ],
    "487": [
      "ghost",
      "dragon"
    ],
    "488": [
      "psychic"
    ],
    "489": [
      "water"
    ],
    "490": [
      "water"
    ],
    "491": [
      "dark"
    ],
    "492": [
      "grass"
    ],
    "493": [
      "normal"
    ],
    "494": [
      "psychic",
      "fire"
    ],
    "495": [
      "grass"
    ],
    "496": [
      "grass"
    ],
    "497": [
      "grass"
    ],
    "498": [
      "fire"
    ],
    "499": [
      "fire",
      "fighting"
    ],
    "500": [
      "fire",
      "fighting"
    ],
    "501": [
      "water"
    ],
    "502": [
      "water"
    ],
    "503": [
      "water"
    ],
    "504": [
      "normal"
    ],
    "505": [
      "normal"
    ],
    "506": [
      "normal"
    ],
    "507": [
      "normal"
    ],
    "508": [
      "normal"
    ],
    "509": [
      "dark"
    ],
    "510": [
      "dark"
    ],
    "511": [
      "grass"
    ],
    "512": [
      "grass"
    ],
    "513": [
      "fire"
    ],
    "514": [
      "fire"
    ],
    "515": [
      "water"
    ],
    "516": [
      "water"
    ],
    "517": [
      "psychic"
    ],
    "518": [
      "psychic"
    ],
    "519": [
      "normal",
      "flying"
    ],
    "520": [
      "normal",
      "flying"
    ],
    "521": [
      "normal",
      "flying"
    ],
    "522": [
      "electric"
    ],
    "523": [
      "electric"
    ],
    "524": [
      "rock"
    ],
    "525": [
      "rock"
    ],
    "526": [
      "rock"
    ],
    "527": [
      "psychic",
      "flying"
    ],
    "528": [
      "psychic",
      "flying"
    ],
    "529": [
      "ground"
    ],
    "530": [
      "ground",
      "steel"
    ],
    "531": [
      "normal"
    ],
    "532": [
      "fighting"
    ],
    "533": [
      "fighting"
    ],
    "534": [
      "fighting"
    ],
    "535": [
      "water"
    ],
    "536": [
      "water",
      "ground"
    ],
    "537": [
      "water",
      "ground"
    ],
    "538": [
      "fighting"
    ],
    "539": [
      "fighting"
    ],
    "540": [
      "bug",
      "grass"
    ],
    "541": [
      "bug",
      "grass"
    ],
    "542": [
      "bug",
      "grass"
    ],
    "543": [
      "bug",
      "poison"
    ],
    "544": [
      "bug",
      "poison"
    ],
    "545": [
      "bug",
      "poison"
    ],
    "546": [
      "grass",
      "fairy"
    ],
    "547": [
      "grass",
      "fairy"
    ],
    "548": [
      "grass"
    ],
    "549": [
      "grass"
    ],
    "550": [
      "water"
    ],
    "551": [
      "ground",
      "dark"
    ],
    "552": [
      "ground",
      "dark"
    ],
    "553": [
      "ground",
      "dark"
    ],
    "554": [
      "fire"
    ],
    "555": [
      "fire"
    ],
    "556": [
      "grass"
    ],
    "557": [
      "bug",
      "rock"
    ],
    "558": [
      "bug",
      "rock"
    ],
    "559": [
      "dark",
      "fighting"
    ],
    "560": [
      "dark",
      "fighting"
    ],
    "561": [
      "psychic",
      "flying"
    ],
    "562": [
      "ghost"
    ],
    "563": [
      "ghost"
    ],
    "564": [
      "water",
      "rock"
    ],
    "565": [
      "water",
      "rock"
    ],
    "566": [
      "rock",
      "flying"
    ],
    "567": [
      "rock",
      "flying"
    ],
    "568": [
      "poison"
    ],
    "569": [
      "poison"
    ],
    "570": [
      "dark"
    ],
    "571": [
      "dark"
    ],
    "572": [
      "normal"
    ],
    "573": [
      "normal"
    ],
    "574": [
      "psychic"
    ],
    "575": [
      "psychic"
    ],
    "576": [
      "psychic"
    ],
    "577": [
      "psychic"
    ],
    "578": [
      "psychic"
    ],
    "579": [
      "psychic"
    ],
    "580": [
      "water",
      "flying"
    ],
    "581": [
      "water",
      "flying"
    ],
    "582": [
      "ice"
    ],
    "583": [
      "ice"
    ],
    "584": [
      "ice"
    ],
    "585": [
      "normal",
      "grass"
    ],
    "586": [
      "normal",
      "grass"
    ],
    "587": [
      "electric",
      "flying"
    ],
    "588": [
      "bug"
    ],
    "589": [
      "bug",
      "steel"
    ],
    "590": [
      "grass",
      "poison"
    ],
    "591": [
      "grass",
      "poison"
    ],
    "592": [
      "water",
      "ghost"
    ],
    "593": [
      "water",
      "ghost"
    ],
    "594": [
      "water"
    ],
    "595": [
      "bug",
      "electric"
    ],
    "596": [
      "bug",
      "electric"
    ],
    "597": [
      "grass",
      "steel"
    ],
    "598": [
      "grass",
      "steel"
    ],
    "599": [
      "steel"
    ],
    "600": [
      "steel"
    ],
    "601": [
      "steel"
    ],
    "602": [
      "electric"
    ],
    "603": [
      "electric"
    ],
    "604": [
      "electric"
    ],
    "605": [
      "psychic"
    ],
    "606": [
      "psychic"
    ],
    "607": [
      "ghost",
      "fire"
    ],
    "608": [
      "ghost",
      "fire"
    ],
    "609": [
      "ghost",
      "fire"
    ],
    "610": [
      "dragon"
    ],
    "611": [
      "dragon"
    ],
    "612": [
      "dragon"
    ],
    "613": [
      "ice"
    ],
    "614": [
      "ice"
    ],
    "615": [
      "ice"
    ],
    "616": [
      "bug"
    ],
    "617": [
      "bug"
    ],
    "618": [
      "ground",
      "electric"
    ],
    "619": [
      "fighting"
    ],
    "620": [
      "fighting"
    ],
    "621": [
      "dragon"
    ],
    "622": [
      "ground",
      "ghost"
    ],
    "623": [
      "ground",
      "ghost"
    ],
    "624": [
      "dark",
      "steel"
    ],
    "625": [
      "dark",
      "steel"
    ],
    "626": [
      "normal"
    ],
    "627": [
      "normal",
      "flying"
    ],
    "628": [
      "normal",
      "flying"
    ],
    "629": [
      "dark",
      "flying"
    ],
    "630": [
      "dark",
      "flying"
    ],
    "631": [
      "fire"
    ],
    "632": [
      "bug",
      "steel"
    ],
    "633": [
      "dark",
      "dragon"
    ],
    "634": [
      "dark",
      "dragon"
    ],
    "635": [
      "dark",
      "dragon"
    ],
    "636": [
      "bug",
      "fire"
    ],
    "637": [
      "bug",
      "fire"
    ],
    "638": [
      "steel",
      "fighting"
    ],
    "639": [
      "rock",
      "fighting"
    ],
    "640": [
      "grass",
      "fighting"
    ],
    "641": [
      "flying"
    ],
    "642": [
      "electric",
      "flying"
    ],
    "643": [
      "dragon",
      "fire"
    ],
    "644": [
      "dragon",
      "electric"
    ],
    "645": [
      "ground",
      "flying"
    ],
    "646": [
      "dragon",
      "ice"
    ],
    "647": [
      "water",
      "fighting"
    ],
    "648": [
      "normal",
      "psychic"
    ],
    "649": [
      "bug",
      "steel"
    ],
    "650": [
      "grass"
    ],
    "651": [
      "grass"
    ],
    "652": [
      "grass",
      "fighting"
    ],
    "653": [
      "fire"
    ],
    "654": [
      "fire"
    ],
    "655": [
      "fire",
      "psychic"
    ],
    "656": [
      "water"
    ],
    "657": [
      "water"
    ],
    "658": [
      "water",
      "dark"
    ],
    "659": [
      "normal"
    ],
    "660": [
      "normal",
      "ground"
    ],
    "661": [
      "normal",
      "flying"
    ],
    "662": [
      "fire",
      "flying"
    ],
    "663": [
      "fire",
      "flying"
    ],
    "664": [
      "bug"
    ],
    "665": [
      "bug"
    ],
    "666": [
      "bug",
      "flying"
    ],
    "667": [
      "fire",
      "normal"
    ],
    "668": [
      "fire",
      "normal"
    ],
    "669": [
      "fairy"
    ],
    "670": [
      "fairy"
    ],
    "671": [
      "fairy"
    ],
    "672": [
      "grass"
    ],
    "673": [
      "grass"
    ],
    "674": [
      "fighting"
    ],
    "675": [
      "fighting",
      "dark"
    ],
    "676": [
      "normal"
    ],
    "677": [
      "psychic"
    ],
    "678": [
      "psychic"
    ],
    "679": [
      "steel",
      "ghost"
    ],
    "680": [
      "steel",
      "ghost"
    ],
    "681": [
      "steel",
      "ghost"
    ],
    "682": [
      "fairy"
    ],
    "683": [
      "fairy"
    ],
    "684": [
      "fairy"
    ],
    "685": [
      "fairy"
    ],
    "686": [
      "dark",
      "psychic"
    ],
    "687": [
      "dark",
      "psychic"
    ],
    "688": [
      "rock",
      "water"
    ],
    "689": [
      "rock",
      "water"
    ],
    "690": [
      "poison",
      "water"
    ],
    "691": [
      "poison",
      "dragon"
    ],
    "692": [
      "water"
    ],
    "693": [
      "water"
    ],
    "694": [
      "electric",
      "normal"
    ],
    "695": [
      "electric",
      "normal"
    ],
    "696": [
      "rock",
      "dragon"
    ],
    "697": [
      "rock",
      "dragon"
    ],
    "698": [
      "rock",
      "ice"
    ],
    "699": [
      "rock",
      "ice"
    ],
    "700": [
      "fairy"
    ],
    "701": [
      "fighting",
      "flying"
    ],
    "702": [
      "electric",
      "fairy"
    ],
    "703": [
      "rock",
      "fairy"
    ],
    "704": [
      "dragon"
    ],
    "705": [
      "dragon"
    ],
    "706": [
      "dragon"
    ],
    "707": [
      "steel",
      "fairy"
    ],
    "708": [
      "ghost",
      "grass"
    ],
    "709": [
      "ghost",
      "grass"
    ],
    "710": [
      "ghost",
      "grass"
    ],
    "711": [
      "ghost",
      "grass"
    ],
    "712": [
      "ice"
    ],
    "713": [
      "ice"
    ],
    "714": [
      "flying",
      "dragon"
    ],
    "715": [
      "flying",
      "dragon"
    ],
    "716": [
      "fairy"
    ],
    "717": [
      "dark",
      "flying"
    ],
    "718": [
      "dragon",
      "ground"
    ],
    "719": [
      "rock",
      "fairy"
    ],
    "720": [
      "psychic",
      "ghost"
    ],
    "721": [
      "fire",
      "water"
    ],
    "722": [
      "grass",
      "flying"
    ],
    "723": [
      "grass",
      "flying"
    ],
    "724": [
      "grass",
      "ghost"
    ],
    "725": [
      "fire"
    ],
    "726": [
      "fire"
    ],
    "727": [
      "fire",
      "dark"
    ],
    "728": [
      "water"
    ],
    "729": [
      "water"
    ],
    "730": [
      "water",
      "fairy"
    ],
    "731": [
      "normal",
      "flying"
    ],
    "732": [
      "normal",
      "flying"
    ],
    "733": [
      "normal",
      "flying"
    ],
    "734": [
      "normal"
    ],
    "735": [
      "normal"
    ],
    "736": [
      "bug"
    ],
    "737": [
      "bug",
      "electric"
    ],
    "738": [
      "bug",
      "electric"
    ],
    "739": [
      "fighting"
    ],
    "740": [
      "fighting",
      "ice"
    ],
    "741": [
      "fire",
      "flying"
    ],
    "742": [
      "bug",
      "fairy"
    ],
    "743": [
      "bug",
      "fairy"
    ],
    "744": [
      "rock"
    ],
    "745": [
      "rock"
    ],
    "746": [
      "water"
    ],
    "747": [
      "poison",
      "water"
    ],
    "748": [
      "poison",
      "water"
    ],
    "749": [
      "ground"
    ],
    "750": [
      "ground"
    ],
    "751": [
      "water",
      "bug"
    ],
    "752": [
      "water",
      "bug"
    ],
    "753": [
      "grass"
    ],
    "754": [
      "grass"
    ],
    "755": [
      "grass",
      "fairy"
    ],
    "756": [
      "grass",
      "fairy"
    ],
    "757": [
      "poison",
      "fire"
    ],
    "758": [
      "poison",
      "fire"
    ],
    "759": [
      "normal",
      "fighting"
    ],
    "760": [
      "normal",
      "fighting"
    ],
    "761": [
      "grass"
    ],
    "762": [
      "grass"
    ],
    "763": [
      "grass"
    ],
    "764": [
      "fairy"
    ],
    "765": [
      "normal",
      "psychic"
    ],
    "766": [
      "fighting"
    ],
    "767": [
      "bug",
      "water"
    ],
    "768": [
      "bug",
      "water"
    ],
    "769": [
      "ghost",
      "ground"
    ],
    "770": [
      "ghost",
      "ground"
    ],
    "771": [
      "water"
    ],
    "772": [
      "normal"
    ],
    "773": [
      "normal"
    ],
    "774": [
      "rock",
      "flying"
    ],
    "775": [
      "normal"
    ],
    "776": [
      "fire",
      "dragon"
    ],
    "777": [
      "electric",
      "steel"
    ],
    "778": [
      "ghost",
      "fairy"
    ],
    "779": [
      "water",
      "psychic"
    ],
    "780": [
      "normal",
      "dragon"
    ],
    "781": [
      "ghost",
      "grass"
    ],
    "782": [
      "dragon"
    ],
    "783": [
      "dragon",
      "fighting"
    ],
    "784": [
      "dragon",
      "fighting"
    ],
    "785": [
      "electric",
      "fairy"
    ],
    "786": [
      "psychic",
      "fairy"
    ],
    "787": [
      "grass",
      "fairy"
    ],
    "788": [
      "water",
      "fairy"
    ],
    "789": [
      "psychic"
    ],
    "790": [
      "psychic"
    ],
    "791": [
      "psychic",
      "steel"
    ],
    "792": [
      "psychic",
      "ghost"
    ],
    "793": [
      "rock",
      "poison"
    ],
    "794": [
      "bug",
      "fighting"
    ],
    "795": [
      "bug",
      "fighting"
    ],
    "796": [
      "electric"
    ],
    "797": [
      "steel",
      "flying"
    ],
    "798": [
      "grass",
      "steel"
    ],
    "799": [
      "dark",
      "dragon"
    ],
    "800": [
      "psychic"
    ],
    "801": [
      "steel",
      "fairy"
    ],
    "802": [
      "fighting",
      "ghost"
    ],
    "803": [
      "poison"
    ],
    "804": [
      "poison",
      "dragon"
    ],
    "805": [
      "rock",
      "steel"
    ],
    "806": [
      "fire",
      "ghost"
    ],
    "807": [
      "electric"
    ],
    "808": [
      "steel"
    ],
    "809": [
      "steel"
    ],
    "810": [
      "grass"
    ],
    "811": [
      "grass"
    ],
    "812": [
      "grass"
    ],
    "813": [
      "fire"
    ],
    "814": [
      "fire"
    ],
    "815": [
      "fire"
    ],
    "816": [
      "water"
    ],
    "817": [
      "water"
    ],
    "818": [
      "water"
    ],
    "819": [
      "normal"
    ],
    "820": [
      "normal"
    ],
    "821": [
      "flying"
    ],
    "822": [
      "flying"
    ],
    "823": [
      "flying",
      "steel"
    ],
    "824": [
      "bug"
    ],
    "825": [
      "bug",
      "psychic"
    ],
    "826": [
      "bug",
      "psychic"
    ],
    "827": [
      "dark"
    ],
    "828": [
      "dark"
    ],
    "829": [
      "grass"
    ],
    "830": [
      "grass"
    ],
    "831": [
      "normal"
    ],
    "832": [
      "normal"
    ],
    "833": [
      "water"
    ],
    "834": [
      "water",
      "rock"
    ],
    "835": [
      "electric"
    ],
    "836": [
      "electric"
    ],
    "837": [
      "rock"
    ],
    "838": [
      "rock",
      "fire"
    ],
    "839": [
      "rock",
      "fire"
    ],
    "840": [
      "grass",
      "dragon"
    ],
    "841": [
      "grass",
      "dragon"
    ],
    "842": [
      "grass",
      "dragon"
    ],
    "843": [
      "ground"
    ],
    "844": [
      "ground"
    ],
    "845": [
      "flying",
      "water"
    ],
    "846": [
      "water"
    ],
    "847": [
      "water"
    ],
    "848": [
      "electric",
      "poison"
    ],
    "849": [
      "electric",
      "poison"
    ],
    "850": [
      "fire",
      "bug"
    ],
    "851": [
      "fire",
      "bug"
    ],
    "852": [
      "fighting"
    ],
    "853": [
      "fighting"
    ],
    "854": [
      "ghost"
    ],
    "855": [
      "ghost"
    ],
    "856": [
      "psychic"
    ],
    "857": [
      "psychic"
    ],
    "858": [
      "psychic",
      "fairy"
    ],
    "859": [
      "dark",
      "fairy"
    ],
    "860": [
      "dark",
      "fairy"
    ],
    "861": [
      "dark",
      "fairy"
    ],
    "862": [
      "dark",
      "normal"
    ],
    "863": [
      "steel"
    ],
    "864": [
      "ghost"
    ],
    "865": [
      "fighting"
    ],
    "866": [
      "ice",
      "psychic"
    ],
    "867": [
      "ground",
      "ghost"
    ],
    "868": [
      "fairy"
    ],
    "869": [
      "fairy"
    ],
    "870": [
      "fighting"
    ],
    "871": [
      "electric"
    ],
    "872": [
      "ice",
      "bug"
    ],
    "873": [
      "ice",
      "bug"
    ],
    "874": [
      "rock"
    ],
    "875": [
      "ice"
    ],
    "876": [
      "psychic",
      "normal"
    ],
    "877": [
      "electric",
      "dark"
    ],
    "878": [
      "steel"
    ],
    "879": [
      "steel"
    ],
    "880": [
      "electric",
      "dragon"
    ],
    "881": [
      "electric",
      "ice"
    ],
    "882": [
      "water",
      "dragon"
    ],
    "883": [
      "water",
      "ice"
    ],
    "884": [
      "steel",
      "dragon"
    ],
    "885": [
      "dragon",
      "ghost"
    ],
    "886": [
      "dragon",
      "ghost"
    ],
    "887": [
      "dragon",
      "ghost"
    ],
    "888": [
      "fairy"
    ],
    "889": [
      "fighting"
    ],
    "890": [
      "poison",
      "dragon"
    ],
    "891": [
      "fighting"
    ],
    "892": [
      "fighting",
      "dark"
    ],
    "893": [
      "dark",
      "grass"
    ],
    "894": [
      "electric"
    ],
    "895": [
      "dragon"
    ],
    "896": [
      "ice"
    ],
    "897": [
      "ghost"
    ],
    "898": [
      "psychic",
      "grass"
    ],
    "899": [
      "normal",
      "psychic"
    ],
    "900": [
      "bug",
      "rock"
    ],
    "901": [
      "ground",
      "normal"
    ],
    "902": [
      "water",
      "ghost"
    ],
    "903": [
      "fighting",
      "poison"
    ],
    "904": [
      "dark",
      "poison"
    ],
    "905": [
      "fairy",
      "flying"
    ],
    "906": [
      "grass"
    ],
    "907": [
      "grass"
    ],
    "908": [
      "grass",
      "dark"
    ],
    "909": [
      "fire"
    ],
    "910": [
      "fire"
    ],
    "911": [
      "fire",
      "ghost"
    ],
    "912": [
      "water"
    ],
    "913": [
      "water"
    ],
    "914": [
      "water",
      "fighting"
    ],
    "915": [
      "normal"
    ],
    "916": [
      "normal"
    ],
    "917": [
      "bug"
    ],
    "918": [
      "bug"
    ],
    "919": [
      "bug"
    ],
    "920": [
      "bug",
      "dark"
    ],
    "921": [
      "electric"
    ],
    "922": [
      "electric",
      "fighting"
    ],
    "923": [
      "electric",
      "fighting"
    ],
    "924": [
      "normal"
    ],
    "925": [
      "normal"
    ],
    "926": [
      "fairy"
    ],
    "927": [
      "fairy"
    ],
    "928": [
      "grass",
      "normal"
    ],
    "929": [
      "grass",
      "normal"
    ],
    "930": [
      "grass",
      "normal"
    ],
    "931": [
      "normal",
      "flying"
    ],
    "932": [
      "rock"
    ],
    "933": [
      "rock"
    ],
    "934": [
      "rock"
    ],
    "935": [
      "fire"
    ],
    "936": [
      "fire",
      "psychic"
    ],
    "937": [
      "fire",
      "ghost"
    ],
    "938": [
      "electric"
    ],
    "939": [
      "electric"
    ],
    "940": [
      "electric",
      "flying"
    ],
    "941": [
      "electric",
      "flying"
    ],
    "942": [
      "dark"
    ],
    "943": [
      "dark"
    ],
    "944": [
      "poison",
      "normal"
    ],
    "945": [
      "poison",
      "normal"
    ],
    "946": [
      "grass",
      "ghost"
    ],
    "947": [
      "grass",
      "ghost"
    ],
    "948": [
      "ground",
      "grass"
    ],
    "949": [
      "ground",
      "grass"
    ],
    "950": [
      "rock"
    ],
    "951": [
      "grass"
    ],
    "952": [
      "grass",
      "fire"
    ],
    "953": [
      "bug"
    ],
    "954": [
      "bug",
      "psychic"
    ],
    "955": [
      "psychic"
    ],
    "956": [
      "psychic"
    ],
    "957": [
      "fairy",
      "steel"
    ],
    "958": [
      "fairy",
      "steel"
    ],
    "959": [
      "fairy",
      "steel"
    ],
    "960": [
      "water"
    ],
    "961": [
      "water"
    ],
    "962": [
      "flying",
      "dark"
    ],
    "963": [
      "water"
    ],
    "964": [
      "water"
    ],
    "965": [
      "steel",
      "poison"
    ],
    "966": [
      "steel",
      "poison"
    ],
    "967": [
      "dragon",
      "normal"
    ],
    "968": [
      "steel"
    ],
    "969": [
      "rock",
      "poison"
    ],
    "970": [
      "rock",
      "poison"
    ],
    "971": [
      "ghost"
    ],
    "972": [
      "ghost"
    ],
    "973": [
      "flying",
      "fighting"
    ],
    "974": [
      "ice"
    ],
    "975": [
      "ice"
    ],
    "976": [
      "water",
      "psychic"
    ],
    "977": [
      "water"
    ],
    "978": [
      "dragon",
      "water"
    ],
    "979": [
      "fighting",
      "ghost"
    ],
    "980": [
      "poison",
      "ground"
    ],
    "981": [
      "normal",
      "psychic"
    ],
    "982": [
      "normal"
    ],
    "983": [
      "dark",
      "steel"
    ],
    "984": [
      "ground",
      "fighting"
    ],
    "985": [
      "fairy",
      "psychic"
    ],
    "986": [
      "grass",
      "dark"
    ],
    "987": [
      "ghost",
      "fairy"
    ],
    "988": [
      "bug",
      "fighting"
    ],
    "989": [
      "electric",
      "ground"
    ],
    "990": [
      "ground",
      "steel"
    ],
    "991": [
      "ice",
      "water"
    ],
    "992": [
      "fighting",
      "electric"
    ],
    "993": [
      "dark",
      "flying"
    ],
    "994": [
      "fire",
      "poison"
    ],
    "995": [
      "rock",
      "electric"
    ],
    "996": [
      "dragon",
      "ice"
    ],
    "997": [
      "dragon",
      "ice"
    ],
    "998": [
      "dragon",
      "ice"
    ],
    "999": [
      "ghost"
    ],
    "1000": [
      "steel",
      "ghost"
    ],
    "1001": [
      "dark",
      "grass"
    ],
    "1002": [
      "dark",
      "ice"
    ],
    "1003": [
      "dark",
      "ground"
    ],
    "1004": [
      "dark",
      "fire"
    ],
    "1005": [
      "dragon",
      "dark"
    ],
    "1006": [
      "fairy",
      "fighting"
    ],
    "1007": [
      "fighting",
      "dragon"
    ],
    "1008": [
      "electric",
      "dragon"
    ],
    "1009": [
      "water",
      "dragon"
    ],
    "1010": [
      "grass",
      "psychic"
    ],
    "1011": [
      "grass",
      "dragon"
    ],
    "1012": [
      "grass",
      "ghost"
    ],
    "1013": [
      "grass",
      "ghost"
    ],
    "1014": [
      "poison",
      "fighting"
    ],
    "1015": [
      "poison",
      "psychic"
    ],
    "1016": [
      "poison",
      "fairy"
    ],
    "1017": [
      "grass"
    ],
    "1018": [
      "steel",
      "dragon"
    ],
    "1019": [
      "grass",
      "dragon"
    ],
    "1020": [
      "fire",
      "dragon"
    ],
    "1021": [
      "electric",
      "dragon"
    ],
    "1022": [
      "rock",
      "psychic"
    ],
    "1023": [
      "steel",
      "psychic"
    ],
    "1024": [
      "normal"
    ],
    "1025": [
      "poison",
      "ghost"
    ]
  }
};

// data/background-catalog.json
var background_catalog_default = {
  byType: {
    water: "water",
    fire: "fire",
    ice: "ice",
    flying: "fly",
    grass: "leaf-bug",
    bug: "leaf-bug",
    fighting: "fight",
    ground: "ground",
    rock: "ground",
    poison: "poison",
    steel: "steel",
    ghost: "ghost",
    dark: "dark",
    fairy: "fairy",
    normal: "normal",
    dragon: "dragon",
    psychic: "psychic",
    electric: "electric"
  },
  bySlug: {
    zapdos: "special/zapdos",
    articuno: "special/articuno",
    moltres: "special/moltres",
    raikou: "special/raikou",
    entei: "special/entei",
    suicune: "special/suicune",
    lugia: "special/lugia",
    "ho-oh": "special/ho-oh",
    latias: "special/latias-latios",
    latios: "special/latias-latios",
    "mega-latias": "special/latias-latios",
    "mega-latios": "special/latias-latios",
    kyogre: "special/kyogre",
    "primal-kyogre": "special/kyogre",
    groudon: "special/groudon",
    "primal-groudon": "special/groudon",
    rayquaza: "special/rayquaza",
    "mega-rayquaza": "special/rayquaza",
    jirachi: "special/jirachi",
    arceus: "special/arceus",
    celebi: "special/celebi",
    cresselia: "special/cresselia",
    darkrai: "special/darkrai",
    "mega-darkrai": "special/darkrai",
    deoxys: "special/deoxys",
    "deoxys-attack-forme": "special/deoxys",
    "deoxys-defense-forme": "special/deoxys",
    "deoxys-speed-forme": "special/deoxys",
    dialga: "special/dialga",
    diancie: "special/diancie",
    "mega-diancie": "special/diancie",
    genesect: "special/genesect",
    "giratina-another-forme": "special/giratina",
    "giratina-origin-forme": "special/giratina",
    "hoopa-confined": "special/hoopa-confined",
    "hoopa-unbound": "special/hoopa-confined",
    manaphy: "special/manaphy-phione",
    phione: "special/manaphy-phione",
    "meloetta-aria": "special/meloetta-aria",
    "meloetta-pirouette": "special/meloetta-pirouette",
    mewtwo: "special/mewtwo",
    "mega-mewtwo-x": "special/mewtwo",
    "mega-mewtwo-y": "special/mewtwo",
    palkia: "special/palkia",
    regigigas: "special/regigigas",
    victini: "special/victini",
    zarude: "special/zarude",
    cosmog: "special/ultra-beast",
    cosmoem: "special/ultra-beast",
    nihilego: "special/ultra-beast",
    buzzwole: "special/ultra-beast",
    pheromosa: "special/ultra-beast",
    xurkitree: "special/ultra-beast",
    celesteela: "special/ultra-beast",
    kartana: "special/ultra-beast",
    guzzlord: "special/ultra-beast",
    poipole: "special/ultra-beast",
    naganadel: "special/ultra-beast",
    stakataka: "special/ultra-beast",
    blacephalon: "special/ultra-beast",
    regice: "special/regice",
    regirock: "special/regirock",
    registeel: "special/registeel",
    "shaymin-land-forme": "special/shaymin",
    "shaymin-sky-forme": "special/shaymin",
    "ultra-necrozma": "special/ultranecrozma",
    xerneas: "special/xerneas",
    yveltal: "special/yveltal",
    uxie: "special/uxie-mesprit-azelf",
    mesprit: "special/uxie-mesprit-azelf",
    azelf: "special/uxie-mesprit-azelf",
    zeraora: "special/zeraora",
    "mega-zeraora": "special/zeraora",
    cobalion: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    terrakion: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    virizion: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    keldeo: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    "keldeo-resolute": "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
    lunala: "special/lunala",
    "necrozma-dawn-wings": "special/lunala",
    marshadow: "special/marshadow",
    solgaleo: "special/solgaleo",
    "necrozma-dusk-mane": "special/solgaleo",
    koraidon: "special/koraidon",
    kyurem: "special/kyurem",
    "black-kyurem": "special/kyurem",
    "white-kyurem": "special/kyurem",
    mew: "special/mew",
    miraidon: "special/miraidon",
    okidogi: "special/okidogi-munkidori-fezandipiti-pecharunt",
    munkidori: "special/okidogi-munkidori-fezandipiti-pecharunt",
    fezandipiti: "special/okidogi-munkidori-fezandipiti-pecharunt",
    pecharunt: "special/okidogi-munkidori-fezandipiti-pecharunt",
    zekrom: "special/zekrom",
    "tornadus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "tornadus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "thundurus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "thundurus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "landorus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "landorus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "enamorus-incarnate": "special/tornadus-thundurus-landorus-enamorus",
    "enamorus-therian": "special/tornadus-thundurus-landorus-enamorus",
    "tapu-koko": "special/tapu",
    "tapu-lele": "special/tapu",
    "tapu-bulu": "special/tapu",
    "tapu-fini": "special/tapu",
    "articuno-galarian": "special/articuno-galarian",
    "zapdos-galarian": "special/zapdos-galarian",
    "moltres-galarian": "special/moltres-galarian",
    eternatus: "special/eternatus",
    kubfu: "special/kubfu",
    necrozma: "special/necrozma",
    reshiram: "special/reshiram",
    "urshifu-rapid-strike": "special/urshifu-rapid-strike",
    "urshifu-rapid-strike-gigantamax": "special/gigantamax",
    "urshifu-single-strike": "special/urshifu-single-strike",
    "urshifu-single-strike-gigantamax": "special/gigantamax",
    "zacian-crowned-sword": "special/zacian",
    "zacian-hero-of-many-battles": "special/zacian",
    "zamazenta-crowned-shield": "special/zamazenta",
    "zamazenta-hero-of-many-battles": "special/zamazenta",
    "mega-zygarde": "special/zygarde",
    "zygarde-10-forme": "special/zygarde",
    "zygarde-50-forme": "special/zygarde",
    "zygarde-complete-forme": "special/zygarde",
    "type-null": "special/typenullsilvally",
    silvally: "special/typenullsilvally",
    "chien-pao": "special/chienpao",
    "chi-yu": "special/chiyu",
    "ting-lu": "special/tinglu",
    "wo-chien": "special/wochien",
    "ogerpon-cornerstone-mask": "special/ogerpon",
    "ogerpon-hearthflame-mask": "special/ogerpon",
    "ogerpon-teal-mask": "special/ogerpon",
    "ogerpon-wellspring-mask": "special/ogerpon",
    calyrex: "special/calyrex-glastrier-calyrex-ice-rider",
    glastrier: "special/calyrex-glastrier-calyrex-ice-rider",
    "calyrex-ice-rider": "special/calyrex-glastrier-calyrex-ice-rider",
    spectrier: "special/spectrier-calyrex-shadow-rider",
    "calyrex-shadow-rider": "special/spectrier-calyrex-shadow-rider",
    heatran: "special/heatran",
    "mega-heatran": "special/heatran",
    magearna: "special/magearna",
    "mega-magearna": "special/magearna",
    meltan: "special/meltan-melmetal",
    melmetal: "special/meltan-melmetal",
    "melmetal-gigantamax": "special/gigantamax",
    regidrago: "special/regidrago",
    regieleki: "special/regieleki",
    volcanion: "special/volcanion",
    "venusaur-gigantamax": "special/gigantamax",
    "charizard-gigantamax": "special/gigantamax",
    "blastoise-gigantamax": "special/gigantamax",
    "butterfree-gigantamax": "special/gigantamax",
    "pikachu-gigantamax": "special/gigantamax",
    "meowth-gigantamax": "special/gigantamax",
    "machamp-gigantamax": "special/gigantamax",
    "gengar-gigantamax": "special/gigantamax",
    "kingler-gigantamax": "special/gigantamax",
    "lapras-gigantamax": "special/gigantamax",
    "eevee-gigantamax": "special/gigantamax",
    "snorlax-gigantamax": "special/gigantamax",
    "garbodor-gigantamax": "special/gigantamax",
    "rillaboom-gigantamax": "special/gigantamax",
    "cinderace-gigantamax": "special/gigantamax",
    "inteleon-gigantamax": "special/gigantamax",
    "corviknight-gigantamax": "special/gigantamax",
    "orbeetle-gigantamax": "special/gigantamax",
    "drednaw-gigantamax": "special/gigantamax",
    "coalossal-gigantamax": "special/gigantamax",
    "flapple-gigantamax": "special/gigantamax",
    "appletun-gigantamax": "special/gigantamax",
    "sandaconda-gigantamax": "special/gigantamax",
    "toxtricity-gigantamax": "special/gigantamax",
    "centiskorch-gigantamax": "special/gigantamax",
    "hatterene-gigantamax": "special/gigantamax",
    "grimmsnarl-gigantamax": "special/gigantamax",
    "alcremie-gigantamax": "special/gigantamax",
    "copperajah-gigantamax": "special/gigantamax",
    "duraludon-gigantamax": "special/gigantamax",
    "great-tusk": "special/paradox-ancient",
    "scream-tail": "special/paradox-ancient",
    "brute-bonnet": "special/paradox-ancient",
    "flutter-mane": "special/paradox-ancient",
    "slither-wing": "special/paradox-ancient",
    "sandy-shocks": "special/paradox-ancient",
    "roaring-moon": "special/paradox-ancient",
    "walking-wake": "special/paradox-ancient",
    "gouging-fire": "special/paradox-ancient",
    "raging-bolt": "special/paradox-ancient",
    "iron-treads": "special/paradox-future",
    "iron-bundle": "special/paradox-future",
    "iron-hands": "special/paradox-future",
    "iron-jugulis": "special/paradox-future",
    "iron-moth": "special/paradox-future",
    "iron-thorns": "special/paradox-future",
    "iron-valiant": "special/paradox-future",
    "iron-leaves": "special/paradox-future",
    "iron-boulder": "special/paradox-future",
    "iron-crown": "special/paradox-future",
    terapagos: "special/terapagos",
    "terapagos-terastal": "special/terapagos"
  },
  items: {
    normal: {
      id: "normal",
      title: "\uB178\uB9D0 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/normal.webp",
      category: "type",
      order: 0
    },
    fire: {
      id: "fire",
      title: "\uBD88\uAF43 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/fire.webp",
      category: "type",
      order: 1
    },
    water: {
      id: "water",
      title: "\uBB3C \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/water.webp",
      category: "type",
      order: 2
    },
    "leaf-bug": {
      id: "leaf-bug",
      title: "\uD480 \xB7 \uBC8C\uB808 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/leaf-bug.webp",
      category: "type",
      order: 3
    },
    electric: {
      id: "electric",
      title: "\uC804\uAE30 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/electric.webp",
      category: "type",
      order: 4
    },
    ice: {
      id: "ice",
      title: "\uC5BC\uC74C \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/ice.webp",
      category: "type",
      order: 5
    },
    fight: {
      id: "fight",
      title: "\uACA9\uD22C \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/fight.webp",
      category: "type",
      order: 6
    },
    poison: {
      id: "poison",
      title: "\uB3C5 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/poison.webp",
      category: "type",
      order: 7
    },
    ground: {
      id: "ground",
      title: "\uB545 \xB7 \uBC14\uC704 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/ground.webp",
      category: "type",
      order: 8
    },
    fly: {
      id: "fly",
      title: "\uBE44\uD589 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/fly.webp",
      category: "type",
      order: 9
    },
    psychic: {
      id: "psychic",
      title: "\uC5D0\uC2A4\uD37C \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/psychic.webp",
      category: "type",
      order: 10
    },
    ghost: {
      id: "ghost",
      title: "\uACE0\uC2A4\uD2B8 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/ghost.webp",
      category: "type",
      order: 13
    },
    dragon: {
      id: "dragon",
      title: "\uB4DC\uB798\uACE4 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/dragon.webp",
      category: "type",
      order: 14
    },
    dark: {
      id: "dark",
      title: "\uC545 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/dark.webp",
      category: "type",
      order: 15
    },
    steel: {
      id: "steel",
      title: "\uAC15\uCCA0 \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/steel.webp",
      category: "type",
      order: 16
    },
    fairy: {
      id: "fairy",
      title: "\uD398\uC5B4\uB9AC \uD0C0\uC785 \uBC30\uACBD",
      path: "./assets/backgrounds/fairy.webp",
      category: "type",
      order: 17
    },
    "special/articuno": {
      id: "special/articuno",
      title: "\uBE59\uD558\uC758 \uD638\uC218 (\uD504\uB9AC\uC838 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/articuno.webp",
      category: "legendary",
      order: 144,
      generation: 1,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/zapdos": {
      id: "special/zapdos",
      title: "\uB1CC\uBA85\uC758 \uD558\uB298 (\uC36C\uB354 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zapdos.webp",
      category: "legendary",
      order: 145,
      generation: 1,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/moltres": {
      id: "special/moltres",
      title: "\uBD88\uAF43\uC758 \uC9C0\uD3C9\uC120 (\uD30C\uC774\uC5B4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/moltres.webp",
      category: "legendary",
      order: 146,
      generation: 1,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/mewtwo": {
      id: "special/mewtwo",
      title: "\uACE0\uC694\uD55C \uC2E4\uD5D8\uC2E4 (\uBBA4\uCE20 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/mewtwo.webp",
      category: "legendary",
      order: 150,
      generation: 1,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/raikou": {
      id: "special/raikou",
      title: "\uBC88\uAC1C\uAC00 \uB2EC\uB9AC\uB294 \uB4E4\uD310 (\uB77C\uC774\uCF54 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/raikou.webp",
      category: "legendary",
      order: 243,
      generation: 2,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/entei": {
      id: "special/entei",
      title: "\uB178\uC744\uC9C4 \uD654\uC0B0 \uB300\uC9C0 (\uC564\uD14C\uC774 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/entei.webp",
      category: "legendary",
      order: 244,
      generation: 2,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/suicune": {
      id: "special/suicune",
      title: "\uB9D1\uC740 \uBC14\uB78C\uC758 \uD638\uC218 (\uC2A4\uC774\uCFE4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/suicune.webp",
      category: "legendary",
      order: 245,
      generation: 2,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/lugia": {
      id: "special/lugia",
      title: "\uC2EC\uD574\uC758 \uC18C\uC6A9\uB3CC\uC774 (\uB8E8\uAE30\uC544 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/lugia.webp",
      category: "legendary",
      order: 249,
      generation: 2,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/ho-oh": {
      id: "special/ho-oh",
      title: "\uBB34\uC9C0\uAC1C \uB108\uBA38\uC758 \uD558\uB298 (\uCE60\uC0C9\uC870 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/ho-oh.webp",
      category: "legendary",
      order: 250,
      generation: 2,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/regirock": {
      id: "special/regirock",
      title: "\uBC14\uC704\uC758 \uC131\uC804 (\uB808\uC9C0\uB77D \uC804\uC6A9)",
      path: "./assets/backgrounds/special/regirock.webp",
      category: "legendary",
      order: 377,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/regice": {
      id: "special/regice",
      title: "\uC5BC\uC5B4\uBD99\uC740 \uC131\uC804 (\uB808\uC9C0\uC544\uC774\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/regice.webp",
      category: "legendary",
      order: 378,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/registeel": {
      id: "special/registeel",
      title: "\uAC15\uCCA0\uC758 \uC131\uC804 (\uB808\uC9C0\uC2A4\uD2F8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/registeel.webp",
      category: "legendary",
      order: 379,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/latias-latios": {
      id: "special/latias-latios",
      title: "\uD478\uB978 \uD558\uB298\uC758 \uC27C\uD130 (\uB77C\uD2F0\uC544\uC2A4\xB7\uB77C\uD2F0\uC624\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/latias-latios.webp",
      category: "legendary",
      order: 380,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/kyogre": {
      id: "special/kyogre",
      title: "\uAE4A\uC740 \uBC14\uB2E4\uC758 \uBB3C\uACB0 (\uAC00\uC774\uC624\uAC00 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/kyogre.webp",
      category: "legendary",
      order: 382,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/groudon": {
      id: "special/groudon",
      title: "\uAE68\uC5B4\uB09C \uB300\uC9C0 (\uADF8\uB780\uB3C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/groudon.webp",
      category: "legendary",
      order: 383,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/rayquaza": {
      id: "special/rayquaza",
      title: "\uCC3D\uACF5\uC758 \uC18C\uC6A9\uB3CC\uC774 (\uB808\uCFE0\uC7C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/rayquaza.webp",
      category: "legendary",
      order: 384,
      generation: 3,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/uxie-mesprit-azelf": {
      id: "special/uxie-mesprit-azelf",
      title: "\uC9C4\uC2E4 \uD638\uC218 (\uC720\uD06C\uC2DC\xB7\uC5E0\uB77C\uC774\uD2B8\xB7\uC544\uADF8\uB188 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/uxie-mesprit-azelf.webp",
      category: "legendary",
      order: 480,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/dialga": {
      id: "special/dialga",
      title: "\uC2DC\uAC04\uC758 \uD68C\uB791 (\uB514\uC544\uB8E8\uAC00 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/dialga.webp",
      category: "legendary",
      order: 483,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/palkia": {
      id: "special/palkia",
      title: "\uACF5\uAC04\uC758 \uC18C\uC6A9\uB3CC\uC774 (\uD384\uAE30\uC544 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/palkia.webp",
      category: "legendary",
      order: 484,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/heatran": {
      id: "special/heatran",
      title: "\uC6A9\uC554\uC758 \uB3D9\uAD74 (\uD788\uB4DC\uB7F0 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/heatran.webp",
      category: "legendary",
      order: 485,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/regigigas": {
      id: "special/regigigas",
      title: "\uAC70\uC778\uC758 \uC720\uC801 (\uB808\uC9C0\uAE30\uAC00\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/regigigas.webp",
      category: "legendary",
      order: 486,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/giratina": {
      id: "special/giratina",
      title: "\uB4A4\uD2C0\uB9B0 \uCC28\uC6D0 (\uAE30\uB77C\uD2F0\uB098 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/giratina.webp",
      category: "legendary",
      order: 487,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/cresselia": {
      id: "special/cresselia",
      title: "\uCD08\uC2B9\uB2EC\uC758 \uD638\uC218 (\uD06C\uB808\uC138\uB9AC\uC544 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/cresselia.webp",
      category: "legendary",
      order: 488,
      generation: 4,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute": {
      id: "special/cobalion-terrakion-virizion-keldeo-keldeo-resolute",
      title: "\uC131\uAC80\uC0AC\uC758 \uB4E4\uD310 (\uCF54\uBC14\uB974\uC628\xB7\uD14C\uB77C\uD0A4\uC628\xB7\uBE44\uB9AC\uB514\uC628\xB7\uCF00\uB974\uB514\uC624 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/cobalion-terrakion-virizion-keldeo-keldeo-resolute.webp",
      category: "legendary",
      order: 638,
      generation: 5,
      sharedCategories: [
        "legendary",
        "mythical"
      ]
    },
    "special/tornadus-thundurus-landorus-enamorus": {
      id: "special/tornadus-thundurus-landorus-enamorus",
      title: "\uD48D\uC694\uC758 \uC0AC\uB2F9 (\uD1A0\uB124\uB85C\uC2A4\xB7\uBCFC\uD2B8\uB85C\uC2A4\xB7\uB79C\uB4DC\uB85C\uC2A4\xB7\uB7EC\uBE0C\uB85C\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/tornadus-thundurus-landorus-enamorus.webp",
      category: "legendary",
      order: 641,
      generation: 5,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/reshiram": {
      id: "special/reshiram",
      title: "\uD770\uBE5B\uC758 \uD558\uB298 (\uB808\uC2DC\uB77C\uBB34 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/reshiram.webp",
      category: "legendary",
      order: 643,
      generation: 5,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/zekrom": {
      id: "special/zekrom",
      title: "\uD751\uB8B0\uC758 \uB300\uC9C0 (\uC81C\uD06C\uB85C\uBB34 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zekrom.webp",
      category: "legendary",
      order: 644,
      generation: 5,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/kyurem": {
      id: "special/kyurem",
      title: "\uC5BC\uC5B4\uBD99\uC740 \uC655\uAD6D (\uD050\uB808\uBB34 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/kyurem.webp",
      category: "legendary",
      order: 646,
      generation: 5,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/xerneas": {
      id: "special/xerneas",
      title: "\uC0DD\uBA85\uC758 \uC232 (\uC81C\uB974\uB124\uC544\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/xerneas.webp",
      category: "legendary",
      order: 716,
      generation: 6,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/yveltal": {
      id: "special/yveltal",
      title: "\uBD89\uC740 \uC18C\uC6A9\uB3CC\uC774\uC758 \uB300\uC9C0 (\uC774\uBCA8\uD0C0\uB974 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/yveltal.webp",
      category: "legendary",
      order: 717,
      generation: 6,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/zygarde": {
      id: "special/zygarde",
      title: "\uC9C8\uC11C\uC758 \uACC4\uACE1 (\uC9C0\uAC00\uB974\uB370 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zygarde.webp",
      category: "legendary",
      order: 718,
      generation: 6,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/typenullsilvally": {
      id: "special/typenullsilvally",
      title: "\uC5D0\uD14C\uB974\uD30C\uB77C\uB2E4\uC774\uC2A4 (\uD0C0\uC785:\uB110\xB7\uC2E4\uBC84\uB514 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/typenullsilvally.webp",
      category: "legendary",
      order: 772,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/tapu": {
      id: "special/tapu",
      title: "\uC218\uD638\uC2E0\uC758 \uC81C\uB2E8 (\uCE74\uD478\uAF2C\uAF2C\uAF2D\xB7\uCE74\uD478\uB098\uBE44\uB098\xB7\uCE74\uD478\uBE0C\uB8E8\uB8E8\xB7\uCE74\uD478\uB290\uC9C0\uB290 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/tapu.webp",
      category: "legendary",
      order: 785,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/ultra-beast": {
      id: "special/ultra-beast",
      title: "\uC6B8\uD2B8\uB77C\uC2A4\uD398\uC774\uC2A4 (\uC6B8\uD2B8\uB77C\uBE44\uC2A4\uD2B8\xB7\uCF54\uC2A4\uBAA8\uADF8\xB7\uCF54\uC2A4\uBAA8\uC6C0 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/ultra-beast.webp",
      category: "legendary",
      order: 789,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/solgaleo": {
      id: "special/solgaleo",
      title: "\uD0DC\uC591\uC758 \uC81C\uB2E8 (\uC194\uAC00\uB808\uC624\xB7\uB124\uD06C\uB85C\uC988\uB9C8 \uD669\uD63C\uC758\uAC08\uAE30 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/solgaleo.webp",
      category: "legendary",
      order: 791,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/lunala": {
      id: "special/lunala",
      title: "\uB2EC\uC744 \uD488\uC740 \uBC24\uD558\uB298 (\uB8E8\uB098\uC544\uB77C\xB7\uB124\uD06C\uB85C\uC988\uB9C8 \uC0C8\uBCBD\uC758\uB0A0\uAC1C \uC804\uC6A9)",
      path: "./assets/backgrounds/special/lunala.webp",
      category: "legendary",
      order: 792,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/necrozma": {
      id: "special/necrozma",
      title: "\uBE5B\uC744 \uC783\uC740 \uACB0\uC815 (\uB124\uD06C\uB85C\uC988\uB9C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/necrozma.webp",
      category: "legendary",
      order: 800,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/ultranecrozma": {
      id: "special/ultranecrozma",
      title: "\uB208\uBD80\uC2E0 \uBE5B\uC758 \uC131\uC804 (\uC6B8\uD2B8\uB77C\uB124\uD06C\uB85C\uC988\uB9C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/ultranecrozma.webp",
      category: "legendary",
      order: 800,
      generation: 7,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/articuno-galarian": {
      id: "special/articuno-galarian",
      title: "\uBCF4\uB78F\uBE5B \uC124\uC0B0 (\uAC00\uB77C\uB974 \uD504\uB9AC\uC838 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/articuno-galarian.webp",
      category: "legendary",
      order: 144,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/zapdos-galarian": {
      id: "special/zapdos-galarian",
      title: "\uBD89\uC740 \uBC14\uC704\uC758 \uD669\uC57C (\uAC00\uB77C\uB974 \uC36C\uB354 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zapdos-galarian.webp",
      category: "legendary",
      order: 145,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/moltres-galarian": {
      id: "special/moltres-galarian",
      title: "\uC5B4\uB460\uC774 \uD0C0\uC624\uB974\uB294 \uB300\uC9C0 (\uAC00\uB77C\uB974 \uD30C\uC774\uC5B4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/moltres-galarian.webp",
      category: "legendary",
      order: 146,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/zacian": {
      id: "special/zacian",
      title: "\uAC80\uC758 \uC131\uC5ED (\uC790\uC2DC\uC548 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zacian.webp",
      category: "legendary",
      order: 888,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/zamazenta": {
      id: "special/zamazenta",
      title: "\uBC29\uD328\uC758 \uC131\uC5ED (\uC790\uB9C8\uC820\uD0C0 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zamazenta.webp",
      category: "legendary",
      order: 889,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/eternatus": {
      id: "special/eternatus",
      title: "\uBB34\uD55C\uC758 \uC18C\uC6A9\uB3CC\uC774 (\uBB34\uD55C\uB2E4\uC774\uB178 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/eternatus.webp",
      category: "legendary",
      order: 890,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/kubfu": {
      id: "special/kubfu",
      title: "\uC218\uB828\uC758 \uB730 (\uCE58\uACE0\uB9C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/kubfu.webp",
      category: "legendary",
      order: 891,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/urshifu-rapid-strike": {
      id: "special/urshifu-rapid-strike",
      title: "\uBB3C\uACB0\uC758 \uC218\uB828\uC7A5 (\uC6B0\uB77C\uC624\uC2A4 \uC5F0\uACA9\uC758\uD0DC\uC138 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/urshifu-rapid-strike.webp",
      category: "legendary",
      order: 892,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/urshifu-single-strike": {
      id: "special/urshifu-single-strike",
      title: "\uC5B4\uB460\uC758 \uC218\uB828\uC7A5 (\uC6B0\uB77C\uC624\uC2A4 \uC77C\uACA9\uC758\uD0DC\uC138 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/urshifu-single-strike.webp",
      category: "legendary",
      order: 892,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/regieleki": {
      id: "special/regieleki",
      title: "\uC804\uB958\uC758 \uBD09\uC778\uC2E4 (\uB808\uC9C0\uC5D0\uB808\uD0A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/regieleki.webp",
      category: "legendary",
      order: 894,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/regidrago": {
      id: "special/regidrago",
      title: "\uC6A9\uC758 \uBD09\uC778\uC2E4 (\uB808\uC9C0\uB4DC\uB798\uACE0 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/regidrago.webp",
      category: "legendary",
      order: 895,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/calyrex-glastrier-calyrex-ice-rider": {
      id: "special/calyrex-glastrier-calyrex-ice-rider",
      title: "\uC124\uC6D0\uC758 \uC655\uC88C (\uBC84\uB4DC\uB809\uC2A4\xB7\uBE14\uB9AC\uC790\uD3EC\uC2A4\xB7\uBC84\uB4DC\uB809\uC2A4 \uBC31\uB9C8\uD0C4\uBAA8\uC2B5 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/calyrex-glastrier-calyrex-ice-rider.webp",
      category: "legendary",
      order: 896,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/spectrier-calyrex-shadow-rider": {
      id: "special/spectrier-calyrex-shadow-rider",
      title: "\uC6D4\uC601\uC758 \uC655\uC88C (\uB808\uC774\uC2A4\uD3EC\uC2A4\xB7\uBC84\uB4DC\uB809\uC2A4 \uD751\uB9C8\uD0C4\uBAA8\uC2B5 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/spectrier-calyrex-shadow-rider.webp",
      category: "legendary",
      order: 897,
      generation: 8,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/wochien": {
      id: "special/wochien",
      title: "\uC774\uB07C \uB080 \uC81C\uB2E8 (\uCD1D\uC9C0\uC5D4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/wochien.webp",
      category: "legendary",
      order: 1001,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/chienpao": {
      id: "special/chienpao",
      title: "\uBE59\uC124\uC758 \uC81C\uB2E8 (\uD30C\uC624\uC820 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/chienpao.webp",
      category: "legendary",
      order: 1002,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/tinglu": {
      id: "special/tinglu",
      title: "\uB300\uC9C0\uC758 \uC81C\uB2E8 (\uB529\uB8E8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/tinglu.webp",
      category: "legendary",
      order: 1003,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/chiyu": {
      id: "special/chiyu",
      title: "\uBD88\uAF43\uC758 \uC81C\uB2E8 (\uC704\uC720\uC774 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/chiyu.webp",
      category: "legendary",
      order: 1004,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/koraidon": {
      id: "special/koraidon",
      title: "\uD0DC\uACE0\uC758 \uD611\uACE1 (\uCF54\uB77C\uC774\uB3C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/koraidon.webp",
      category: "legendary",
      order: 1007,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/miraidon": {
      id: "special/miraidon",
      title: "\uBE5B\uC774 \uD750\uB974\uB294 \uB3C4\uC2DC (\uBBF8\uB77C\uC774\uB3C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/miraidon.webp",
      category: "legendary",
      order: 1008,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/okidogi-munkidori-fezandipiti-pecharunt": {
      id: "special/okidogi-munkidori-fezandipiti-pecharunt",
      title: "\uBCF5\uC22D\uC544 \uC2E0\uC0AC (\uC870\uD0C0\uAD6C\xB7\uC774\uC57C\uD6C4\xB7\uAE30\uB85C\uCE58\xB7\uBCF5\uC22D\uC545\uB3D9 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/okidogi-munkidori-fezandipiti-pecharunt.webp",
      category: "legendary",
      order: 1014,
      generation: 9,
      sharedCategories: [
        "legendary",
        "mythical"
      ]
    },
    "special/ogerpon": {
      id: "special/ogerpon",
      title: "\uAC00\uBA74\uC758 \uC232 (\uC624\uAC70\uD3F0 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/ogerpon.webp",
      category: "legendary",
      order: 1017,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/terapagos": {
      id: "special/terapagos",
      title: "\uACB0\uC815\uC758 \uC131\uC804 (\uD14C\uB77C\uD30C\uACE0\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/terapagos.webp",
      category: "legendary",
      order: 1024,
      generation: 9,
      sharedCategories: [
        "legendary"
      ]
    },
    "special/mew": {
      id: "special/mew",
      title: "\uAFC8\uACB0\uC758 \uD558\uB298 (\uBBA4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/mew.webp",
      category: "mythical",
      order: 151,
      generation: 1,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/celebi": {
      id: "special/celebi",
      title: "\uC2DC\uAC04\uC744 \uD488\uC740 \uC232 (\uC138\uB808\uBE44 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/celebi.webp",
      category: "mythical",
      order: 251,
      generation: 2,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/jirachi": {
      id: "special/jirachi",
      title: "\uC18C\uC6D0\uC744 \uB2F4\uC740 \uBCC4\uD558\uB298 (\uC9C0\uB77C\uCE58 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/jirachi.webp",
      category: "mythical",
      order: 385,
      generation: 3,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/deoxys": {
      id: "special/deoxys",
      title: "\uBCC4\uB4E4\uC758 \uADA4\uB3C4 (\uD14C\uC624\uD0A4\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/deoxys.webp",
      category: "mythical",
      order: 386,
      generation: 3,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/manaphy-phione": {
      id: "special/manaphy-phione",
      title: "\uBC14\uB2E4\uC758 \uC694\uB78C (\uB9C8\uB098\uD53C\xB7\uD53C\uC624\uB124 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/manaphy-phione.webp",
      category: "mythical",
      order: 489,
      generation: 4,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/darkrai": {
      id: "special/darkrai",
      title: "\uB2EC\uBE5B \uC18D\uC758 \uADF8\uB9BC\uC790 (\uB2E4\uD06C\uB77C\uC774 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/darkrai.webp",
      category: "mythical",
      order: 491,
      generation: 4,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/shaymin": {
      id: "special/shaymin",
      title: "\uAF43\uBC14\uB78C\uC758 \uB4E4\uD310 (\uC250\uC774\uBBF8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/shaymin.webp",
      category: "mythical",
      order: 492,
      generation: 4,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/arceus": {
      id: "special/arceus",
      title: "\uC2DC\uC791\uC758 \uC131\uC804 (\uC544\uB974\uC138\uC6B0\uC2A4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/arceus.webp",
      category: "mythical",
      order: 493,
      generation: 4,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/victini": {
      id: "special/victini",
      title: "\uC2B9\uB9AC\uC758 \uD574\uB3CB\uC774 (\uBE44\uD06C\uD2F0\uB2C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/victini.webp",
      category: "mythical",
      order: 494,
      generation: 5,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/meloetta-aria": {
      id: "special/meloetta-aria",
      title: "\uBCC4\uBE5B\uC758 \uBB34\uB300 (\uBA54\uB85C\uC5E3\uD0C0 \uBCF4\uC774\uC2A4\uD3FC \uC804\uC6A9)",
      path: "./assets/backgrounds/special/meloetta-aria.webp",
      category: "mythical",
      order: 648,
      generation: 5,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/meloetta-pirouette": {
      id: "special/meloetta-pirouette",
      title: "\uB178\uC744\uBE5B\uC758 \uBB34\uB300 (\uBA54\uB85C\uC5E3\uD0C0 \uC2A4\uD15D\uD3FC \uC804\uC6A9)",
      path: "./assets/backgrounds/special/meloetta-pirouette.webp",
      category: "mythical",
      order: 648,
      generation: 5,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/genesect": {
      id: "special/genesect",
      title: "\uBD89\uC740 \uC5F0\uAD6C\uC2E4 (\uAC8C\uB178\uC138\uD06C\uD2B8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/genesect.webp",
      category: "mythical",
      order: 649,
      generation: 5,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/diancie": {
      id: "special/diancie",
      title: "\uBCF4\uC11D\uC758 \uB3D9\uAD74 (\uB514\uC548\uC2DC \uC804\uC6A9)",
      path: "./assets/backgrounds/special/diancie.webp",
      category: "mythical",
      order: 719,
      generation: 6,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/hoopa-confined": {
      id: "special/hoopa-confined",
      title: "\uCC28\uC6D0\uC758 \uD68C\uB791 (\uD6C4\uD30C \uC804\uC6A9)",
      path: "./assets/backgrounds/special/hoopa-confined.webp",
      category: "mythical",
      order: 720,
      generation: 6,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/volcanion": {
      id: "special/volcanion",
      title: "\uC99D\uAE30\uC758 \uACF5\uC7A5 (\uBCFC\uCF00\uB2C8\uC628 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/volcanion.webp",
      category: "mythical",
      order: 721,
      generation: 6,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/magearna": {
      id: "special/magearna",
      title: "\uAE30\uACC4\uC7A5\uCE58\uC758 \uC815\uC6D0 (\uB9C8\uAE30\uC544\uB098 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/magearna.webp",
      category: "mythical",
      order: 801,
      generation: 7,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/marshadow": {
      id: "special/marshadow",
      title: "\uADF8\uB9BC\uC790\uC5D0 \uC7A0\uAE34 \uC720\uC801 (\uB9C8\uC0E4\uB3C4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/marshadow.webp",
      category: "mythical",
      order: 802,
      generation: 7,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/zeraora": {
      id: "special/zeraora",
      title: "\uBC88\uAC1C\uAC00 \uC2A4\uCE58\uB294 \uB3C4\uC2DC (\uC81C\uB77C\uC624\uB77C \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zeraora.webp",
      category: "mythical",
      order: 807,
      generation: 7,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/meltan-melmetal": {
      id: "special/meltan-melmetal",
      title: "\uAC15\uCCA0 \uC81C\uB828\uC18C (\uBA5C\uD0C4\xB7\uBA5C\uBA54\uD0C8 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/meltan-melmetal.webp",
      category: "mythical",
      order: 808,
      generation: 7,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/zarude": {
      id: "special/zarude",
      title: "\uAE4A\uC740 \uC815\uAE00\uC758 \uC27C\uD130 (\uC790\uB8E8\uB3C4 \uC804\uC6A9)",
      path: "./assets/backgrounds/special/zarude.webp",
      category: "mythical",
      order: 893,
      generation: 8,
      sharedCategories: [
        "mythical"
      ]
    },
    "special/gigantamax": {
      id: "special/gigantamax",
      title: "\uAC70\uB2E4\uC774\uB9E5\uC2A4 \uD3ED\uD48D (\uAC70\uB2E4\uC774\uB9E5\uC2A4 \uD3EC\uCF13\uBAAC \uC804\uC6A9)",
      path: "./assets/backgrounds/special/gigantamax.webp",
      category: "other",
      generation: 8,
      order: 3
    },
    "special/paradox-ancient": {
      id: "special/paradox-ancient",
      title: "\uD0DC\uACE0\uC758 \uB300\uC9C0 (\uACFC\uAC70 \uD328\uB7EC\uB3C5\uC2A4 \uD3EC\uCF13\uBAAC \uC804\uC6A9)",
      path: "./assets/backgrounds/special/paradox-ancient.webp",
      category: "other",
      generation: 9,
      order: 984
    },
    "special/paradox-future": {
      id: "special/paradox-future",
      title: "\uBBF8\uB798\uC758 \uB3C4\uC2DC (\uBBF8\uB798 \uD328\uB7EC\uB3C5\uC2A4 \uD3EC\uCF13\uBAAC \uC804\uC6A9)",
      path: "./assets/backgrounds/special/paradox-future.webp",
      category: "other",
      generation: 9,
      order: 990
    }
  }
};

// cloudflare/worker.mjs
var VERSION = "2026-03-11";
var DEFAULT_ORIGIN = "https://pokemon.loraticon.com";
var SETTINGS_SLUG = "__widget_settings_v1__";
var SETTINGS_CAPTION = "pokemon-widget-preferences-v1";
var remoteImages = "https://raw.githubusercontent.com/loraticon/random_pokemon_widget-ver1/main/images";
var koreaDay = (time = Date.now()) => new Date(new Date(time).getTime() + 324e5).toISOString().slice(0, 10);
var normalizeSlug = (slug) => String(slug).replace(/^mr[.-]+mime$/i, "mr-mime").replace(/farfetch['\u2019]d/gi, "farfetchd").replace(/^nidoran\u2640$/i, "nidoran-f").replace(/^nidoran\u2642$/i, "nidoran-m");
var captureKey = (record) => normalizeSlug(record.slug) + ":false";
var entries = new Map(pokemon_final_with_forms_default.map((entry) => [normalizeSlug(entry.slug), entry]));
var defaultPreferences = { mode: "draw", pokemonKey: "", backgroundId: "", favoritePokemon: [], favoriteBackgrounds: [] };
var properties = { "\uC774\uB984": { title: {} }, "\uD3FC \uC2DD\uBCC4\uC790": { rich_text: {} }, "\uBC30\uACBD \uC2DD\uBCC4\uC790": { rich_text: {} }, "\uC990\uACA8\uCC3E\uAE30": { checkbox: {} } };
function backgroundFor(record) {
  if (record.backgroundId) return background_catalog_default.items[record.backgroundId] || null;
  const slug = normalizeSlug(record.slug);
  const types = pokemon_background_types_default.bySlug[slug] || pokemon_background_types_default.byDex[record.dexId] || [];
  const id = background_catalog_default.bySlug[slug] || types.map((type) => background_catalog_default.byType[type]).find(Boolean);
  return background_catalog_default.items[id] || null;
}
var richText = (content) => [{ type: "text", text: { content: String(content) } }];
var plain = (property) => (property?.title || property?.rich_text || []).map((part) => part.plain_text || part.text?.content || "").join("");
var json = (data, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store", "Referrer-Policy": "no-referrer" } });
var ServiceError = class extends Error {
  constructor(message, status = 503, uncertain = false, code) {
    super(message);
    Object.assign(this, { status, uncertain, code });
  }
};
function pageId(value) {
  const input = String(value || "").trim();
  if (/^[0-9a-f]{32}$/i.test(input)) return input.toLowerCase();
  if (/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(input)) return input.replaceAll("-", "").toLowerCase();
  let url;
  try {
    url = new URL(input);
  } catch {
  }
  if (!url || url.protocol !== "https:" || url.username || url.password || !(url.hostname === "app.notion.com" || /(^|\.)(notion\.so|notion\.site)$/.test(url.hostname))) {
    throw new ServiceError("\uBCF5\uC81C\uD55C \uB178\uC158 \uC218\uC9D1 DB\uC758 HTTPS \uC8FC\uC18C\uB97C \uC785\uB825\uD574\uC8FC\uC138\uC694.", 400);
  }
  const id = decodeURIComponent(url.pathname).match(/([0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}|[0-9a-f]{32})\/?$/i)?.[1];
  if (!id) throw new ServiceError("\uBCF5\uC81C\uD55C \uC6D0\uBCF8 \uB178\uC158 DB \uC8FC\uC18C\uB97C \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
  return id.replaceAll("-", "").toLowerCase();
}
var queues = /* @__PURE__ */ new Map();
async function serial(databaseId, task) {
  const previous = queues.get(databaseId) || Promise.resolve();
  let release;
  const current = new Promise((resolve) => {
    release = resolve;
  });
  queues.set(databaseId, current);
  await previous;
  try {
    return await task();
  } finally {
    release();
    if (queues.get(databaseId) === current) queues.delete(databaseId);
  }
}
var worker_default = {
  async fetch(request, env) {
    const origin = request.headers.get("Origin");
    let allowedOrigin;
    try {
      const configured = new URL(env.WIDGET_ORIGIN || DEFAULT_ORIGIN);
      if (configured.protocol === "https:" && !configured.username && !configured.password && !configured.search && !configured.hash && configured.pathname === "/") allowedOrigin = configured.origin;
    } catch {
    }
    const respond = (response) => {
      const headers = new Headers(response.headers);
      headers.set("Vary", "Origin");
      if (origin && origin === allowedOrigin) headers.set("Access-Control-Allow-Origin", origin);
      return new Response(response.body, { status: response.status, headers });
    };
    const reject = (message, status) => respond(json({ error: message }, status));
    if (!allowedOrigin) return reject("Worker\uC758 WIDGET_ORIGIN \uC124\uC815\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 503);
    if (origin && origin !== allowedOrigin) return reject("\uD5C8\uC6A9\uB418\uC9C0 \uC54A\uC740 \uC704\uC82F \uC8FC\uC18C\uC785\uB2C8\uB2E4.", 403);
    const url = new URL(request.url);
    const methods = { "/api/setup": "POST", "/api/collection": "GET", "/api/capture": "POST", "/api/preferences": "POST" };
    if (!methods[url.pathname]) return reject("\uAC1C\uC778 Worker\uB294 \uC218\uC9D1 API\uB9CC \uC81C\uACF5\uD569\uB2C8\uB2E4.", 404);
    if (request.method === "OPTIONS") {
      const asked = (request.headers.get("Access-Control-Request-Headers") || "").split(",").map((x) => x.trim().toLowerCase()).filter(Boolean);
      if (!origin || request.headers.get("Access-Control-Request-Method") !== methods[url.pathname] || asked.some((x) => x !== "content-type")) return reject("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC5F0\uACB0 \uC694\uCCAD\uC785\uB2C8\uB2E4.", 403);
      return respond(new Response(null, { status: 204, headers: { "Access-Control-Allow-Methods": methods[url.pathname], "Access-Control-Allow-Headers": "Content-Type", "Access-Control-Max-Age": "86400" } }));
    }
    if (request.method !== methods[url.pathname]) return reject("\uC9C0\uC6D0\uD558\uC9C0 \uC54A\uB294 \uC694\uCCAD \uBC29\uC2DD\uC785\uB2C8\uB2E4.", 405);
    if (!env.NOTION_TOKEN) return reject("\uAC1C\uC778 Worker\uC758 Secret\uC5D0 NOTION_TOKEN\uC744 \uB4F1\uB85D\uD558\uACE0 \uBC30\uD3EC\uD574\uC8FC\uC138\uC694.", 503);
    try {
      let body = {};
      if (request.method === "POST") {
        const text = await request.text();
        if (new TextEncoder().encode(text).length > 65536) throw new ServiceError("\uC800\uC7A5 \uC694\uCCAD\uC774 \uB108\uBB34 \uCEE4\uC694.", 413);
        try {
          body = JSON.parse(text);
        } catch {
          throw new ServiceError("\uC5F0\uACB0 \uC694\uCCAD \uD615\uC2DD\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
        }
        if (!body || typeof body !== "object" || Array.isArray(body)) throw new ServiceError("\uC5F0\uACB0 \uC694\uCCAD \uD615\uC2DD\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
      }
      const databaseId = pageId(body.databaseId || url.searchParams.get("db"));
      const collection = new NotionCollection(env, databaseId, allowedOrigin);
      const result = await serial(databaseId, async () => {
        if (url.pathname === "/api/setup") {
          const config = await collection.database(true);
          await collection.settings(true);
          return { databaseId, databaseUrl: config.url, dailyLimit: collection.limit };
        }
        if (url.pathname === "/api/capture") return collection.capture(body);
        if (url.pathname === "/api/preferences") return collection.savePreferences(body);
        return collection.getSnapshot(url.searchParams.get("records") === "1");
      });
      return respond(json(result));
    } catch (error) {
      return respond(json({ error: error instanceof ServiceError ? error.message : "\uB178\uC158 \uC5F0\uACB0\uC744 \uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uB2E4\uC2DC \uD655\uC778\uD574\uC8FC\uC138\uC694.", ...error.code ? { code: error.code } : {} }, error.status || 503));
    }
  }
};
var NotionCollection = class {
  constructor(env, databaseId, origin = DEFAULT_ORIGIN) {
    this.env = env;
    this.databaseId = pageId(databaseId);
    this.origin = origin;
    const limit = Number(env.DAILY_LIMIT ?? 3);
    if (!Number.isInteger(limit) || limit < 1 || limit > 100) throw new ServiceError("DAILY_LIMIT\uC740 1~100 \uC0AC\uC774\uC758 \uC815\uC218\uB85C \uC124\uC815\uD574\uC8FC\uC138\uC694.", 400);
    this.limit = limit;
  }
  async notion(path, body, method = body ? "POST" : "GET") {
    let response;
    try {
      response = await fetch("https://api.notion.com/v1/" + path, {
        method,
        headers: { Authorization: "Bearer " + this.env.NOTION_TOKEN, "Notion-Version": VERSION, "Content-Type": "application/json" },
        body: body ? JSON.stringify(body) : void 0,
        signal: AbortSignal.timeout(18e3)
      });
    } catch {
      throw new ServiceError("\uB178\uC158 \uC751\uB2F5\uC774 \uC9C0\uC5F0\uB418\uACE0 \uC788\uC5B4\uC694. \uC7A0\uC2DC \uD6C4 \uC800\uC7A5 \uC0C1\uD0DC\uB97C \uD655\uC778\uD574\uC8FC\uC138\uC694.", 503, true);
    }
    if (!response.ok) {
      const message = response.status === 401 ? "\uB178\uC158 \uC5F0\uACB0 \uD1A0\uD070\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694." : [403, 404].includes(response.status) ? "\uBCF5\uC81C\uD55C \uC6D0\uBCF8 DB \uC8FC\uC18C\uC640 \uB178\uC158\uC758 \uC5F0\uACB0 \uCD94\uAC00 \uAD8C\uD55C\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694." : response.status === 429 ? "\uB178\uC158 \uC694\uCCAD\uC774 \uC7A0\uC2DC \uB9CE\uC544\uC84C\uC5B4\uC694. \uC870\uAE08 \uB4A4 \uB2E4\uC2DC \uD655\uC778\uD574\uC8FC\uC138\uC694." : "\uB178\uC158 \uAE30\uB85D\uC744 \uCC98\uB9AC\uD558\uC9C0 \uBABB\uD588\uC5B4\uC694. DB \uC18D\uC131\uACFC \uC5F0\uACB0 \uC124\uC815\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.";
      throw new ServiceError(message, response.status === 429 ? 429 : 503, response.status >= 500 || response.status === 408);
    }
    try {
      return await response.json();
    } catch {
      throw new ServiceError("\uB178\uC158 \uC751\uB2F5\uC744 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uC800\uC7A5 \uC0C1\uD0DC\uB97C \uD655\uC778\uD574\uC8FC\uC138\uC694.", 503, true);
    }
  }
  async database(prepare = false) {
    if (!this.config) {
      const database = await this.notion("databases/" + this.databaseId);
      if (database.data_sources?.length !== 1) throw new ServiceError("\uB370\uC774\uD130 \uC18C\uC2A4\uAC00 \uD558\uB098\uC778 \uC6D0\uBCF8 \uC218\uC9D1 DB\uB97C \uC5F0\uACB0\uD574\uC8FC\uC138\uC694.", 400);
      this.config = { source: database.data_sources[0].id, url: database.url || "https://www.notion.so/" + this.databaseId };
    }
    if (prepare) {
      const source = await this.notion("data_sources/" + this.config.source);
      for (const [name, definition] of Object.entries(properties)) {
        if (source.properties?.[name] && !(Object.keys(definition)[0] in source.properties[name])) throw new ServiceError(`\uB178\uC158\uC758 '${name}' \uC18D\uC131 \uC720\uD615\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.`, 400);
      }
      const missing = Object.fromEntries(Object.entries(properties).filter(([name]) => !source.properties?.[name]));
      if (Object.keys(missing).length) await this.notion("data_sources/" + this.config.source, { properties: missing }, "PATCH");
    }
    return this.config;
  }
  async query(filter) {
    const config = await this.database();
    const pages = [];
    let cursor;
    for (let count = 0; count < 100; count++) {
      const data = await this.notion(`data_sources/${config.source}/query`, { page_size: 100, ...filter ? { filter } : {}, ...cursor ? { start_cursor: cursor } : {} });
      pages.push(...data.results.filter((page) => !page.archived && !page.in_trash));
      if (!data.has_more) return pages;
      cursor = data.next_cursor;
      if (!cursor) break;
    }
    throw new ServiceError("\uB178\uC158 \uAE30\uB85D\uC744 \uBAA8\uB450 \uC77D\uC9C0 \uBABB\uD588\uC5B4\uC694. \uB2E4\uC2DC \uD655\uC778\uD574\uC8FC\uC138\uC694.");
  }
  async settings(create = false) {
    if (this.settingsRecord) return this.settingsRecord;
    const pages = await this.query({ property: "\uD3FC \uC2DD\uBCC4\uC790", rich_text: { equals: SETTINGS_SLUG } });
    let page = pages.sort((a, b) => String(a.created_time).localeCompare(String(b.created_time)) || a.id.localeCompare(b.id))[0];
    if (!page && create) {
      page = await this.notion("pages", {
        parent: { type: "data_source_id", data_source_id: (await this.database()).source },
        properties: { "\uC774\uB984": { title: richText("\uC704\uC82F \uC124\uC815") }, "\uD3FC \uC2DD\uBCC4\uC790": { rich_text: richText(SETTINGS_SLUG) } },
        children: [{ object: "block", type: "code", code: { language: "json", caption: richText(SETTINGS_CAPTION), rich_text: this.settingsText(defaultPreferences) } }]
      });
    }
    if (!page) throw new ServiceError("\uC5F0\uACB0 \uD398\uC774\uC9C0\uC5D0\uC11C DB\uB97C \uC5F0\uACB0\uD574 \uC704\uC82F \uC124\uC815 \uD398\uC774\uC9C0\uB97C \uC900\uBE44\uD574\uC8FC\uC138\uC694.", 400);
    let cursor;
    let block;
    for (let count = 0; count < 10; count++) {
      const data = await this.notion(`blocks/${page.id}/children?page_size=100${cursor ? "&start_cursor=" + encodeURIComponent(cursor) : ""}`);
      block = data.results.find((item) => item.type === "code" && plain({ rich_text: item.code.caption }) === SETTINGS_CAPTION);
      if (block || !data.has_more) break;
      cursor = data.next_cursor;
      if (!cursor) break;
    }
    if (!block) throw new ServiceError("\uB178\uC158\uC758 \uC704\uC82F \uC124\uC815 \uD398\uC774\uC9C0\uC5D0\uC11C \uC124\uC815 \uBE14\uB85D\uC744 \uCC3E\uC9C0 \uBABB\uD588\uC5B4\uC694.", 400);
    let preferences;
    try {
      preferences = JSON.parse(plain({ rich_text: block.code.rich_text }));
    } catch {
      throw new ServiceError("\uB178\uC158 \uC704\uC82F \uC124\uC815 \uB0B4\uC6A9\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
    }
    if (!preferences || !["draw", "sleep"].includes(preferences.mode) || typeof preferences.pokemonKey !== "string" || typeof preferences.backgroundId !== "string" || !Array.isArray(preferences.favoriteBackgrounds)) throw new ServiceError("\uB178\uC158 \uC704\uC82F \uC124\uC815 \uD615\uC2DD\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
    return this.settingsRecord = { pageId: page.id, blockId: block.id, preferences: { ...defaultPreferences, ...preferences } };
  }
  settingsText(preferences) {
    const text = JSON.stringify({ mode: preferences.mode, pokemonKey: preferences.pokemonKey, backgroundId: preferences.backgroundId, favoriteBackgrounds: preferences.favoriteBackgrounds });
    return text.match(/[\s\S]{1,1800}/gu).map((part) => richText(part)[0]);
  }
  toRecord(page) {
    const p = page.properties;
    const slug = normalizeSlug(plain(p["\uD3FC \uC2DD\uBCC4\uC790"]));
    const entry = entries.get(slug);
    if (!entry) throw new ServiceError(`\uB178\uC158\uC758 \uD3FC \uC2DD\uBCC4\uC790 '${slug}'\uB97C \uD655\uC778\uD574\uC8FC\uC138\uC694.`, 400);
    const backgroundId = plain(p["\uBC30\uACBD \uC2DD\uBCC4\uC790"]).trim();
    if (backgroundId && !background_catalog_default.items[backgroundId]) throw new ServiceError(`\uB178\uC158\uC758 \uBC30\uACBD \uC2DD\uBCC4\uC790 '${backgroundId}'\uB97C \uD655\uC778\uD574\uC8FC\uC138\uC694.`, 400);
    const record = {
      id: page.id,
      pageId: page.id,
      slug,
      dexId: entry.dexId,
      name: plain(p["\uC774\uB984"]) || entry.ko || entry.en,
      isShiny: false,
      favorite: Boolean(p["\uC990\uACA8\uCC3E\uAE30"]?.checkbox),
      backgroundId,
      capturedAt: page.created_time,
      imageSrc: `${remoteImages}/normal/${encodeURIComponent(slug)}.webp`
    };
    const background = backgroundFor(record);
    return { ...record, backgroundId: background?.id || "", backgroundName: background?.title || "", backgroundSrc: background ? new URL(background.path.slice(2), this.origin).href : "" };
  }
  async readRecords() {
    return (await this.query()).filter((page) => plain(page.properties["\uD3FC \uC2DD\uBCC4\uC790"]) !== SETTINGS_SLUG && !page.properties["\uC0C9\uC774 \uB2E4\uB984"]?.checkbox).map((page) => this.toRecord(page)).sort((a, b) => a.dexId - b.dexId);
  }
  preferences(records, stored) {
    const pokemon = new Set(records.map(captureKey));
    const backgrounds = new Set(records.map((record) => record.backgroundId).filter(Boolean));
    return {
      ...defaultPreferences,
      ...stored,
      pokemonKey: pokemon.has(stored.pokemonKey) ? stored.pokemonKey : "",
      backgroundId: backgrounds.has(stored.backgroundId) ? stored.backgroundId : "",
      favoritePokemon: [...new Set(records.filter((record) => record.favorite).map(captureKey))],
      favoriteBackgrounds: [...new Set(stored.favoriteBackgrounds)].filter((id) => backgrounds.has(id))
    };
  }
  async getSnapshot(all = true) {
    const records = await this.readRecords();
    const settings = await this.settings();
    const day = koreaDay();
    const used = records.filter((record) => koreaDay(record.capturedAt) === day).length;
    return {
      schemaVersion: 4,
      day,
      used,
      limit: this.limit,
      remaining: Math.max(0, this.limit - used),
      pending: [],
      owned: [...new Set(records.map(captureKey))],
      records: all ? records : [],
      nextCursor: null,
      preferences: this.preferences(records, settings.preferences)
    };
  }
  async capture(body) {
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(body.id || "") || body.isShiny !== false) throw new ServiceError("\uC77C\uBC18 \uD3EC\uCF13\uBAAC\uC758 \uC218\uC9D1 \uC694\uCCAD\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
    const slug = normalizeSlug(body.slug);
    const entry = entries.get(slug);
    if (!entry) throw new ServiceError("\uB3C4\uAC10\uC5D0 \uC5C6\uB294 \uD3EC\uCF13\uBAAC\uC785\uB2C8\uB2E4.", 400);
    const before = await this.getSnapshot();
    if (before.owned.includes(captureKey(entry))) throw new ServiceError("\uC774\uBBF8 \uC7A1\uC740 \uD3EC\uCF13\uBAAC\uC774\uC5D0\uC694.", 409, false, "ALREADY_COLLECTED");
    if (!before.remaining) throw new ServiceError("\uC624\uB298\uC758 \uC218\uC9D1 \uAE30\uD68C\uB97C \uBAA8\uB450 \uC0AC\uC6A9\uD588\uC5B4\uC694.", 409, false, "DAILY_LIMIT");
    const background = backgroundFor(entry);
    try {
      await this.notion("pages", { parent: { type: "data_source_id", data_source_id: (await this.database()).source }, properties: {
        "\uC774\uB984": { title: richText(entry.ko || entry.en) },
        "\uD3FC \uC2DD\uBCC4\uC790": { rich_text: richText(slug) },
        "\uBC30\uACBD \uC2DD\uBCC4\uC790": { rich_text: richText(background?.id || "") },
        "\uC990\uACA8\uCC3E\uAE30": { checkbox: false }
      } });
    } catch (error) {
      if (!error.uncertain) throw error;
      const after = await this.getSnapshot();
      if (after.owned.includes(captureKey(entry))) return after;
      throw error;
    }
    return this.getSnapshot();
  }
  async savePreferences(body) {
    const records = await this.readRecords();
    const settings = await this.settings();
    const current = this.preferences(records, settings.preferences);
    if (body.favoriteChange) {
      const { pokemonKey, favorite } = body.favoriteChange;
      const matches = records.filter((record) => captureKey(record) === pokemonKey);
      if (typeof favorite !== "boolean" || !matches.length) throw new ServiceError("\uC218\uC9D1\uD55C \uD3EC\uCF13\uBAAC\uB9CC \uC990\uACA8\uCC3E\uAE30\uC5D0 \uCD94\uAC00\uD560 \uC218 \uC788\uC5B4\uC694.", 400);
      for (const record of matches) if (record.favorite !== favorite) await this.notion("pages/" + record.pageId, { properties: { "\uC990\uACA8\uCC3E\uAE30": { checkbox: favorite } } }, "PATCH");
      return { schemaVersion: 4, preferences: this.preferences(await this.readRecords(), settings.preferences) };
    }
    const next = { ...current, ...body };
    if (!["draw", "sleep"].includes(next.mode) || typeof next.pokemonKey !== "string" || typeof next.backgroundId !== "string" || !Array.isArray(next.favoriteBackgrounds) || next.favoriteBackgrounds.length > 3e3 || next.favoriteBackgrounds.some((id) => typeof id !== "string" || id.length > 160)) throw new ServiceError("\uD654\uBA74 \uC124\uC815\uC744 \uD655\uC778\uD574\uC8FC\uC138\uC694.", 400);
    if (next.pokemonKey && !records.some((record) => captureKey(record) === next.pokemonKey)) throw new ServiceError("\uC218\uC9D1\uD55C \uD3EC\uCF13\uBAAC\uB9CC \uC120\uD0DD\uD560 \uC218 \uC788\uC5B4\uC694.", 400);
    const owned = new Set(records.map((record) => record.backgroundId).filter(Boolean));
    if (next.backgroundId && !owned.has(next.backgroundId) || next.favoriteBackgrounds.some((id) => !owned.has(id))) throw new ServiceError("\uC218\uC9D1\uD55C \uBC30\uACBD\uB9CC \uC120\uD0DD\uD560 \uC218 \uC788\uC5B4\uC694.", 400);
    next.favoriteBackgrounds = [...new Set(next.favoriteBackgrounds)];
    await this.notion("blocks/" + settings.blockId, { code: { rich_text: this.settingsText(next) } }, "PATCH");
    settings.preferences = next;
    return { schemaVersion: 4, preferences: this.preferences(records, next) };
  }
};
export {
  NotionCollection,
  backgroundFor,
  worker_default as default,
  koreaDay,
  normalizeSlug,
  pageId
};
